@echo off
title Export Claude Studio
rem Packs Claude Studio (committed code only) into a zip for another PC and shows it in Explorer.
rem On the other PC: unzip it and double-click "Install Claude Studio.cmd".
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\migrate.ps1" -Export -Open
echo.
pause
