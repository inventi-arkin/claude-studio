// Updates from the Claude Studio website (spec updates FR-228 to FR-234, design updates §3).
// LIVE only. A check is a plain GET of latest.json and its signature from the site: nothing about the user or the PC is
// sent. An update runs only when the user clicks Update: download, check the SHA-256 against the signed latest.json,
// unpack, replace the app files in the Studio folder, commit, then hand over to scripts/update-finish.mjs, which deploys,
// waits for the new version and rolls back if it doesn't start. That helper runs detached from the release in use,
// because a deploy restarts this server.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { spawn, execFileSync } from "node:child_process";
import { RELEASE_PUBLIC_KEY } from "./scripts/release-key.pub.js";

export const UPDATE_SITE = (process.env.STUDIO_UPDATE_SITE || "https://inventi-arkin.github.io/claude-studio/").replace(/\/?$/, "/");
// Only https, or http to this PC (a test site); never anything else.
const siteOk = /^https:\/\//.test(UPDATE_SITE) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//.test(UPDATE_SITE);
const PUBLIC_KEY = process.env.STUDIO_UPDATE_KEY_FILE ? fs.readFileSync(process.env.STUDIO_UPDATE_KEY_FILE, "utf8") : RELEASE_PUBLIC_KEY;
const SIX_HOURS = 6 * 60 * 60 * 1000;
const MAX_MANIFEST = 64 * 1024, MAX_ZIP = 50 * 1024 * 1024;
const NEVER_TOUCH = /^(data|\.deploy|node_modules|specs|design|tests|site)(\/|$)/; // kept as they are (FR-232)
const TAR = process.platform === "win32" ? path.join(process.env.SystemRoot || "C:\\Windows", "System32", "tar.exe") : "tar";

export const cmpVersion = (a, b) => { const p = (v) => String(v).split(".").map((n) => Number(n) || 0); const x = p(a), y = p(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };

export const setupUpdates = (app, { CHANNEL, DATA, APP_DIR, PORT, busy }) => {
  const FILE = path.join(DATA, "updates.json");
  const load = () => ({ auto: true, ...readJson(FILE, {}) });
  const save = (patch) => { const s = { ...load(), ...patch }; fs.mkdirSync(DATA, { recursive: true }); fs.writeFileSync(FILE + ".tmp", JSON.stringify(s, null, 2)); fs.renameSync(FILE + ".tmp", FILE); return s; };
  const installed = () => readJson(path.join(APP_DIR, "release.json"), { version: "0", title: "", date: null, notes: [] });
  // LIVE runs from <Studio folder>\.deploy\releases\<sha>; the Studio folder is three levels up.
  const ROOT = path.resolve(APP_DIR, "..", "..", "..");
  const live = CHANNEL === "live" && fs.existsSync(path.join(ROOT, ".git")) && path.basename(path.dirname(APP_DIR)) === "releases";
  let checking = null, job = null; // job: { version, step, abort, done, total }

  // ---- checking (FR-228, FR-229) ----
  const fetchLimited = async (url, max, signal) => {
    const r = await fetch(url, { signal, redirect: "follow", cache: "no-store", credentials: "omit", headers: { accept: "*/*" } });
    if (!r.ok) throw new Error(`the site answered ${r.status}`);
    const len = Number(r.headers.get("content-length") || 0);
    if (len > max) throw new Error("the file is too big");
    const chunks = []; let n = 0;
    for await (const c of r.body) { n += c.length; if (n > max) throw new Error("the file is too big"); chunks.push(c); }
    return Buffer.concat(chunks);
  };
  const check = async () => {
    if (!live || !siteOk) return load();
    if (checking) return checking;
    checking = (async () => {
      const at = Date.now();
      try {
        const signal = AbortSignal.timeout(15000);
        const [text, sig] = await Promise.all([fetchLimited(UPDATE_SITE + "latest.json", MAX_MANIFEST, signal), fetchLimited(UPDATE_SITE + "latest.json.sig", 1024, signal)]);
        let ok = false;
        try { ok = crypto.verify(null, text, crypto.createPublicKey(PUBLIC_KEY), Buffer.from(sig.toString("utf8").trim(), "base64")); } catch {}
        if (!ok) return save({ lastCheck: { at, ok: false, unverified: true } });
        const m = JSON.parse(text.toString("utf8"));
        const valid = m?.format === "claude-studio-release" && /^\d+\.\d+\.\d+$/.test(m.version) && typeof m.title === "string" && Array.isArray(m.notes)
          && m.zip && /^releases\/claude-studio-[\d.]+\.zip$/.test(m.zip.url) && Number.isInteger(m.zip.size) && /^[0-9a-f]{64}$/.test(m.zip.sha256);
        if (!valid) return save({ lastCheck: { at, ok: false, error: "The update information isn't in the expected form." } });
        const latest = { version: m.version, title: m.title.slice(0, 60), date: String(m.date || "").slice(0, 10), notes: m.notes.slice(0, 10).map((n) => String(n).slice(0, 200)), zip: m.zip };
        return save({ lastCheck: { at, ok: true, latest } });
      } catch (e) {
        const offline = /fetch failed|ENOTFOUND|ECONNREFUSED|EAI_AGAIN|timeout|aborted/i.test(String(e?.cause?.code || e?.name || e?.message));
        return save({ lastCheck: { at, ok: false, error: offline ? "No connection to " + new URL(UPDATE_SITE).host + "." : String(e?.message || e).slice(0, 200) } });
      } finally { checking = null; }
    })();
    return checking;
  };
  if (live && siteOk) {
    setTimeout(() => { if (load().auto) check(); }, 10_000);
    setInterval(() => { if (load().auto) check(); }, SIX_HOURS).unref();
  }

  const view = () => {
    const s = load(), mine = installed(), latest = s.lastCheck?.latest;
    const available = live && latest && cmpVersion(latest.version, mine.version) > 0 ? latest : null;
    return { channel: CHANNEL, live, site: UPDATE_SITE, installed: mine, auto: s.auto !== false, lastCheck: s.lastCheck || null,
      lastOk: s.lastOk || null, available, dismissed: s.dismissed || null, checking: !!checking,
      progress: job ? { version: job.version, step: job.step, done: job.done || 0, total: job.total || 0 } : s.progress || null,
      result: s.result || null };
  };
  const busyNow = () => !!job || !!load().progress;

  // ---- updating (FR-231 to FR-233) ----
  const git = (...a) => execFileSync("git", a, { cwd: ROOT, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
  const apply = async (latest) => {
    const me = job; // this update's own job: Cancel can't make it look like a failure (QA F-1)
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "claude-studio-update-"));
    const zipPath = path.join(tmp, "release.zip"), stage = path.join(tmp, "stage");
    const fail = (reason) => { save({ result: { kind: "failed", to: latest.version, from: installed().version, reason, at: Date.now() }, progress: null }); };
    try {
      me.step = "downloading"; me.total = latest.zip.size;
      const r = await fetch(new URL(latest.zip.url, UPDATE_SITE), { signal: me.abort.signal, cache: "no-store", credentials: "omit" });
      if (!r.ok) throw new Error(`the download failed (${r.status})`);
      const hash = crypto.createHash("sha256"), out = fs.createWriteStream(zipPath);
      for await (const c of r.body) { me.done += c.length; if (me.done > MAX_ZIP) throw new Error("the download is too big"); hash.update(c); out.write(c); }
      await new Promise((res) => out.end(res));
      me.step = "checking";
      if (hash.digest("hex") !== latest.zip.sha256) return fail("the download didn't match its checksum");
      // Every path must stay inside the staging folder (FR-232).
      const list = execFileSync(TAR, ["-tf", zipPath], { encoding: "utf8" }).split(/\r?\n/).filter(Boolean);
      if (!list.length || list.some((p) => path.isAbsolute(p) || /^[a-zA-Z]:/.test(p) || p.split(/[\\/]/).includes(".."))) return fail("the download contains paths that aren't allowed");
      if (me.abort.signal.aborted) return save({ progress: null });
      me.step = "installing"; // from here on there's no Cancel
      fs.mkdirSync(stage);
      execFileSync(TAR, ["-xf", zipPath, "-C", stage]);
      const rel = readJson(path.join(stage, "release.json"), null);
      if (rel?.version !== latest.version) return fail("the download isn't the release it says it is");
      const files = list.filter((p) => !p.endsWith("/")).map((p) => p.replaceAll("\\", "/"));
      if (files.some((p) => NEVER_TOUCH.test(p))) return fail("the download contains folders that aren't allowed");
      // Replace the tracked app files; delete the ones the release removed; leave data, .deploy, node_modules and untracked files.
      const tracked = git("ls-files", "-z").split("\0").filter(Boolean);
      const gone = tracked.filter((p) => !files.includes(p) && !NEVER_TOUCH.test(p));
      const head = git("rev-parse", "HEAD");
      try {
        for (const f of files) { const to = path.join(ROOT, f); fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(path.join(stage, f), to); }
        for (const f of gone) fs.rmSync(path.join(ROOT, f), { force: true });
        for (let i = 0; i < files.length; i += 100) git("add", "--", ...files.slice(i, i + 100));
        for (let i = 0; i < gone.length; i += 100) git("rm", "-q", "--cached", "--ignore-unmatch", "--", ...gone.slice(i, i + 100));
        git("-c", "user.name=Claude Studio updater", "-c", "user.email=updater@localhost", "commit", "-q", "--allow-empty", "-m", `Update to v${latest.version.replace(/\.0$/, "")}`);
      } catch (e) {
        try { git("reset", "-q", "--hard", head); } catch {}
        return fail("the new files couldn't be put in place: " + String(e?.stderr || e?.message || e).slice(0, 200));
      }
      // Deploy, wait for the new version and roll back if needed: in a helper that outlives this server's restart.
      // The helper installs the new release (npm ci, about a minute), then restarts; it updates the step itself.
      me.step = "restarting";
      save({ progress: { version: latest.version, step: "installing", startedAt: Date.now(), from: installed().version } });
      const helper = spawn(process.execPath, [path.join(APP_DIR, "scripts", "update-finish.mjs"), "--root", ROOT, "--data", DATA, "--port", String(PORT), "--to", latest.version, "--from", installed().version],
        { detached: true, stdio: "ignore", windowsHide: true });
      helper.unref();
      job = null; // from here on the helper owns the progress (updates.json)
    } catch (e) {
      if (me.abort.signal.aborted) return save({ progress: null });
      fail(String(e?.message || e).slice(0, 200));
    } finally {
      fs.rmSync(tmp, { recursive: true, force: true });
      if (job === me && me.step !== "restarting") job = null;
    }
  };

  // ---- routes (X-Studio is checked for every write by the app's guard) ----
  app.get("/api/updates", (req, res) => res.json(view()));
  app.post("/api/updates/check", async (req, res) => { if (!live) return res.status(409).json({ error: "Updates apply to LIVE." }); await check(); res.json(view()); });
  app.post("/api/updates/auto", (req, res) => { save({ auto: req.body?.on !== false }); res.json(view()); });
  app.post("/api/updates/dismiss", (req, res) => { const v = view().available?.version; if (v) save({ dismissed: v }); res.json(view()); });
  app.post("/api/updates/seen", (req, res) => { const s = load(); if (s.result) save({ result: { ...s.result, seen: true } }); res.json(view()); });
  app.post("/api/updates/apply", (req, res) => {
    const v = view();
    if (!live) return res.status(409).json({ error: "Updates apply to LIVE." });
    if (!v.available) return res.status(409).json({ error: "There's no newer version to install. Check for updates first." });
    if (busyNow()) return res.status(409).json({ code: "updating", error: "An update is already in progress." });
    const b = busy();
    if (b) return res.status(409).json({ code: "busy", error: `"${b}" is still working. Update when it's done.`, chat: b });
    let dirty;
    try { dirty = git("status", "--porcelain").split(/\r?\n/).filter(Boolean); } catch { return res.status(409).json({ error: "The Studio folder's git repository can't be read." }); }
    if (dirty.length) return res.status(409).json({ code: "dirty", count: dirty.length, error: `${dirty.length} file${dirty.length === 1 ? "" : "s"} changed in the Studio folder. Commit or discard ${dirty.length === 1 ? "it" : "them"} first, so the update doesn't overwrite ${dirty.length === 1 ? "it" : "them"}.` });
    job = { version: v.available.version, step: "downloading", abort: new AbortController(), done: 0, total: v.available.zip.size };
    save({ result: null });
    apply(v.available);
    res.status(202).json(view());
  });
  app.post("/api/updates/cancel", (req, res) => {
    if (job && ["downloading", "checking"].includes(job.step)) { job.abort.abort(); return res.json({ ...view(), progress: null }); } // the update tidies up itself
    res.status(409).json({ error: job ? "It's past the point where it can be cancelled." : "No update is running." });
  });
  // Go back to the previous release (after an update): the normal rollback, through the same helper.
  app.post("/api/updates/rollback", (req, res) => {
    if (!live) return res.status(409).json({ error: "Updates apply to LIVE." });
    if (busyNow()) return res.status(409).json({ error: "An update is in progress." });
    save({ progress: { step: "restarting", rollback: true, startedAt: Date.now(), from: installed().version } });
    spawn(process.execPath, [path.join(APP_DIR, "scripts", "update-finish.mjs"), "--root", ROOT, "--data", DATA, "--port", String(PORT), "--rollback", "--from", installed().version],
      { detached: true, stdio: "ignore", windowsHide: true }).unref();
    res.status(202).json(view());
  });
  return { updating: busyNow, releaseVersion: () => installed().version };
};
