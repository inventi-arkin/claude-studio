// Companions and places (spec worlds-v2 FR-206 to FR-213; before that, custom-world FR-143, FR-144, FR-151): the schemas
// Claude fills, the strict checks every companion and place passes before the page sees it or it is saved, and the
// readability adjustment. Both are data only: pixel rows, #rrggbb colours, a few enums and short strings. The page draws
// them with canvas pixels, <rect>s and textContent, so nothing in them is ever markup.

export const SCENE_ROLES = ["skyTop", "skyBottom", "cloud", "hillFar", "hill", "ground", "groundDetail", "accentA", "accentB", "accentC"];
export const FRAMES = ["stand", "walkA", "walkB", "happy", "blink"]; // v1 (v0.10), plus optional "sleep"
// v2 (worlds-v2 FR-217): every one required, all the same size.
export const FRAMES_V2 = ["idle1", "idle2", "walk1", "walk2", "walk3", "walk4", "blink", "happy", "sleep", "think", "surprised"];
export const LINE_KINDS = ["hello", "idle", "hover", "checkin", "thinking", "done", "sleepy", "happy"];
export const HILLS = ["rolling", "gentle", "flat", "jagged", "dunes"];
export const GROUNDS = ["grass", "sand", "snow", "stone", "soil"]; // FR-211; a place without one is grass
export const DEPTHS = ["far", "near"]; // FR-212; a decoration without one is near
export const DENSITY = ["few", "some", "many"];
export const MAX_WORLDS = 12; // per library (FR-206)
export const MAX_DECOR = 6;

const HEX = /^#[0-9a-fA-F]{6}$/;
const PCHAR = /^[a-zA-Z#]$/;
const NAME = /^[^\u0000-\u001f\u007f<>]{1,40}$/;

// ---------- the schemas for outputFormat (generator side) ----------
// Lists instead of maps (palette entries as { char, color }) because structured output is easiest with fixed keys;
// toCompanion() / toPlace() turn them into the stored shapes.
const str = (description) => ({ type: "string", description });
const rows = (description) => ({ type: "array", items: { type: "string" }, description });
const colours = { type: "object", additionalProperties: false, required: SCENE_ROLES, properties: Object.fromEntries(SCENE_ROLES.map((k) => [k, str("#rrggbb")])) };
const CREATURE = {
  type: "object", additionalProperties: false, required: ["palette", "width", "height", "frames"],
  properties: {
    palette: { type: "array", description: "3-12 entries, including char 'o' for the outline. char is one letter a-z, A-Z or #; color is #rrggbb. '.' is always transparent.",
      items: { type: "object", additionalProperties: false, required: ["char", "color"], properties: { char: str("one character"), color: str("#rrggbb") } } },
    width: { type: "integer", description: "16-32; 24 is best" },
    height: { type: "integer", description: "16-32; 24 is best" },
    frames: {
      type: "object", additionalProperties: false, required: FRAMES_V2,
      properties: Object.fromEntries(FRAMES_V2.map((f) => [f, rows(`Exactly height rows of exactly width characters (${f}).`)])),
    },
  },
};
const LINES = { type: "object", additionalProperties: false, required: LINE_KINDS, properties: Object.fromEntries(LINE_KINDS.map((k) => [k, rows("1-4 short lines, each 1-60 characters.")])) };
const SCENE = {
  type: "object", additionalProperties: false, required: ["light", "dark", "hills", "ground", "decor"],
  properties: {
    light: colours, dark: colours,
    hills: { type: "string", enum: HILLS },
    ground: { type: "string", enum: GROUNDS },
    decor: { type: "array", description: `0-${MAX_DECOR} kinds of plants or objects.`, items: {
      type: "object", additionalProperties: false, required: ["palette", "width", "height", "rows", "density", "depth"],
      properties: {
        palette: { type: "array", description: "1-4 entries mapping a character to a scene colour role, so decorations follow light and dark.",
          items: { type: "object", additionalProperties: false, required: ["char", "role"], properties: { char: str("one character"), role: { type: "string", enum: SCENE_ROLES } } } },
        width: { type: "integer", description: "3-16" }, height: { type: "integer", description: "3-24" },
        rows: rows("Exactly height rows of exactly width characters; the bottom row stands on the ground."),
        density: { type: "string", enum: DENSITY },
        depth: { type: "string", enum: DEPTHS },
      },
    } },
  },
};
export const COMPANION_SCHEMA = {
  type: "object", additionalProperties: false, required: ["name", "creature", "lines"],
  properties: { name: str("The companion's name, 1-40 characters."), creature: CREATURE, lines: LINES },
};
export const PLACE_SCHEMA = {
  type: "object", additionalProperties: false, required: ["name", "scene"],
  properties: { name: str("The place's name, 1-40 characters."), scene: SCENE },
};

const REFUSE = "If the description asks for something hateful, sexual or violent, refuse briefly in plain text instead.";
export const COMPANION_PROMPT = `You design a tiny pixel-art companion for Claude Studio, a local app. You output data only, through the structured output; never code, SVG or HTML.

Creature
- Side view, facing right, feet on the lowest rows, centred. width and height 24 (16-32 allowed). Every frame has exactly height rows of exactly width characters, using '.' for transparent and only characters from the palette. Keep the top 3-5 rows mostly free for raised arms, ears or a thought, but otherwise fill the frame: with its outline the creature spans at least 18 of the 24 columns and 16 of the rows, like the example below.
- palette: 3-12 colours. 'o' is a dark outline drawn 1 pixel all round the creature. Shade the main colour in three tones (light along the top and left, base, shadow along the bottom and right), plus eyes with a 1-pixel highlight. The silhouette must read at 48 pixels tall.
- Frames: idle1 (standing), idle2 (the body 1 pixel lower, feet in place: breathing), walk1 (left legs forward and lifted), walk2 (passing, body 1 pixel lower), walk3 (right legs forward), walk4 (passing), blink (eyes closed), happy (arms or ears up, happy eyes), sleep (eyes closed, slumped 1 pixel), think (eyes looking up, two small dots above one shoulder), surprised (wide eyes, small round mouth).
- An example of the format only (Claude's idle1, 24x24, palette o outline, l light, b base, s shadow, e eyes, w highlight); draw your own creature in its own style:
  ........................
  ........................
  ........................
  ........................
  ........................
  ......oooooooooooo......
  .....obbbbbbbbbbbbo.....
  ....oblllllllbbbbbbo....
  ...oblbbbbbbbbbbbbbbo...
  ...oblbbwebbbbwebbsso...
  ...oblbbeebbbbeebbsso...
  .oooblbbeebbbbeebbssooo.
  obbbblbbbbbbbbbbbbssbbbo
  obbbbbbbbbbbbbbbbbssbbbo
  osssbbbbbbbbbbbbbbssssso
  .ooobbbbbbbbbbbbbbssooo.
  ...obbbbbbbbbbbbbbsso...
  ...obssssssssssssssso...
  ....osssssssssssssso....
  .....oboobooooboobo.....
  .....oboobo..oboobo.....
  .....oboobo..oboobo.....
  .....osooso..osooso.....
  ......o..o....o..o......

Lines: short and friendly, in the companion's own voice; no links or markup. hello greets the user, idle may include {greeting} (replaced by Good morning / afternoon / evening), hover reacts to the pointer, checkin checks on the user, thinking is shown while Claude works, done when a reply finishes, sleepy late at night, happy when clicked.

${REFUSE}`;
export const PLACE_PROMPT = `You design a pixel-art place for Claude Studio, a local app: the landscape a companion walks in. You output data only, through the structured output; never code, SVG or HTML.

Colours: light and dark palettes for the same place, by day and by night.
- Light: a light sky (skyTop and skyBottom) so dark text on it stays readable. Dark: a dark sky so light text stays readable.
- cloud is clouds by day and the star tint by night. hillFar is the far hill layer and hill the near one (the middle layer is mixed from both), ground is the walking surface, groundDetail its texture, accentA to accentC colour plants and objects.
- hills is the skyline shape. ground is the ground texture: grass, sand, snow, stone or soil.

Decorations: 0-6 kinds of plants or objects (trees, bushes, flowers, rocks, cacti, shells, lamps…). Each has a palette of scene roles, not colours, so it follows day and night. depth "far" kinds are drawn small and hazy on the far hills (trees, towers: 5-9 wide, 6-12 high); "near" kinds stand on the ground (up to 16 wide and 24 high; trees 10-16 wide, 12-20 high; flowers and rocks 3-6). Give near trees a trunk and a canopy with a lighter and a darker role.

${REFUSE}`;

// ---------- checks (generated, saved and imported shapes all end here) ----------
const checkRows = (r, w, h, chars, what) => {
  if (!Array.isArray(r) || r.length !== h) return `${what} has ${Array.isArray(r) ? r.length : 0} rows; expected ${h}.`;
  for (let i = 0; i < h; i++) {
    if (typeof r[i] !== "string" || r[i].length !== w) return `${what} row ${i + 1} has ${typeof r[i] === "string" ? r[i].length : 0} characters; expected ${w}.`;
    for (const c of r[i]) if (c !== "." && !chars.has(c)) return `${what} uses "${c}", which isn't in its palette.`;
  }
  return null;
};
const isInt = (n, lo, hi) => Number.isInteger(n) && n >= lo && n <= hi;
const only = (o, keys, what) => { const extra = Object.keys(o).find((k) => !keys.includes(k)); return extra ? `${what} has an unknown field "${extra}".` : null; };
const isObj = (o) => o && typeof o === "object" && !Array.isArray(o);
const checkName = (n) => (typeof n !== "string" || !NAME.test(n.trim()) ? "The name must be 1-40 characters." : null);
// v2 (FR-217): 16-32 square-ish, 3-12 colours with an outline 'o', all 11 frames.
const checkCreatureV2 = (c) => {
  let p;
  if ((p = only(c, ["version", "palette", "width", "height", "frames"], "The creature"))) return p;
  if (!isInt(c.width, 16, 32) || !isInt(c.height, 16, 32)) return "The creature must be 16-32 pixels wide and high.";
  if (!isObj(c.palette)) return "The creature's palette is missing.";
  const pal = Object.entries(c.palette);
  if (pal.length < 3 || pal.length > 12) return "The creature's palette must have 3-12 colours.";
  for (const [k, v] of pal) if (!PCHAR.test(k) || typeof v !== "string" || !HEX.test(v)) return `Palette entry "${k}" must be a letter or # with a #rrggbb colour.`;
  if (!c.palette.o) return "The creature's palette needs an outline colour 'o'.";
  if (!isObj(c.frames)) return "The creature's frames are missing.";
  if ((p = only(c.frames, FRAMES_V2, "The frames"))) return p;
  const chars = new Set(Object.keys(c.palette));
  for (const f of FRAMES_V2) if ((p = checkRows(c.frames[f], c.width, c.height, chars, `Frame ${f}`))) return p;
  return null;
};
const checkCreature = (c) => {
  let p;
  if (!isObj(c)) return "The creature is missing.";
  if (c.version === 2) return checkCreatureV2(c);
  if ((p = only(c, ["palette", "width", "height", "frames"], "The creature"))) return p;
  if (!isInt(c.width, 8, 24) || !isInt(c.height, 8, 24)) return "The creature must be 8-24 pixels wide and high.";
  if (!isObj(c.palette)) return "The creature's palette is missing.";
  const pal = Object.entries(c.palette);
  if (pal.length < 2 || pal.length > 8) return "The creature's palette must have 2-8 colours.";
  for (const [k, v] of pal) if (!PCHAR.test(k) || typeof v !== "string" || !HEX.test(v)) return `Palette entry "${k}" must be a letter or # with a #rrggbb colour.`;
  if (!isObj(c.frames)) return "The creature's frames are missing.";
  if ((p = only(c.frames, [...FRAMES, "sleep"], "The frames"))) return p;
  const chars = new Set(Object.keys(c.palette));
  for (const f of [...FRAMES, ...(c.frames.sleep ? ["sleep"] : [])]) if ((p = checkRows(c.frames[f], c.width, c.height, chars, `Frame ${f}`))) return p;
  return null;
};
const checkLines = (l) => {
  let p;
  if (!isObj(l)) return "The lines are missing.";
  if ((p = only(l, LINE_KINDS, "The lines"))) return p;
  for (const k of LINE_KINDS) {
    if (!Array.isArray(l[k]) || l[k].length < 1 || l[k].length > 4) return `lines.${k} must have 1-4 lines.`;
    for (const t of l[k]) if (typeof t !== "string" || !t.trim() || t.length > 60 || /[\u0000-\u001f]/.test(t)) return `Each of lines.${k} must be 1-60 characters.`;
  }
  return null;
};
// ground and depth are optional, so places from v0.10 (and their files) still pass (FR-213).
const checkScene = (s) => {
  let p;
  if (!isObj(s)) return "The scene is missing.";
  if ((p = only(s, ["light", "dark", "hills", "ground", "decor"], "The scene"))) return p;
  for (const t of ["light", "dark"]) {
    if (!isObj(s[t])) return `The ${t} colours are missing.`;
    if ((p = only(s[t], SCENE_ROLES, `The ${t} colours`))) return p;
    for (const k of SCENE_ROLES) if (typeof s[t][k] !== "string" || !HEX.test(s[t][k])) return `${t}.${k} must be a #rrggbb colour.`;
  }
  if (!HILLS.includes(s.hills)) return `hills must be one of ${HILLS.join(", ")}.`;
  if (s.ground != null && !GROUNDS.includes(s.ground)) return `ground must be one of ${GROUNDS.join(", ")}.`;
  if (!Array.isArray(s.decor) || s.decor.length > MAX_DECOR) return `There can be at most ${MAX_DECOR} decorations.`;
  for (const [i, d] of s.decor.entries()) {
    const what = `Decoration ${i + 1}`;
    if (!isObj(d)) return `${what} must be an object.`;
    if ((p = only(d, ["palette", "width", "height", "rows", "density", "depth"], what))) return p;
    if (!isInt(d.width, 3, 16) || !isInt(d.height, 3, 24)) return `${what} must be 3-16 pixels wide and 3-24 high.`;
    if (d.depth != null && !DEPTHS.includes(d.depth)) return `${what} depth must be far or near.`;
    if (!isObj(d.palette)) return `${what} has no palette.`;
    const dp = Object.entries(d.palette);
    if (dp.length < 1 || dp.length > 4) return `${what} must have 1-4 colours.`;
    for (const [k, v] of dp) if (!PCHAR.test(k) || !SCENE_ROLES.includes(v)) return `${what} palette entry "${k}" must name a scene colour.`;
    if (!DENSITY.includes(d.density)) return `${what} density must be few, some or many.`;
    if ((p = checkRows(d.rows, d.width, d.height, new Set(Object.keys(d.palette)), what))) return p;
  }
  return null;
};
// Each returns the first problem or null.
export const checkCompanion = (c) => {
  if (!isObj(c)) return "A companion must be an object.";
  return only(c, ["name", "creature", "lines"], "The companion") || checkName(c.name) || checkCreature(c.creature) || checkLines(c.lines);
};
export const checkPlace = (p) => {
  if (!isObj(p)) return "A place must be an object.";
  return only(p, ["name", "scene"], "The place") || checkName(p.name) || checkScene(p.scene);
};
// A v0.10 world (old files and the old library): both halves together.
export const checkWorld = (w) => {
  if (!isObj(w)) return "A world must be an object.";
  return only(w, ["name", "creature", "scene", "lines"], "The world") || checkName(w.name) || checkCreature(w.creature) || checkScene(w.scene) || checkLines(w.lines);
};

// Generated (list) shapes → stored shapes. Unknown fields are dropped here; the checks then see only known ones.
const map = (list, val) => (Array.isArray(list) ? Object.fromEntries(list.filter(isObj).map((e) => [e.char, e[val]])) : list);
const name = (g) => (typeof g.name === "string" ? g.name.trim() : g.name);
// A generated frame that's a pixel or two off in size (a 25-character row in a 24-wide sprite is a common slip) is
// fitted rather than thrown away: empty pixels are trimmed or added at the edges, a row that is still too long
// loses its last characters, and characters that aren't in the palette become empty. Only for fresh generations; imported files are checked as they are.
const fitRows = (r, w, h, chars) => {
  if (!Array.isArray(r) || !Number.isInteger(w) || !Number.isInteger(h) || r.some((x) => typeof x !== "string")) return r;
  let rows = r.map((x) => {
    let s = [...x].map((ch) => (chars.has(ch) ? ch : ".")).join(""); // spaces and stray characters are empty pixels
    while (s.length > w && s.endsWith(".")) s = s.slice(0, -1);
    while (s.length > w && s.startsWith(".")) s = s.slice(1);
    return s.length > w ? s.slice(0, w) : s.padEnd(w, ".");
  });
  const empty = (x) => /^\.*$/.test(x);
  while (rows.length > h && empty(rows[rows.length - 1])) rows = rows.slice(0, -1);
  while (rows.length > h && empty(rows[0])) rows = rows.slice(1);
  if (rows.length > h) rows = rows.slice(rows.length - h);
  while (rows.length < h) rows = [".".repeat(w), ...rows];
  return rows;
};
// The generator answers in v2 (FR-217).
export const toCompanion = (g) => {
  if (!isObj(g)) return g;
  const c = g.creature || {}, f = c.frames || {};
  const chars = new Set(Array.isArray(c.palette) ? c.palette.map((e) => e?.char) : []);
  const frames = Object.fromEntries(FRAMES_V2.map((k) => [k, fitRows(f[k], c.width, c.height, chars)]));
  return { name: name(g), creature: { version: 2, palette: map(c.palette, "color"), width: c.width, height: c.height, frames },
    lines: isObj(g.lines) ? Object.fromEntries(LINE_KINDS.map((k) => [k, g.lines[k]])) : g.lines };
};
export const toPlace = (g) => {
  if (!isObj(g)) return g;
  const s = g.scene || {};
  const pick = (o) => (isObj(o) ? Object.fromEntries(SCENE_ROLES.map((k) => [k, o[k]])) : o);
  return { name: name(g), scene: { light: pick(s.light), dark: pick(s.dark), hills: s.hills, ground: s.ground,
    decor: Array.isArray(s.decor) ? s.decor.map((d) => ({ palette: map(d?.palette, "role"), width: d?.width, height: d?.height, rows: d?.rows, density: d?.density, depth: d?.depth })) : s.decor } };
};

// ---------- readability (custom-world FR-151) ----------
const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const lum = (h) => { const c = rgb(h).map((v) => v / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
export const contrast = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
const mix = (a, b, t) => "#" + rgb(a).map((v, i) => Math.round(v + (rgb(b)[i] - v) * t).toString(16).padStart(2, "0")).join("");
// The page text of every style (theme.css): the greeting must read against the sky in each.
const TEXT = { light: ["#18181b", "#2a2520", "#111820"], dark: ["#ededf0", "#efe8dc", "#e6edf3"] };
// The Meadow (styles.css): where an unreadable colour is moved towards.
const MEADOW = {
  light: { skyTop: "#9fd0f5", skyBottom: "#e6f4fd", hill: "#86bd7c", ground: "#9ccc72" },
  dark: { skyTop: "#070b18", skyBottom: "#1b2442", hill: "#1f3a2e", ground: "#1f3328" },
};
const fit = (colour, target, need, theme) => {
  for (let t = 0; t <= 1.0001; t += 0.1) {
    const c = t ? mix(colour, target, Math.min(1, t)) : colour;
    if (TEXT[theme].every((x) => contrast(c, x) >= need)) return c;
  }
  return target;
};
// Returns a copy of a place (or v0.10 world) with sky (4.5:1 against the greeting) and hill/ground (3:1 against chat
// text) adjusted where needed.
export const readable = (w) => {
  const out = structuredClone(w);
  for (const t of ["light", "dark"]) {
    for (const k of ["skyTop", "skyBottom"]) out.scene[t][k] = fit(out.scene[t][k], MEADOW[t][k], 4.5, t);
    for (const k of ["hill", "ground"]) out.scene[t][k] = fit(out.scene[t][k], MEADOW[t][k], 3, t);
  }
  return out;
};
