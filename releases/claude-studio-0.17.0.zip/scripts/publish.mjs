// Publishes a release of Claude Studio to the public website (spec updates FR-222 to FR-226, design updates §2, D-4).
// Usage: npm run publish-release                     asks for the version, title and notes
//        npm run publish-release -- --version 0.17.0 --title "Website and updates" --notes "line one|line two"
//        npm run publish-release -- --dry-run          builds everything into the site folder, pushes nothing
//        npm run publish-release -- --push             only pushes the site folder again (after a failed push)
// What it does: checks that LIVE runs this clean, committed HEAD; writes release.json and the package version; commits
// "Release v<version>" and deploys it; zips a snapshot of the app files (no history, specs, designs, tests or site);
// writes latest.json, signs it, renders the website and pushes it to the public repository's main branch (GitHub Pages).
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import readline from "node:readline/promises";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { PRIVATE_KEY, KEY_DIR } from "./release-key.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SITE_SRC = path.join(ROOT, "site");
const REMOTE = "https://github.com/inventi-arkin/claude-studio.git";
const SITE_URL = "https://inventi-arkin.github.io/claude-studio/";
const KEEP_ZIPS = 5;
const EXCLUDE = ["specs", "design", "tests", "site"]; // never published (FR-223, FR-224)
const PUBLISHER = ["-c", "user.name=Claude Studio releases", "-c", "user.email=inventi-arkin@users.noreply.github.com"];

const args = process.argv.slice(2);
const flag = (n) => args.includes(`--${n}`);
const opt = (n) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : undefined; };
const SITE_DIR = path.resolve(opt("site-dir") || path.join(KEY_DIR, "site"));
const fail = (msg) => { console.error(`\n✗ ${msg}`); process.exit(1); };
const git = (cwd, ...a) => execFileSync("git", a, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
const run = (cmd, a, cwd = ROOT) => execFileSync(cmd, a, { cwd, stdio: "inherit", shell: process.platform === "win32" && cmd === "npm" });
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
const cmpVersion = (a, b) => { const p = (v) => String(v).split(".").map((n) => Number(n) || 0); const x = p(a), y = p(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const short = (v) => String(v).replace(/\.0$/, "");
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

const push = () => {
  console.log(`Pushing the website to ${REMOTE}…`);
  try { execFileSync("git", ["push", "-u", "origin", "main"], { cwd: SITE_DIR, stdio: "inherit" }); }
  catch {
    fail(`The push didn't go through. The release is built in ${SITE_DIR}.\n  1. Make sure the public repository exists: https://github.com/new → owner inventi-arkin, name claude-studio, Public, empty (no README).\n  2. Run: npm run publish-release -- --push   (Git asks you to sign in to GitHub the first time.)`);
  }
  console.log(`\n✓ Published. The site updates in a minute or two: ${SITE_URL}`);
  console.log("  First time only: on GitHub, open the repository's Settings → Pages, choose \"Deploy from a branch\", branch main, folder / (root), and Save.\n  (The main branch only exists after this first push, so it can't be chosen before.)");
};
if (flag("push")) { push(); process.exit(0); }

// ---- 1. checks (FR-223, AC-134) ----
if (git(ROOT, "status", "--porcelain")) fail("The working tree has uncommitted changes. Commit them first: only committed, deployed code can be published.");
const head = git(ROOT, "rev-parse", "--short", "HEAD");
const live = readJson(path.join(ROOT, ".deploy", "current.json"), null);
if (live?.sha !== head) fail(`LIVE runs ${live?.version || "nothing"}, not HEAD (${head}). Deploy and test HEAD first (npm run deploy), then publish.`);
if (!fs.existsSync(PRIVATE_KEY)) fail(`No release key at ${PRIVATE_KEY}. Make one once with: node scripts/release-key.mjs`);
const current = readJson(path.join(ROOT, "release.json"), { version: "0" });

// ---- 2. version, title and notes ----
// Without a console to answer in (for example Claude Code's "!" shell), everything must come as options.
if (!process.stdin.isTTY && !(opt("version") && opt("title") && (opt("notes") || opt("notes-file"))))
  fail('Nothing can answer questions here. Run it in a terminal, or pass everything:\n  npm run publish-release -- --version 0.17.0 --title "Website and updates" --notes "first line|second line"');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = async (q, d) => (opt(q.key) ?? ((await rl.question(`${q.text}${d ? ` [${d}]` : ""}: `)).trim() || d));
const next = (() => { const [a, b] = String(current.version).split(".").map(Number); return `${a || 0}.${(b || 0) + 1}.0`; })();
const version = await ask({ key: "version", text: `Version (now ${current.version})` }, next);
if (!/^\d+\.\d+\.\d+$/.test(version)) fail("The version must look like 0.17.0.");
if (cmpVersion(version, current.version) <= 0) fail(`v${version} isn't newer than the current v${current.version}.`);
const title = await ask({ key: "title", text: "Title (a few words)" });
if (!title || title.length > 60) fail("Give a title of 1-60 characters.");
let notes = opt("notes") ? opt("notes").split("|") : opt("notes-file") ? fs.readFileSync(opt("notes-file"), "utf8").split(/\r?\n/) : null;
if (!notes) {
  notes = [];
  console.log("Release notes, one line each (up to 10); an empty line ends:");
  for (let i = 0; i < 10; i++) { const l = (await rl.question("  • ")).trim(); if (!l) break; notes.push(l); }
}
rl.close();
notes = notes.map((n) => n.trim()).filter(Boolean).slice(0, 10);
if (!notes.length) fail("Give at least one line of release notes.");
const date = new Date().toISOString().slice(0, 10);

// ---- 3. release commit, deployed so this PC runs what it publishes ----
fs.writeFileSync(path.join(ROOT, "release.json"), JSON.stringify({ version, title, date, notes }, null, 2) + "\n");
run("npm", ["version", version, "--no-git-tag-version", "--allow-same-version"]);
git(ROOT, "add", "release.json", "package.json", "package-lock.json");
git(ROOT, "commit", "-m", `Release v${short(version)}: ${title}`);
try { git(ROOT, "tag", `v${version}`); } catch {}
run(process.execPath, [path.join(ROOT, "scripts", "deploy.mjs")]);

// ---- 4. the snapshot zip ----
const out = path.join(SITE_DIR, "releases");
fs.mkdirSync(out, { recursive: true });
const zipName = `claude-studio-${version}.zip`, zipPath = path.join(out, zipName);
git(ROOT, "archive", "--format=zip", `--output=${zipPath}`, "HEAD", "--", ".", ...EXCLUDE.map((e) => `:(exclude)${e}`));
const zip = fs.readFileSync(zipPath);
const sha256 = crypto.createHash("sha256").update(zip).digest("hex");

// ---- 5. latest.json, signed ----
const prev = readJson(path.join(SITE_DIR, "latest.json"), null);
const history = [{ version, title, date, notes }, ...(prev?.history || []).filter((h) => h.version !== version)].slice(0, 20);
const latest = { format: "claude-studio-release", version, title, date, notes, zip: { name: zipName, url: `releases/${zipName}`, size: zip.length, sha256 }, history };
const latestText = JSON.stringify(latest, null, 2) + "\n";
const key = crypto.createPrivateKey(fs.readFileSync(PRIVATE_KEY));
fs.writeFileSync(path.join(SITE_DIR, "latest.json"), latestText);
fs.writeFileSync(path.join(SITE_DIR, "latest.json.sig"), crypto.sign(null, Buffer.from(latestText), key).toString("base64") + "\n");

// ---- 6. the website ----
const LOGO = ["......oooooooooooo......", ".....obbbbbbbbbbbbo.....", "....oblllllllbbbbbbo....", "...oblbbbbbbbbbbbbbbo...", "...oblbbwebbbbwebbsso...", "...oblbbeebbbbeebbsso...",
  ".oooblbbeebbbbeebbssooo.", "obbbblbbbbbbbbbbbbssbbbo", "obbbbbbbbbbbbbbbbbssbbbo", "osssbbbbbbbbbbbbbbssssso", ".ooobbbbbbbbbbbbbbssooo.", "...obbbbbbbbbbbbbbsso...",
  "...obssssssssssssssso...", "....osssssssssssssso....", ".....oboobooooboobo.....", ".....oboobo..oboobo.....", ".....oboobo..oboobo.....", ".....osooso..osooso.....", "......o..o....o..o......"];
const PAL = { o: "#4a1f12", s: "#b5583c", b: "#d97757", l: "#f2a07f", e: "#1f1410", w: "#fff4ec" };
const rects = LOGO.flatMap((r, y) => [...r].map((c, x) => (PAL[c] ? `<rect x="${x}" y="${y}" width="1" height="1" fill="${PAL[c]}"/>` : ""))).join("");
const svg = (size, aria) => `<svg width="${size}" height="${Math.round(size * 19 / 24)}" viewBox="0 0 24 19" shape-rendering="crispEdges"${aria ? "" : ' aria-hidden="true"'}>${rects}</svg>`;
const longDate = (d) => new Date(d + "T12:00:00Z").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
const notesHtml = history.map((h, i) => `<details class="rel"${i === 0 ? " open" : ""}><summary><b>v${esc(short(h.version))}</b><span>${esc(h.title)} · ${esc(longDate(h.date))}</span>${i === 0 ? '<span class="tag">Latest</span>' : ""}</summary>
      <ul>${h.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></details>`).join("\n    ");
const html = fs.readFileSync(path.join(SITE_SRC, "index.html"), "utf8")
  .replaceAll("{{LOGO_SVG}}", svg(32)).replaceAll("{{LOGO_ICON}}", encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 19" shape-rendering="crispEdges">${rects}</svg>`))
  .replaceAll("{{ZIP_URL}}", `releases/${zipName}`).replaceAll("{{ZIP_NAME}}", zipName).replaceAll("{{ZIP_SIZE}}", `${(zip.length / 1048576).toFixed(1)} MB`)
  .replaceAll("{{VERSION_SHORT}}", esc(short(version))).replaceAll("{{DATE_LONG}}", esc(longDate(date))).replaceAll("{{NOTES_HTML}}", notesHtml);
fs.writeFileSync(path.join(SITE_DIR, "index.html"), html);
for (const f of ["site.css", "screenshot.png"]) fs.copyFileSync(path.join(SITE_SRC, f), path.join(SITE_DIR, f));
fs.writeFileSync(path.join(SITE_DIR, ".nojekyll"), "");
// The last few zips stay (installed PCs may still be downloading an older one); older ones go.
const zips = fs.readdirSync(out).filter((f) => /^claude-studio-[\d.]+\.zip$/.test(f)).sort((a, b) => cmpVersion(b.slice(14, -4), a.slice(14, -4)));
for (const old of zips.slice(KEEP_ZIPS)) fs.rmSync(path.join(out, old));

// ---- 7. the public repository: one commit per release, by a neutral author (FR-224) ----
if (!fs.existsSync(path.join(SITE_DIR, ".git"))) { git(SITE_DIR, "init", "-b", "main"); git(SITE_DIR, "remote", "add", "origin", REMOTE); }
git(SITE_DIR, "add", "-A");
git(SITE_DIR, ...PUBLISHER, "commit", "-m", `Claude Studio v${short(version)}: ${title}`);
console.log(`\nBuilt v${short(version)} in ${SITE_DIR}: ${zipName} (${(zip.length / 1048576).toFixed(1)} MB, sha256 ${sha256.slice(0, 12)}…), latest.json signed, website rendered.`);
if (flag("dry-run")) { console.log("Dry run: nothing pushed. Push later with: npm run publish-release -- --push"); process.exit(0); }
push();
