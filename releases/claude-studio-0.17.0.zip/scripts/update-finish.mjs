// Finishes an update (spec updates FR-232 to FR-234): deploys the Studio folder's new commit, waits for LIVE to report the
// new version and rolls back if it doesn't within 90 s. Started detached by updater.js from the release in use (known to
// work), so it outlives that server's restart. Also used for "Go back" (--rollback). Writes the outcome to updates.json.
// Usage: node update-finish.mjs --root <Studio folder> --data <LIVE data> --port 4300 --to 0.18.0 --from 0.17.0 [--rollback]
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

const opt = (n) => { const i = process.argv.indexOf(`--${n}`); return i >= 0 ? process.argv[i + 1] : undefined; };
const ROOT = opt("root"), DATA = opt("data"), PORT = opt("port") || "4300", TO = opt("to"), FROM = opt("from") || "?";
const ROLLBACK = process.argv.includes("--rollback");
const FILE = path.join(DATA, "updates.json"), LOG = path.join(DATA, "update.log");
const WAIT_MS = 90_000;
const log = (m) => { try { fs.appendFileSync(LOG, `${new Date().toISOString()} ${m}\n`); } catch {} };
const load = () => { try { return JSON.parse(fs.readFileSync(FILE, "utf8")); } catch { return {}; } };
const save = (patch) => { const s = { ...load(), ...patch }; fs.writeFileSync(FILE + ".tmp", JSON.stringify(s, null, 2)); fs.renameSync(FILE + ".tmp", FILE); };
const deploy = (...a) => execFileSync(process.execPath, [path.join(ROOT, "scripts", "deploy.mjs"), ...a], { cwd: ROOT, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// The version LIVE reports, or null while it's down.
const liveVersion = async () => { try { const r = await fetch(`http://127.0.0.1:${PORT}/api/info`, { signal: AbortSignal.timeout(3000) }); return (await r.json()).releaseVersion || null; } catch { return null; } };
// Counted in tries, not by the clock: if the PC sleeps meanwhile, the new version still gets its full 90 s after waking.
const waitFor = async (pred, ms) => { for (let i = 0; i < ms / 2000; i++) { const v = await liveVersion(); if (pred(v)) return v; await sleep(2000); } return null; };

const done = (result) => { log(JSON.stringify(result)); save({ progress: null, result: { ...result, at: Date.now() } }); };
try {
  if (ROLLBACK) {
    log(`going back from ${FROM}`);
    deploy("--rollback");
    const v = await waitFor((v) => v && v !== FROM, WAIT_MS);
    done(v ? { kind: "wentBack", from: FROM, to: v } : { kind: "failed", from: FROM, reason: "Going back didn't finish within 90 s." });
  } else {
    log(`deploying ${TO} (from ${FROM})`);
    const step = (s) => { const p = load().progress; if (p) save({ progress: { ...p, step: s, ...(s === "restarting" ? { restartAt: Date.now() } : {}) } }); };
    try { deploy(); step("restarting"); } catch (e) {
      // Nothing changed for LIVE: undo the update commit so the folder matches what runs.
      try { execFileSync("git", ["reset", "-q", "--hard", "HEAD~1"], { cwd: ROOT }); } catch {}
      done({ kind: "failed", from: FROM, to: TO, reason: "Installing failed: " + String(e?.stderr || e?.message || e).trim().split(/\r?\n/).slice(-3).join(" ").slice(0, 300) });
      process.exit(0);
    }
    const v = await waitFor((v) => v === TO, WAIT_MS);
    if (v) done({ kind: "updated", from: FROM, to: TO });
    else {
      log(`v${TO} didn't report back; rolling back`);
      try { deploy("--rollback"); } catch (e) { log("rollback failed: " + (e?.stderr || e?.message)); }
      await waitFor((v) => v === FROM, WAIT_MS);
      done({ kind: "rolledBack", from: FROM, to: TO, reason: `v${TO.replace(/\.0$/, "")} didn't report back within 90 s after restarting.` });
    }
  }
} catch (e) {
  done({ kind: "failed", from: FROM, to: TO, reason: String(e?.message || e).slice(0, 300) });
}
