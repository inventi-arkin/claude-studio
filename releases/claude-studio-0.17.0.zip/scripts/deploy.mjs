// Deploys a committed version of Claude Studio to the live channel (.deploy/releases/<sha>).
// Usage: node scripts/deploy.mjs            deploy HEAD (working tree must be clean)
//        node scripts/deploy.mjs <ref>      deploy a commit or tag
//        node scripts/deploy.mjs --rollback go back to the previous release
//        node scripts/deploy.mjs --list     show releases
//        node scripts/deploy.mjs --lock | --unlock   set or clear the Windows write lock on releases
// The live supervisor (scripts/live.mjs) watches .deploy/current.json and restarts on change.
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DEPLOY = path.join(ROOT, ".deploy");
const RELEASES = path.join(DEPLOY, "releases");
const CURRENT = path.join(DEPLOY, "current.json");
const HISTORY = path.join(DEPLOY, "history.json");
const git = (...args) => execFileSync("git", args, { cwd: ROOT, encoding: "utf8" }).trim();
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
const fail = (msg) => { console.error(msg); process.exit(1); };

// Windows write lock: a deny-write ACL for this user on .deploy/releases, so nothing but this
// script changes deployed code. It is lifted only while a release is exported and installed.
const WIN = process.platform === "win32";
const USER = os.userInfo().username;
const icacls = (...args) => execFileSync("icacls", [RELEASES, ...args], { stdio: "pipe" });
const unlock = () => { if (WIN && fs.existsSync(RELEASES)) icacls("/remove:d", USER); };
// Deny write data, append, write attributes and write extended attributes. That blocks writing, creating,
// renaming and deleting (deletes need WA), while Node can still read and run the files. Denying the generic
// W or D right also blocks Node's reads, so neither is used.
const lock = () => { if (WIN && fs.existsSync(RELEASES)) icacls("/deny", `${USER}:(OI)(CI)(WD,AD,WA,WEA)`); };

const history = readJson(HISTORY, []);
const current = readJson(CURRENT, null);
const arg = process.argv[2];

const activate = (entry, note) => {
  fs.writeFileSync(CURRENT, JSON.stringify(entry, null, 2));
  history.push({ ...entry, activatedAt: new Date().toISOString(), note });
  fs.writeFileSync(HISTORY, JSON.stringify(history, null, 2));
  console.log(`Live is now ${entry.version} (${entry.sha}). A running live server restarts by itself.`);
};

if (arg === "--list") {
  const seen = new Set();
  for (const h of [...history].reverse()) {
    if (seen.has(h.sha)) continue;
    seen.add(h.sha);
    console.log(`${h.sha === current?.sha ? "*" : " "} ${h.version}  ${h.subject || ""}`);
  }
  process.exit(0);
}

if (arg === "--lock" || arg === "--unlock") {
  (arg === "--lock" ? lock : unlock)();
  console.log(`Releases ${arg === "--lock" ? "locked" : "unlocked"}.`);
  process.exit(0);
}

if (arg === "--rollback") {
  const prev = [...history].reverse().find((h) => h.sha !== current?.sha && fs.existsSync(path.join(RELEASES, h.sha, ".ready")));
  if (!prev) fail("No earlier release to roll back to.");
  const { activatedAt, note, ...entry } = prev;
  activate(entry, "rollback");
  process.exit(0);
}

const ref = arg || "HEAD";
if (!arg && git("status", "--porcelain")) fail("Working tree has uncommitted changes. Commit them first (live only runs committed code), or pass a ref.");
let sha;
try { sha = git("rev-parse", "--short", `${ref}^{commit}`); } catch { fail(`Unknown ref: ${ref}`); }
const subject = git("log", "-1", "--format=%s", sha);
const date = git("log", "-1", "--format=%cd", "--date=format:%Y.%m.%d", sha);
const version = `v${date}-${sha}`;
const dir = path.join(RELEASES, sha);

// .ready marks a release that exported and installed fully; anything else is rebuilt from scratch.
if (!fs.existsSync(path.join(dir, ".ready"))) try {
  console.log(`Exporting ${sha} (${subject})…`);
  unlock();
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  const tar = path.join(DEPLOY, `${sha}.tar`);
  git("archive", "--format=tar", `--output=${tar}`, sha);
  // Relative path: GNU tar (Git Bash) reads "C:" in an absolute path as a remote host.
  execFileSync("tar", ["-xf", path.relative(dir, tar).replaceAll("\\", "/")], { cwd: dir, stdio: "inherit" });
  fs.rmSync(tar);
  console.log("Installing dependencies…");
  execFileSync(process.platform === "win32" ? "npm.cmd" : "npm", ["ci", "--omit=dev", "--no-audit", "--no-fund"], { cwd: dir, stdio: "inherit", shell: process.platform === "win32" });
  fs.writeFileSync(path.join(dir, ".ready"), new Date().toISOString());
} finally {
  lock();
}
activate({ sha, version, subject, deployedAt: new Date().toISOString() }, "deploy");
