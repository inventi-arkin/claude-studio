// Makes the release signing key pair once, on the publishing PC (spec updates FR-226).
// The private key goes to %USERPROFILE%\.claude-studio\release-key.pem and never into git; the public key is written to
// scripts/release-key.pub.js, which is committed so every installed Studio can check what it downloads.
// Usage: node scripts/release-key.mjs        (refuses if a key already exists)
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const KEY_DIR = path.join(os.homedir(), ".claude-studio");
export const PRIVATE_KEY = path.join(KEY_DIR, "release-key.pem");
const PUBLIC_FILE = path.join(ROOT, "scripts", "release-key.pub.js");

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (fs.existsSync(PRIVATE_KEY)) { console.error(`A release key already exists: ${PRIVATE_KEY}\nKeep using it; a new one would make every installed Studio refuse new releases.`); process.exit(1); }
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519");
  fs.mkdirSync(KEY_DIR, { recursive: true });
  fs.writeFileSync(PRIVATE_KEY, privateKey.export({ type: "pkcs8", format: "pem" }), { mode: 0o600 });
  const pub = publicKey.export({ type: "spki", format: "pem" }).trim();
  fs.writeFileSync(PUBLIC_FILE, `// The public half of the Claude Studio release key (spec updates FR-226). Installed Studios accept an update only if\n// its latest.json is signed with the matching private key, which stays on the publishing PC.\nexport const RELEASE_PUBLIC_KEY = \`${pub}\`;\n`);
  console.log(`Private key: ${PRIVATE_KEY} (back it up somewhere safe; never share it)\nPublic key:  ${path.relative(ROOT, PUBLIC_FILE)} (commit this)`);
}
