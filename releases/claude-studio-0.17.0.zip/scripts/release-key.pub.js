// The public half of the Claude Studio release key (spec updates FR-226). Installed Studios accept an update only if
// its latest.json is signed with the matching private key, which stays on the publishing PC.
export const RELEASE_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAP9JmYwdMDhyTfNR5YV2laRvHz9++Vzyk4FCeIPazGxo=
-----END PUBLIC KEY-----`;
