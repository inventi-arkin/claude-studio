<#
.SYNOPSIS
  Moves Claude Studio to another Windows device: the app and its git history only (no chats, no Home setup).

.DESCRIPTION
  The easy way: double-click "Export Claude Studio.cmd" in the Studio folder here, copy the zip to the other PC,
  unzip it and double-click "Install Claude Studio.cmd" there.

  On this PC:     powershell -ExecutionPolicy Bypass -File scripts\migrate.ps1 -Export
                  Packs the committed code (a git bundle of every branch) into one zip with a checksum and the
                  double-click installer. Uncommitted changes are not included, so the export stops if there are any.
  On the new PC:  powershell -ExecutionPolicy Bypass -File migrate.ps1 -Import <zip or unzipped folder>
                  Offers to install what is missing (Node.js LTS and Git with winget, Claude Code with its official
                  installer; it asks first) and opens the Claude sign-in when needed. Then clones Studio into
                  <ClaudeHome>\projects\Claude-Studio (creating an empty Home folder if there is none), runs npm ci
                  and npm run deploy, creates the "Claude Studio" desktop shortcut and starts LIVE on http://localhost:4300.
  Only Claude Studio moves: no chats, settings, skills or memory from this PC.
  Nothing is overwritten: the import stops if the Studio folder already exists.
  Claude credentials are never read or copied; the installer only checks that a sign-in exists.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File scripts\migrate.ps1 -Export
  powershell -ExecutionPolicy Bypass -File migrate.ps1 -Import C:\Users\me\Downloads\claude-studio-ee49cfa-2026-10-15.zip
#>
[CmdletBinding(DefaultParameterSetName = "Export")]
param(
  [Parameter(ParameterSetName = "Export", Mandatory = $true)] [switch] $Export,
  [Parameter(ParameterSetName = "Export")] [string] $OutDir,
  [Parameter(ParameterSetName = "Export")] [switch] $Open,
  [Parameter(ParameterSetName = "Import", Mandatory = $true)] [string] $Import,
  [Parameter(ParameterSetName = "Import")] [string] $ClaudeHome = "C:\claude",
  [Parameter(ParameterSetName = "Import")] [switch] $NoShortcut,
  [Parameter(ParameterSetName = "Import")] [switch] $NoStart,
  [Parameter(ParameterSetName = "Import")] [switch] $NoInstall
)
$ErrorActionPreference = "Stop"
$LivePort = 4300

function Step($text) { Write-Host "-> $text" -ForegroundColor Cyan }
function Done($text) { Write-Host "   $text" -ForegroundColor Green }
function Fail($text) { Write-Host "X  $text" -ForegroundColor Red; exit 1 }
function Run($exe, [string[]] $argList, $where) {
  Push-Location $where
  try { & $exe @argList; if ($LASTEXITCODE -ne 0) { Fail "$exe $($argList -join ' ') failed (exit $LASTEXITCODE)." } }
  finally { Pop-Location }
}
function Has($cmd) { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function Ask($question) {
  $a = Read-Host "   $question [Y/n]"
  return ($a -eq "" -or $a -match "^(y|yes)$")
}
# After an installer runs, pick up the new PATH (machine + user) and Claude Code's usual folder in this window.
function RefreshPath {
  $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User") + ";" + (Join-Path $env:USERPROFILE ".local\bin")
}
function NodeOk { if (-not (Has "node")) { return $false }; return ([int]((& node --version).TrimStart("v").Split(".")[0]) -ge 22) }
function Winget($id, $name) {
  if (-not (Has "winget")) { Fail "$name is needed, and winget (Windows' App Installer) isn't available to install it. Install $name yourself and run this again." }
  Step "Installing $name (winget)"
  & winget install -e --id $id --accept-source-agreements --accept-package-agreements
  if ($LASTEXITCODE -ne 0) { Fail "Installing $name failed (winget exit $LASTEXITCODE). Install it yourself and run this again." }
  RefreshPath
}

# ---------------------------------------------------------------- export
if ($PSCmdlet.ParameterSetName -eq "Export") {
  $app = Split-Path -Parent $PSScriptRoot
  if (-not (Test-Path (Join-Path $app ".git"))) { Fail "$app is not the Claude Studio git repo." }
  if (-not (Has "git")) { Fail "Git is not installed." }
  Step "Checking the working tree"
  $dirty = (& git -C $app status --porcelain)
  if ($dirty) { Fail "There are uncommitted changes in $app. Commit them first; the export only carries commits." }
  $sha = (& git -C $app rev-parse --short HEAD).Trim()
  $branch = (& git -C $app rev-parse --abbrev-ref HEAD).Trim()
  if (-not $OutDir) { $OutDir = Join-Path (Split-Path -Parent (Split-Path -Parent $app)) "output\migrate" }
  New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
  $stage = Join-Path ([IO.Path]::GetTempPath()) ("studio-export-" + [guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $stage | Out-Null
  try {
    Step "Bundling every branch at $sha ($branch)"
    $bundle = Join-Path $stage "claude-studio.bundle"
    Run "git" @("bundle", "create", "-q", $bundle, "--all") $app
    Copy-Item $PSCommandPath (Join-Path $stage "migrate.ps1")
    $manifest = [ordered]@{
      app = "Claude Studio"; commit = $sha; branch = $branch
      created = (Get-Date).ToString("s"); sourceNode = (& node --version)
      bundleSha256 = (Get-FileHash $bundle -Algorithm SHA256).Hash
    }
    ($manifest | ConvertTo-Json) | Out-File -Encoding ascii (Join-Path $stage "manifest.json")
    # The double-click installer: runs the import from the unzipped folder and keeps the window open at the end.
    @(
      "@echo off",
      "title Install Claude Studio",
      "powershell -NoProfile -ExecutionPolicy Bypass -File ""%~dp0migrate.ps1"" -Import ""%~dp0.""",
      "echo.",
      "pause"
    ) | Out-File -Encoding ascii (Join-Path $stage "Install Claude Studio.cmd")
    @(
      "Claude Studio $sha - install on this PC",
      "",
      "1. Unzip this file anywhere.",
      "2. Double-click 'Install Claude Studio.cmd'.",
      "   It offers to install what is missing (Node.js, Git, Claude Code) and asks before each,",
      "   opens the Claude sign-in if this PC isn't signed in yet, then sets up Studio,",
      "   puts a 'Claude Studio' shortcut on the desktop and opens it in the browser.",
      "",
      "Studio is installed in C:\claude\projects\Claude-Studio (C:\claude is created empty if it doesn't exist;",
      "Claude works inside it). Only Claude Studio is included: no chats, settings, skills or memory.",
      "",
      "Advanced: powershell -ExecutionPolicy Bypass -File migrate.ps1 -Import <this folder or zip>",
      "          options -ClaudeHome D:\claude, -NoShortcut, -NoStart, -NoInstall"
    ) | Out-File -Encoding ascii (Join-Path $stage "README.txt")
    $zip = Join-Path $OutDir ("claude-studio-$sha-" + (Get-Date -Format "yyyy-MM-dd") + ".zip")
    if (Test-Path $zip) { Remove-Item $zip }
    Step "Writing $zip"
    Compress-Archive -Path (Join-Path $stage "*") -DestinationPath $zip
    Done ("Done: {0} ({1:N1} MB). Copy it to the other PC, unzip it and double-click 'Install Claude Studio.cmd'." -f $zip, ((Get-Item $zip).Length / 1MB))
    if ($Open) { Start-Process explorer.exe "/select,`"$zip`"" }
  } finally { Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue }
  exit 0
}

# ---------------------------------------------------------------- import
$source = (Resolve-Path $Import).Path
RefreshPath
Step "Checking this PC"
# What Studio needs: Node.js 22+ (with npm), Git, and a signed-in Claude Code. Missing ones are offered, never forced.
if (-not (NodeOk)) {
  $why = if (Has "node") { "Node.js $(& node --version) is too old (Studio needs 22 or later)." } else { "Node.js is not installed." }
  if ($NoInstall -or -not (Ask "$why Install Node.js LTS now?")) { Fail "$why Install Node.js 22 or later from https://nodejs.org and run this again." }
  Winget "OpenJS.NodeJS.LTS" "Node.js LTS"
  if (-not (NodeOk)) { Fail "Node.js was installed but isn't found yet. Close this window and run the installer again." }
}
if (-not (Has "git")) {
  if ($NoInstall -or -not (Ask "Git is not installed. Install Git now?")) { Fail "Git is not installed. Install it from https://git-scm.com and run this again." }
  Winget "Git.Git" "Git"
  if (-not (Has "git")) { Fail "Git was installed but isn't found yet. Close this window and run the installer again." }
}
if (-not (Has "npm.cmd")) { Fail "npm was not found (it comes with Node.js). Reinstall Node.js and run this again." }
Done "Node $(& node --version), $(& git --version)"
if (-not (Has "claude")) {
  if (-not $NoInstall -and (Ask "Claude Code is not installed. Install it now (official installer from claude.ai)?")) {
    Step "Installing Claude Code"
    Invoke-RestMethod https://claude.ai/install.ps1 | Invoke-Expression
    RefreshPath
  }
  if (-not (Has "claude")) { Write-Host "   Claude Code isn't installed, so Studio will open but can't reply until it is (https://claude.com/claude-code)." -ForegroundColor Yellow }
}
# Signed in? Only whether a sign-in exists is checked; nothing is read.
$signedIn = (Test-Path (Join-Path $env:USERPROFILE ".claude\.credentials.json")) -or [bool]$env:ANTHROPIC_API_KEY
if ((Has "claude") -and -not $signedIn -and -not $NoInstall) {
  Write-Host "   Claude Code isn't signed in on this PC yet. A window opens: follow the steps to sign in, then close it." -ForegroundColor Yellow
  Start-Process cmd.exe -ArgumentList "/k claude" -Wait
  if (Test-Path (Join-Path $env:USERPROFILE ".claude\.credentials.json")) { Done "Signed in" }
  else { Write-Host "   Still not signed in; you can do it later by running 'claude' once." -ForegroundColor Yellow }
}

$stage = Join-Path ([IO.Path]::GetTempPath()) ("studio-import-" + [guid]::NewGuid().ToString("N"))
try {
  # The unzipped folder (the double-click installer) or the zip itself.
  if (Test-Path $source -PathType Container) { $from = $source }
  else { Step "Unpacking $source"; Expand-Archive -Path $source -DestinationPath $stage; $from = $stage }
  # Two kinds: a release from the website (the app files with release.json; spec updates FR-227), or an export of
  # this PC's history (manifest.json + a git bundle).
  $release = $null
  if (Test-Path (Join-Path $from "release.json")) {
    $release = Get-Content -Raw (Join-Path $from "release.json") | ConvertFrom-Json
    Done "Claude Studio v$($release.version) ($($release.title)), released $($release.date)"
  } else {
    if (-not (Test-Path (Join-Path $from "manifest.json"))) { Fail "$source isn't a Claude Studio release or export (no release.json or manifest.json)." }
    $manifest = Get-Content -Raw (Join-Path $from "manifest.json") | ConvertFrom-Json
    $bundle = Join-Path $from "claude-studio.bundle"
    if ((Get-FileHash $bundle -Algorithm SHA256).Hash -ne $manifest.bundleSha256) { Fail "The zip is damaged (checksum mismatch). Copy it again." }
    Done "Claude Studio $($manifest.commit), exported $($manifest.created); checksum OK"
  }

  # Studio needs a Claude Home: a folder with .claude\ and projects\ (the nearest one above the app is used).
  $ClaudeHome = [IO.Path]::GetFullPath($ClaudeHome)
  foreach ($sub in @(".claude", "projects")) {
    $p = Join-Path $ClaudeHome $sub
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Force -Path $p | Out-Null; Done "Created $p" }
  }
  $target = Join-Path $ClaudeHome "projects\Claude-Studio"
  $upgrade = $false
  if (Test-Path $target) {
    # A Studio from before v0.17 has no updater, so a release zip can upgrade it in place, once (spec updates AC-143,
    # QA F-4). Newer ones update themselves (Settings > Updates); anything else is never overwritten.
    if (-not $release -or (Test-Path (Join-Path $target "updater.js")) -or -not (Test-Path (Join-Path $target ".git"))) {
      Fail "$target already exists. Move it away (or pick another -ClaudeHome) and run again; nothing was changed. To get a newer version, use Settings > Updates in Studio."
    }
    Step "Found Claude Studio from before v0.17 in $target"
    if ((& git -C $target status --porcelain) ) { Fail "$target has changes that aren't committed. Commit or discard them first, then run this again; nothing was changed." }
    if (-not (Ask "Upgrade it to v$($release.version)? Your chats, companions, places and settings stay as they are.")) { Fail "Nothing was changed." }
    $upgrade = $true
  }

  if ($upgrade) {
    # The same as an update (updater.js): replace the tracked app files, delete the ones the release removed, never
    # touch data, .deploy, node_modules, specs, design, tests or site, and commit. LIVE switches on the deploy below.
    Step "Upgrading $target to v$($release.version)"
    $keep = '^(data|\.deploy|node_modules|specs|design|tests|site)(/|$)'
    $files = @(Get-ChildItem -Recurse -File -Force $from | ForEach-Object { $_.FullName.Substring($from.TrimEnd('\').Length + 1).Replace('\', '/') } | Where-Object { $_ -notmatch '^(node_modules|\.git|data|\.deploy)/' })
    $tracked = @(& git -C $target ls-files)
    $gone = @($tracked | Where-Object { $_ -notin $files -and $_ -notmatch $keep })
    foreach ($f in $files) {
      $to = Join-Path $target $f
      New-Item -ItemType Directory -Force -Path (Split-Path $to) | Out-Null
      Copy-Item -Force -LiteralPath (Join-Path $from $f) -Destination $to
    }
    foreach ($f in $gone) { Remove-Item -Force -LiteralPath (Join-Path $target $f) -ErrorAction SilentlyContinue }
    $list = Join-Path $stage "paths.txt"
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    [IO.File]::WriteAllLines($list, [string[]]$files)
    Run "git" @("add", "--pathspec-from-file=$list") $target
    if ($gone.Count) { [IO.File]::WriteAllLines($list, [string[]]$gone); Run "git" @("rm", "-q", "--cached", "--ignore-unmatch", "--pathspec-from-file=$list") $target }
    Run "git" @("-c", "user.name=Claude Studio installer", "-c", "user.email=installer@localhost", "commit", "-q", "--allow-empty", "-m", "Upgrade to v$($release.version)") $target
    Done "$($files.Count) files updated, $($gone.Count) removed; your data wasn't touched"
  } elseif ($release) {
    # A fresh local repository with the release as its first commit: updates add one commit each (updater.js).
    Step "Copying Claude Studio v$($release.version) to $target"
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    Get-ChildItem -Force $from | Where-Object { $_.Name -notin @("node_modules", ".git", "data", ".deploy") } | Copy-Item -Destination $target -Recurse -Force
    Run "git" @("init", "-q", "-b", "main") $target
    Run "git" @("add", "-A") $target
    Run "git" @("-c", "user.name=Claude Studio installer", "-c", "user.email=installer@localhost", "commit", "-q", "-m", "Install v$($release.version)") $target
  } else {
    Step "Cloning into $target"
    Run "git" @("clone", "-q", "--branch", $manifest.branch, $bundle, $target) $ClaudeHome
    Run "git" @("remote", "remove", "origin") $target
  }
  Step "Installing packages (npm ci, exactly as locked)"
  Run "npm.cmd" @("ci", "--no-audit", "--no-fund") $target
  Step "Building LIVE (npm run deploy)"
  Run "npm.cmd" @("run", "deploy") $target
} finally { Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue }

# The same shortcut as on the first PC: opens LIVE and starts it first when needed. The probe uses 127.0.0.1 because
# PowerShell tries IPv6 ::1 first for localhost and Studio listens on 127.0.0.1 only.
$probe = "http://127.0.0.1:$LivePort/api/info"
if (-not $NoShortcut) {
  Step "Creating the Claude Studio desktop shortcut"
  $lnk = Join-Path ([Environment]::GetFolderPath("Desktop")) "Claude Studio.lnk"
  $sc = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
  $sc.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
  $sc.Arguments = "-NoProfile -WindowStyle Hidden -Command `"`$u = 'http://localhost:$LivePort'; `$probe = '$probe'; try { Invoke-WebRequest -UseBasicParsing `$probe -TimeoutSec 2 | Out-Null } catch { Start-Process cmd.exe -ArgumentList '/c npm run live' -WorkingDirectory '$target' -WindowStyle Minimized; for (`$i = 0; `$i -lt 40; `$i++) { Start-Sleep -Milliseconds 500; try { Invoke-WebRequest -UseBasicParsing `$probe -TimeoutSec 2 | Out-Null; break } catch {} } }; Start-Process `$u`""
  $sc.WorkingDirectory = $target
  $sc.IconLocation = (Join-Path $target "public\claude.ico") + ",0"
  $sc.WindowStyle = 7
  $sc.Description = "Open Claude Studio (LIVE, http://localhost:$LivePort); starts it first if needed"
  $sc.Save()
  Done $lnk
}

if (-not $NoStart) {
  Step "Starting LIVE on port $LivePort"
  $up = $false
  try { Invoke-WebRequest -UseBasicParsing $probe -TimeoutSec 2 | Out-Null; $up = $true; Write-Host "   Something already answers on port $LivePort; not starting another server." -ForegroundColor Yellow } catch {}
  if (-not $up) {
    Start-Process cmd.exe -ArgumentList "/c npm run live" -WorkingDirectory $target -WindowStyle Minimized
    for ($i = 0; $i -lt 40 -and -not $up; $i++) { Start-Sleep -Milliseconds 500; try { Invoke-WebRequest -UseBasicParsing $probe -TimeoutSec 2 | Out-Null; $up = $true } catch {} }
  }
  if (-not $up) { Fail "LIVE did not answer on port $LivePort. Run 'npm run live' in $target to see why." }
  $info = Invoke-RestMethod $probe
  Done "LIVE $($info.version) is running with Claude Home $($info.home)"
  Start-Process "http://localhost:$LivePort"
}
Write-Host ""
Done "Claude Studio is installed in $target."
if ($release) { Write-Host "   New versions: Studio checks for them; see Settings > Updates." }
else { Write-Host "   DEV: run 'npm run dev' there (http://localhost:4310). Updates: commit there, then 'npm run deploy'." }
