// Away status: what chats are doing, from any page (spec specs/away-status.md FR-187 to FR-196, design
// design/away-status.md). Loaded after look.js and the page script (app.js or home.js). Uses $, el, store, activity,
// studioView, ago and the "studio-chats" event from the shared poller; on the chat page also state and scrollDown.

const AW_END = { done: "is done", stopped: "was stopped", error: "hit an error", interrupted: "was interrupted" };
const AW_WORD = { done: "Done", stopped: "Stopped", error: "Hit an error", interrupted: "Interrupted" };
const AW_ICON = { done: "✓", stopped: "■", error: "!", interrupted: "■" };
const awChatPage = !!$("messages");
const awVisible = () => document.visibilityState === "visible";
const awName = (p) => String(p).split(/[\\/]/).pop();
const awSince = (t) => {
  const s = Math.max(0, Math.round((Date.now() - t) / 1000));
  return s < 60 ? `${s}s` : s < 3600 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`;
};
// "Created 2 · changed 1: summary.md, chart.png, notes.md…" (FR-185). Empty when the turn touched no files.
const awFiles = (files, max = 3) => {
  if (!files?.length) return "";
  const made = files.filter((f) => f.kind === "created").length, changed = files.length - made;
  const counts = [made && `created ${made}`, changed && `changed ${changed}`].filter(Boolean).join(" · ");
  const names = files.slice(0, max).map((f) => awName(f.path)).join(", ") + (files.length > max ? ` +${files.length - max} more` : "");
  return counts[0].toUpperCase() + counts.slice(1) + ": " + names;
};

// ---------- seen and new (FR-187) ----------
const awSeen = () => store.get("seen", null);
const awMarkSeen = (id, at) => {
  if (!id || !at) return;
  const s = awSeen() || {};
  if ((s[id] || 0) >= at) return;
  s[id] = at;
  store.set("seen", Object.fromEntries(Object.entries(s).sort((a, b) => b[1] - a[1]).slice(0, 300)));
};
// New: the last turn ended after I last looked, and the chat isn't on screen in this tab right now.
const awIsNew = (c) => {
  const s = awSeen();
  if (!s || !c?.lastEnd || c.running || c.removed) return false;
  if (c.id === studioView.chatId && awVisible()) return false;
  return c.lastEnd.at > (s[c.id] || 0);
};
const awNewCount = (project) => activity.chats.filter((c) => (c.project || "General") === project && awIsNew(c)).length;

// ---------- the activity pill and its list (FR-188, FR-189) ----------
const awPill = el("button", "aw-pill");
awPill.type = "button";
awPill.hidden = true;
awPill.setAttribute("aria-haspopup", "true");
awPill.setAttribute("aria-expanded", "false");
$("openPalette")?.before(awPill);
let awList = null, awTick = null;
const awGroups = () => {
  const chats = activity.chats.filter((c) => !c.removed);
  return {
    wait: chats.filter((c) => c.waiting),
    work: chats.filter((c) => c.running && !c.waiting),
    fresh: chats.filter(awIsNew).sort((a, b) => b.lastEnd.at - a.lastEnd.at),
  };
};
const awRenderPill = () => {
  const g = awGroups();
  const n = { wait: g.wait.length, work: g.work.length, fresh: g.fresh.length };
  awPill.hidden = !(n.wait || n.work || n.fresh);
  if (awPill.hidden) { awCloseList(); return; }
  const kind = n.wait ? "wait" : n.work ? "work" : "new";
  awPill.className = "aw-pill " + kind;
  awPill.innerHTML = "";
  if (kind === "work") { const p = el("span", "pulse"); p.setAttribute("aria-hidden", "true"); awPill.append(p); }
  else awPill.append(el("span", null, kind === "wait" ? "▲" : "✓"));
  if (kind !== "wait") awPill.append(el("span", null, String(kind === "work" ? n.work : n.fresh)));
  awPill.append(el("span", "long", kind === "wait" ? "Needs you" : kind === "work" ? "working" : "new"));
  if (kind === "wait") awPill.append(el("span", "short", String(n.wait)));
  const parts = [n.wait && `${n.wait} needs you`, n.work && `${n.work} working`, n.fresh && `${n.fresh} new`].filter(Boolean);
  awPill.setAttribute("aria-label", "Activity: " + parts.join(", "));
  awPill.title = "Activity: " + parts.join(", ");
  if (awList) awFillList();
};
const awGo = (id) => {
  awCloseList();
  if (awChatPage) { location.hash = id; } else location.href = "/chat#" + id;
};
const awFillList = () => {
  const g = awGroups();
  awList.innerHTML = "";
  const group = (label, items, row) => {
    if (!items.length) return;
    awList.append(el("div", "aw-group", label));
    for (const c of items) {
      const b = el("button", "aw-row");
      b.type = "button";
      b.setAttribute("role", "menuitem");
      const t = el("b");
      row.icon(t);
      t.append(c.title);
      b.append(t, el("span", "proj", c.project || "General"));
      for (const line of row.meta(c)) b.append(line);
      b.onclick = () => awGo(c.id);
      awList.append(b);
    }
  };
  group("Needs you", g.wait, { icon: (t) => t.append(el("span", "ico wait", "▲ ")), meta: (c) => [el("span", "meta", `waiting since ${awSince(c.waitingSince || c.startedAt || Date.now())}`)] });
  group("Working", g.work, { icon: (t) => { const p = el("span", "pulse"); p.setAttribute("aria-hidden", "true"); t.append(p, " "); },
    meta: (c) => [el("span", "meta", c.startedAt ? `started ${awSince(c.startedAt)} ago` : "working")] });
  group("New", g.fresh, { icon: () => {}, meta: (c) => {
    const m = el("span", "meta");
    m.append(el("span", "word " + c.lastEnd.status, AW_WORD[c.lastEnd.status] || "Done"), ` ${ago(c.lastEnd.at)}`);
    const f = awFiles(c.lastEnd.files);
    if (f) m.append(" · " + f);
    const out = [m];
    if (c.lastEnd.firstLine) out.push(el("span", "meta", `"${c.lastEnd.firstLine}"`));
    return out;
  } });
};
const awCloseList = () => {
  if (!awList) return;
  awList.remove(); awList = null;
  clearInterval(awTick);
  awPill.setAttribute("aria-expanded", "false");
  removeEventListener("pointerdown", awOutside, true);
};
const awOutside = (e) => { if (awList && !awList.contains(e.target) && e.target !== awPill && !awPill.contains(e.target)) awCloseList(); };
awPill.onclick = () => {
  if (awList) { awCloseList(); return; }
  awList = el("div", "aw-list");
  awList.setAttribute("role", "menu");
  awList.setAttribute("aria-label", "Activity");
  document.body.append(awList);
  awFillList();
  const r = awPill.getBoundingClientRect();
  awList.style.top = `${r.bottom + 6}px`;
  awList.style.left = `${Math.max(8, Math.min(innerWidth - awList.offsetWidth - 8, r.right - awList.offsetWidth))}px`;
  awPill.setAttribute("aria-expanded", "true");
  awTick = setInterval(awFillList, 1000);
  addEventListener("pointerdown", awOutside, true);
  awList.querySelector(".aw-row")?.focus();
};
document.addEventListener("keydown", (e) => {
  if (!awList) return;
  const rows = [...awList.querySelectorAll(".aw-row")], i = rows.indexOf(document.activeElement);
  if (e.key === "Escape") { e.preventDefault(); awCloseList(); awPill.focus(); }
  else if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); rows[(i + (e.key === "ArrowDown" ? 1 : -1) + rows.length) % rows.length]?.focus(); }
  else if (e.key === "Tab") awCloseList();
});

// ---------- notices when something happens elsewhere (FR-190) ----------
const awNotices = el("div", "aw-notices");
awNotices.setAttribute("role", "region");
awNotices.setAttribute("aria-label", "Chat updates");
const awLive = el("p", "sr");
awLive.setAttribute("aria-live", "polite");
const awAlert = el("p", "sr");
awAlert.setAttribute("aria-live", "assertive");
document.body.append(awNotices, awLive, awAlert);
const awNotice = (c, kind, key) => {
  awNotices.querySelector(`[data-key="${CSS.escape(key)}"]`)?.remove();
  const n = el("div", "aw-notice " + (kind === "wait" ? "wait" : kind === "error" ? "err" : kind === "done" ? "" : "muted"));
  n.dataset.key = key;
  n.dataset.chat = c.id;
  const top = el("div", "top");
  const body = el("div");
  const t = el("b", null, c.title);
  body.append(t, " " + (kind === "wait" ? "needs you" : AW_END[kind] || "is done"));
  const f = kind !== "wait" && awFiles(c.lastEnd?.files);
  if (f) body.append(el("div", "sub", f));
  if (kind !== "wait" && c.lastEnd?.firstLine) body.append(el("div", "sub", `"${c.lastEnd.firstLine}"`));
  const x = el("button", "icon-btn", "✕");
  x.type = "button";
  x.setAttribute("aria-label", "Dismiss");
  x.onclick = () => n.remove();
  top.append(el("span", "ico", kind === "wait" ? "▲" : AW_ICON[kind] || "✓"), body, x);
  const act = el("div", "act");
  const open = el("button", "btn sm primary", "Open");
  open.type = "button";
  open.setAttribute("aria-label", `Open ${c.title}`);
  open.onclick = () => { n.remove(); awGo(c.id); };
  act.append(open);
  n.append(top, act);
  awNotices.append(n);
  while (awNotices.children.length > 3) awNotices.firstElementChild.remove();
  (kind === "wait" ? awAlert : awLive).textContent = `${c.title} ${kind === "wait" ? "needs you" : AW_END[kind] || "is done"}.`;
  if (kind !== "wait") {
    let left = 12000, last = Date.now();
    const tick = setInterval(() => {
      if (!n.isConnected) return clearInterval(tick);
      const now = Date.now();
      if (!n.matches(":hover, :focus-within")) left -= now - last;
      last = now;
      if (left <= 0) { clearInterval(tick); n.classList.add("leaving"); setTimeout(() => n.remove(), 200); }
    }, 250);
  }
};

// ---------- reacting to the poller ----------
let awPrev = null, awPrevAt = 0, awNewSig = null; // last snapshot, when it was taken
addEventListener("studio-chats", (e) => {
  const chats = e.detail;
  if (awSeen() === null) awMarkAllSeen(chats); // first run: no backlog of "new" (AC-117)
  const open = studioView.chatId && chats.find((c) => c.id === studioView.chatId);
  if (open?.lastEnd && awVisible()) awMarkSeen(open.id, open.lastEnd.at);
  if (awPrev && awVisible()) {
    for (const c of chats) {
      // A chat that appeared since the last poll (started in another tab) counts as having had nothing before,
      // so one that is already waiting or already finished still gets its notice.
      const p = awPrev.get(c.id) || {};
      if (c.id === studioView.chatId) continue;
      if (c.lastEnd && c.lastEnd.turnId !== p.lastEnd?.turnId && c.lastEnd.at >= awPrevAt - 1000) awNotice(c, c.lastEnd.status, c.id + ":end:" + c.lastEnd.turnId);
      if (c.waiting && c.waitingId !== p.waitingId) awNotice(c, "wait", c.id + ":wait");
    }
  }
  // A "needs you" notice goes once its card is answered anywhere.
  for (const n of awNotices.querySelectorAll(".aw-notice.wait")) if (!chats.find((c) => c.id === n.dataset.chat)?.waiting) n.remove();
  awPrev = new Map(chats.map((c) => [c.id, c]));
  awPrevAt = Date.now();
  awRenderPill();
  const sig = chats.filter(awIsNew).map((c) => c.id + ":" + c.lastEnd.at).join(",");
  if (sig !== awNewSig) { awNewSig = sig; dispatchEvent(new Event("studio-seen")); } // pages redraw their "New" markers
  if (awChatPage) awSyncBanner(chats);
});
const awMarkAllSeen = (chats) => {
  const s = {};
  for (const c of chats) if (c.lastEnd?.at) s[c.id] = c.lastEnd.at;
  store.set("seen", s);
};
// Seen marks are shared by every tab of this browser: re-draw when another tab changes them.
addEventListener("storage", (e) => {
  if (e.key !== "studio.seen") return;
  awRenderPill();
  dispatchEvent(new Event("studio-seen"));
});
document.addEventListener("visibilitychange", () => {
  if (!awVisible() || !studioView.chatId) return;
  const c = activity.chats.find((x) => x.id === studioView.chatId);
  if (c?.lastEnd) awMarkSeen(c.id, c.lastEnd.at);
});

// ---------- chat page: the return banner and the divider (FR-192 to FR-195) ----------
let awBanner = null, awBannerTick = null;
const awSetBanner = (kind, build) => {
  if (!awChatPage) return;
  clearInterval(awBannerTick);
  if (!awBanner || !awBanner.isConnected) {
    awBanner = el("div", "aw-banner");
    $("messages").prepend(awBanner);
  }
  awBanner.className = "aw-banner " + kind;
  awBanner.innerHTML = "";
  build(awBanner);
};
const awHref = (p) => {
  const parts = String(p).split("/");
  if (/^[A-Za-z]:|^\//.test(p) || parts.includes("..")) return null;
  const enc = (xs) => xs.map(encodeURIComponent).join("/");
  if (parts[0] === "output" && parts.length > 1) return "/output/" + enc(parts.slice(1));
  if (parts[0] === "projects" && parts.length > 2) return `/project-file/${encodeURIComponent(parts[1])}/${enc(parts.slice(2))}`;
  return null;
};
const awClearBanner = () => { clearInterval(awBannerTick); awBanner?.remove(); awBanner = null; };
const awFileLinks = (box, files) => {
  const f = awFiles(files);
  if (!f) return;
  const line = el("span", "files", f.slice(0, f.indexOf(": ") + 2));
  files.slice(0, 3).forEach((file, i) => {
    if (i) line.append(", ");
    // Files the Outputs panel can open (output\ and project folders) are links through its own sandboxed routes;
    // anything else, including files outside Home, is shown as text (spec A-2).
    const href = awHref(file.path);
    if (!href) line.append(el("span", null, awName(file.path)));
    else { const a = el("a", null, awName(file.path)); a.href = href; a.target = "_blank"; a.rel = "noopener"; line.append(a); }
  });
  if (files.length > 3) line.append(` +${files.length - 3} more`);
  box.append(line);
};
const awWorkBanner = (c) => awSetBanner("work", (b) => {
  const p = el("span", "pulse"); p.setAttribute("aria-hidden", "true");
  const d = el("div");
  const text = () => { d.innerHTML = ""; d.append(el("b", null, "Still working"), ` · started ${c.startedAt ? awSince(c.startedAt) + " ago" : "a moment ago"}, showing the reply so far`); };
  text();
  b.append(p, d);
  awBannerTick = setInterval(text, 1000);
});
const awWaitBanner = (c) => awSetBanner("wait", (b) => {
  const d = el("div");
  d.append(el("b", null, "Needs you"), ` · answer the card below (waiting ${awSince(c.waitingSince || Date.now())})`);
  const go = el("button", "btn sm", "Go to card");
  go.type = "button";
  go.onclick = () => document.querySelector("#messages .card:not(.settled), #messages .perm:not(.settled)")?.scrollIntoView({ block: "center", behavior: "smooth" });
  b.append(el("span", "ico", "▲"), d, go);
});
// Called by app.js when it rejoins a running chat (FR-192, FR-193).
const awayRejoined = (chat) => {
  const c = activity.chats.find((x) => x.id === chat.id) || chat;
  if (c.waiting) awWaitBanner(c); else awWorkBanner(c);
};
// While the banner shows, follow the chat between running and waiting.
const awSyncBanner = (chats) => {
  if (!awBanner?.isConnected || !studioView.chatId) return;
  const c = chats.find((x) => x.id === studioView.chatId);
  if (!c?.running) return;
  if (c.waiting && !awBanner.classList.contains("wait")) awWaitBanner(c);
  else if (!c.waiting && awBanner.classList.contains("wait")) awWorkBanner(c);
};
// Called by app.js when the turn this page is following ends (done event, with the summary).
const awayTurnEnded = (chatId, lastEnd) => {
  if (lastEnd?.at) awMarkSeen(chatId, lastEnd.at);
  if (!awBanner?.isConnected || !lastEnd) return;
  awSetBanner(lastEnd.status === "done" ? "done" : lastEnd.status === "error" ? "done err" : "done muted", (b) => {
    const d = el("div");
    d.setAttribute("role", "status");
    d.append(el("b", null, lastEnd.status === "done" ? "Done just now" : AW_WORD[lastEnd.status] || "Done"));
    awFileLinks(d, lastEnd.files || []);
    b.append(el("span", "ico", AW_ICON[lastEnd.status] || "✓"), d);
  });
  const b = awBanner;
  setTimeout(() => { if (b.isConnected) { b.classList.add("collapsing"); setTimeout(() => b.remove(), matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 300); } }, 10000);
};
// Called by app.js after a chat's history is shown and before it is rejoined (FR-194).
const awayOpened = (chat) => {
  const c = activity.chats.find((x) => x.id === chat.id) || chat;
  awClearBanner();
  if (!awIsNewOnOpen(c)) { if (c.lastEnd) awMarkSeen(c.id, c.lastEnd.at); return; }
  const mine = [...document.querySelectorAll("#messages .run.me")].pop();
  const div = el("div", "aw-divider", "New since you left");
  div.setAttribute("role", "separator");
  if (mine) mine.before(div);
  const e = c.lastEnd;
  awSetBanner(e.status === "done" ? "done" : e.status === "error" ? "done err" : "done muted", (b) => {
    const d = el("div");
    const lead = { done: "Finished while you were away", stopped: "Stopped while you were away", error: "Hit an error while you were away", interrupted: "Interrupted while you were away" };
    d.append(el("b", null, lead[e.status] || lead.done), ` · ${ago(e.at)}`);
    awFileLinks(d, e.files || []);
    const x = el("button", "icon-btn", "✕");
    x.type = "button";
    x.setAttribute("aria-label", "Hide");
    x.onclick = () => awClearBanner();
    b.append(el("span", "ico", AW_ICON[e.status] || "✓"), d, x);
  });
  if (mine) {
    if (typeof state !== "undefined") state.follow = false; // stay at the divider, not the bottom
    requestAnimationFrame(() => div.scrollIntoView({ block: "start" }));
  }
  awMarkSeen(c.id, e.at);
};
// On open the chat is already this page's chat, so check the seen mark directly (awIsNew skips the open chat).
const awIsNewOnOpen = (c) => { const s = awSeen(); return !!(s && c?.lastEnd && !c.running && c.lastEnd.at > (s[c.id] || 0)); };
