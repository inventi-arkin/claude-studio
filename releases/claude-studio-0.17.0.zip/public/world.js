// Home page world: a pixel-art scene (sky, sun or moon, clouds or stars, hills, meadow) and Claude, a free-roaming
// orange pixel character with reactions. Spec: specs/look-and-feel.md FR-30, FR-30a, FR-30b, FR-31, FR-31a, FR-32.
// Loaded after look.js (uses $, el, store, applyLook, greetingWord). On the chat page (CHAT) the world is a meadow band
// behind the bottom of the conversation: no sun or moon, Claude walks on a layer above it, and thinks while a turn runs.

const reduceMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
const effectiveTheme = () => document.documentElement.dataset.theme || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
const rand = (a, b) => a + Math.random() * (b - a);
const CHAT = $("world").classList.contains("chat-world");

// Pixel art helper: rows of characters, a palette of character -> color, one SVG rect per pixel.
const pixelSvg = (rows, palette, scale, cls = "") => {
  const w = rows[0].length, h = rows.length, rects = [];
  rows.forEach((row, y) => [...row].forEach((c, x) => { if (palette[c]) rects.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="${palette[c]}"/>`); }));
  return `<svg class="${cls}" viewBox="0 0 ${w} ${h}" width="${w * scale}" height="${h * scale}" shape-rendering="crispEdges" aria-hidden="true">${rects.join("")}</svg>`;
};
const SUN = ["......y.......", "..y.......y...", ".....oooo.....", "....oyyyyo....", "...oyyyyyyo...", "y..oyyyyyyo..y", "...oyyyyyyo...", "...oyyyyyyo...", "....oyyyyo....", ".....oooo.....", "..y.......y...", "......y......."];
const MOON = ["....mmmm....", "..mmmm......", ".mmmm.......", ".mmm........", "mmmm........", "mmcm........", "mmmm........", "mmcm........", ".mmmm.......", ".mmmmm......", "..mmmmmm....", "....mmmm...."];
// Two-tone clouds (spec worlds-v2 FR-211): a lit top, the cloud colour, a shaded base; weather tones all three.
const CLOUD = ["....llll......", "..llllllll....", ".wwwwwwwwwww..", "wwwwwwwwwwwwww", ".ssssssssssss."];
const CLOUD_PAL = { l: "var(--cloud-lit)", w: "var(--wx-cloud, var(--cloud))", s: "var(--cloud-shade)" };
const HEART = [".hh.hh.", "hhhhhhh", "hhhhhhh", ".hhhhh.", "..hhh..", "...h..."];
const SPARK = ["..s..", ".sss.", "sssss", ".sss.", "..s.."];

// ---------- custom companion and place (spec custom-world FR-148 to FR-152, worlds-v2 FR-206 to FR-210) ----------
// CW is the active pair, already checked by the server (pixel rows, #rrggbb colours, enums, short strings), or null for
// Claude in the Meadow: { name, creature, lines } from the companion (missing for Claude), plus { scene } from the place
// (missing for the Meadow). Its colours only ever become values of the ten world custom properties.
let CW = null;
const CW_VARS = PX_VARS;
const worldVarsOn = (node, world, theme) => { for (const [k, v] of Object.entries(CW_VARS)) world?.scene ? node.style.setProperty(v, world.scene[theme][k]) : node.style.removeProperty(v); };
// Claude (classic) in use (worlds-v2 FR-219): the server's reserved id; drawn with the v0.15 frames.
const CLASSIC_ID = "claude-classic", CLASSIC_COMPANION = { name: "Claude", classic: true };
const pairOf = (companion, place) => (companion || place ? { ...(companion || { name: "Claude" }), ...(place ? { scene: place.scene } : {}) } : null);
const cwLine = (kind, fallback) => {
  const list = CW?.lines?.[kind];
  return list?.length ? list[Math.floor(Math.random() * list.length)].replace("{greeting}", greetingWord()) : fallback;
};

// ---------- scene ----------
// groundTop and tops (the near ridge, [x, y, step] in CSS px) are read by the weather; P holds the place's colours.
const scene = { groundTop: 0, tops: [], px: CHAT ? 3 : 4, P: null, edge: null, par: "" };
const PAR_MARGIN = 4; // art px drawn either side of the hill layers, for the parallax (FR-214)
// Everything is measured inside the world area (sky + stage), not the window (FR-30b).
const worldEl = () => $("world");
const worldSize = () => ({ W: worldEl().clientWidth, H: worldEl().clientHeight });
// Top of the grass: in the clear stage, below the hills, leaving most of the stage to walk in.
const groundTopFor = () => {
  if (CHAT) return worldSize().H - 96;
  const st = $("stage"); return st.offsetTop + Math.min(110, Math.round(st.offsetHeight * 0.36));
};

const buildScene = () => {
  const roam = document.querySelector(".roam");
  const pet = $("pet");
  const wrap = el("div", "scene");
  wrap.setAttribute("aria-hidden", "true");
  // Canvas layers at art resolution (spec worlds-v2 FR-211 to FR-215): sky, then the three hill layers (which move a
  // little with the companion), the ground, and the near plants (which sway in the wind).
  wrap.innerHTML = `<canvas class="sky-cv"></canvas><div class="stars"></div><div class="clouds"></div>`
    + `<canvas class="land land-far"></canvas><canvas class="land land-mid"></canvas><canvas class="land land-near"></canvas>`
    + `<canvas class="land land-ground"></canvas><canvas class="land land-decor wx-sway"></canvas>`;
  roam.insertBefore(wrap, roam.firstChild);
  // The sun or moon is a real button: clicking it switches the theme (FR-30b). Not in the small meadow.
  if (!CHAT) {
    const sky = el("button", "celestial");
    sky.type = "button";
    sky.id = "celestial";
    sky.innerHTML = pixelSvg(SUN, { y: "#f8c84a", o: "#f0a93b" }, 6, "sun") + pixelSvg(MOON, { m: "#ece6c8", c: "#cfc7a3" }, 6, "moon");
    sky.onclick = toggleTheme;
    roam.insertBefore(sky, $("pet"));
  }
  // Clouds (light) drift across; stars (dark) twinkle. Both are placed in the upper part of the sky.
  const clouds = wrap.querySelector(".clouds");
  for (let i = 0; i < 4; i++) {
    const c = el("div", "cloud");
    c.innerHTML = pixelSvg(CLOUD, CLOUD_PAL, CHAT ? [4, 3, 4, 3][i] : [7, 5, 6, 4][i]);
    c.style.top = `${CHAT ? [14, 34, 24, 40][i] : [14, 30, 22, 40][i]}%`;
    c.style.animationDuration = `${[110, 150, 130, 170][i]}s`;
    c.style.animationDelay = `${-[20, 90, 55, 130][i]}s`;
    clouds.append(c);
  }
  const stars = wrap.querySelector(".stars");
  for (let i = 0; i < (CHAT ? 30 : 46); i++) {
    const s = el("span", "star");
    s.style.left = `${rand(1, 99)}%`;
    s.style.top = `${CHAT ? rand(20, 50) : rand(8, 55)}%`;
    s.style.animationDelay = `${-rand(0, 4)}s`;
    if (i % 5 === 0) s.classList.add("big");
    stars.append(s);
  }
  drawLand();
  new ResizeObserver(() => { clearTimeout(scene.t); scene.t = setTimeout(drawLand, 120); }).observe(worldEl());
};

// The place is painted by pixel.js into the scene's canvases: 4 screen px per art pixel on Home, 3 in the chat band.
// Colours are the ten world custom properties as the page resolves them, so the Meadow and custom places are drawn alike.
const drawLand = () => {
  const sc = document.querySelector(".scene"), { W, H } = worldSize(), px = scene.px, M = PAR_MARGIN;
  const w = Math.ceil(W / px), h = Math.ceil(H / px), gt = Math.round(groundTopFor() / px), hw = w + 2 * M;
  scene.groundTop = gt * px;
  const P = scene.P = pxRolesFrom(sc), q = (c) => sc.querySelector(c);
  const hill = (c) => { const cv = q(c); cv.style.left = `${-M * px}px`; return pxCanvas(cv, hw, gt, px); };
  const tops = pxPaint({ far: hill(".land-far"), mid: hill(".land-mid"), near: hill(".land-near"), ground: pxCanvas(q(".land-ground"), w, h, px), decor: pxCanvas(q(".land-decor"), w, h, px) },
    { w, h, gt, hw, P, scene: CW?.scene, dark: effectiveTheme() === "dark", band: CHAT });
  scene.tops = tops.map((y, x) => [(x - M) * px, y * px, px]);
  scene.edge = petEdge();
  drawSky();
  scene.par = ""; parallax();
  const sky = $("celestial");
  // The sun or moon sits top right; if that would overlap the greeting at this width, it moves down to the stage sky.
  if (sky) {
    sky.style.top = "20px";
    const g = $("greeting").getBoundingClientRect(), c = sky.getBoundingClientRect();
    if (c.left < g.right + 16 && c.right > g.left - 16) sky.style.top = `${$("stage").offsetTop + 4}px`;
  }
  keepPetInside();
  drawPet();
  wxLand();
};
// The sky follows the weather's colours (--wx-sky-top/bottom), which ease over 4 s: skyTween() redraws it meanwhile.
const drawSky = () => {
  const sc = document.querySelector(".scene"), px = scene.px, w = Math.ceil(worldSize().W / px), gt = Math.round(scene.groundTop / px);
  if (!sc || gt < 1) return;
  pxSky(pxCanvas(sc.querySelector(".sky-cv"), w, gt, px), w, gt, pxProbe(sc, "var(--wx-sky-top, var(--sky-top))"), pxProbe(sc, "var(--wx-sky-bottom, var(--sky-bottom))"));
};
const skyTween = (ms = 4300) => {
  clearInterval(scene.skyT);
  drawSky();
  if (reduceMotion()) return;
  const end = performance.now() + ms;
  scene.skyT = setInterval(() => { drawSky(); if (performance.now() > end) clearInterval(scene.skyT); }, 120);
};
// Parallax (FR-214): the hill layers shift up to 3 art px against the companion's position, 0.33 / 0.66 / 1 for far,
// mid and near (the snow cap goes with the near hills). Off at 860 px and narrower and with reduced motion.
const parallax = () => {
  const sc = document.querySelector(".scene");
  if (!sc) return;
  const on = !reduceMotion() && innerWidth > 860, off = on ? (pet.x / Math.max(1, worldSize().W) - 0.5) * -6 : 0;
  const shifts = [0.33, 0.66, 1].map((k) => Math.round(off * k) * scene.px), key = shifts.join();
  if (key === scene.par) return;
  scene.par = key;
  [".land-far", ".land-mid", ".land-near", ".wx-cap"].forEach((c, i) => { const n = sc.querySelector(c); if (n) n.style.translate = `${shifts[Math.min(i, 2)]}px 0`; });
};
// FR-216: the outline colour when the companion's main colour is close to the ground's, or null.
const petEdge = () => {
  if (!scene.P) return null;
  const c = petSprite();
  return pxOutline(!c ? pxHex(ORANGE) : c.version === 2 ? pxHex(c.palette.o) : pxMainColour(c.frames.stand, c.palette), scene.P.ground);
};
// In the transparent cells next to a sprite: the outline (rows of characters; solid(ch) says which are drawn).
const outlineRects = (rows, solid, edge) => {
  if (!edge) return "";
  const at = (x, y) => solid(rows[y]?.[x]), out = [];
  for (let y = -1; y <= rows.length; y++) for (let x = -1; x <= rows[0].length; x++)
    if (!at(x, y) && (at(x - 1, y) || at(x + 1, y) || at(x, y - 1) || at(x, y + 1))) out.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="${edge}"/>`);
  return out.join("");
};

const toggleTheme = () => {
  const next = effectiveTheme() === "dark" ? "light" : "dark";
  store.set("settings", { ...store.get("settings", {}), theme: next });
  applyLook();
  updateCelestialLabel();
  reactSay(next === "dark" ? "Good night! 🌙" : "Good morning! ☀");
};
const updateCelestialLabel = () => {
  if (!$("celestial")) return;
  const dark = effectiveTheme() === "dark";
  $("celestial").setAttribute("aria-label", dark ? "Switch to light theme" : "Switch to dark theme");
  $("celestial").title = dark ? "Switch to light theme" : "Switch to dark theme";
};

// ---------- Claude ----------
// 16x14 pixel frames. # = body, E = eye area (body colored; eyes drawn on top per expression).
const BODY = ["................", "...##########...", "..############..", "..##EE####EE##..", "..##EE####EE##..", "..##EE####EE##..", "..############..", "################", "..############..", "..############..", "...##########..."];
const LEGS = {
  stand: ["...#.#....#.#...", "...#.#....#.#...", "................"],
  stepA: ["..#..#....#..#..", "..#..#.....#.#..", "................"],
  stepB: ["...#.#...#..#...", "...#.#..#...#...", "................"],
};
// Arms up: the side stubs on row 7 move up to rows 3-6 (waving or happy).
const armsUp = (rows) => rows.map((r, y) => (y === 7 ? ".." + r.slice(2, 14) + ".." : y >= 3 && y <= 6 ? "#" + r.slice(1, 15) + "#" : r));
// Eye pixels per expression, as [x, y] for the left eye; the right eye is mirrored (+6 columns).
const EYES = {
  normal: [[4, 4], [5, 4], [4, 5], [5, 5]],
  closed: [[4, 5], [5, 5]],
  up: [[4, 3], [5, 3], [4, 4], [5, 4]],
  surprised: [[4, 3], [5, 3], [4, 4], [5, 4], [4, 5], [5, 5]],
  happy: [[3, 5], [4, 4], [5, 4], [6, 5]],
  dizzy: [[3, 3], [5, 3], [4, 4], [3, 5], [5, 5]],
};
const ORANGE = "#d97757", INK = "#1f1410", BLUSH = "#f2a29a";
const pet = { mode: null, x: 0, y: 0, tx: 0, ty: 0, facing: 1, step: 0, pauseUntil: 0, eyesOpen: true, armsUp: false, lastInput: Date.now(), happyUntil: 0, sayUntil: 0, last: 0, tick: 0,
  expr: "normal", blush: false, hover: false, reactUntil: 0, dizzyUntil: 0, clicks: [], clickCount: 0, lastReaction: null, dance: 0,
  scale: 1, checkin: null, nextCheckin: Date.now() + rand(15000, 25000), walkFrame: 0, walked: 0, blinkUntil: 0, blinkAt: Date.now() + rand(3000, 5500) };
const SIZE = { w: 64, h: 56 };
const SPEED = 45; // px per second
// Set by weather.js: walking speed in the wind, and a redraw when the land is redrawn (spec weather FR-170).
let wxWalk = () => 1, wxLand = () => {};
const LINES = {
  wave: () => cwLine("hello", "Hi! Ready when you are."),
  idle: () => cwLine("idle", `${greetingWord()}! 👋`),
  happy: () => cwLine("happy", "Yay! Let's build something."),
  think: () => cwLine("thinking", "Thinking…"),
  sleep: () => cwLine("sleepy", "Zz… it's late."),
};
const HOVER_LINES = ["Oh, hi!", "Hello there!", "Need something?", "👀"];
const CHECKIN_LINES = ["Just checking in 👀", "How's it going?", "Need a hand?", "Still here with you!"];
const BIG = 1.2; // extra size when Claude is closest to the user (2.2x)

// The sprite in use: a custom creature, Claude (classic) (null: drawn below from BODY, LEGS and EYES, exactly as in
// v0.15) or the new Claude (worlds-v2 FR-219).
const petSprite = () => CW?.creature || (CW?.classic ? null : CLAUDE_V2);
// v2 frame names (FR-217) for v1 creatures, which have 5 or 6 frames (design creatures-v2 §4).
const V1_FRAME = { idle1: "stand", idle2: "stand", walk1: "walkA", walk2: "stand", walk3: "walkB", walk4: "stand", blink: "blink", happy: "happy", sleep: "sleep", think: "stand", surprised: "stand" };
const spriteRows = (c, f) => (c.version === 2 ? c.frames[f] : c.frames[f === "sleep" && !c.frames.sleep ? "blink" : V1_FRAME[f]] || c.frames.stand);
// Which frame the companion shows now (design creatures-v2 §3). v2 sprites walk 4 frames by distance, v1 ones keep
// their 2-step walk on the 250 ms tick, as before.
const frameFor = (c, still) => {
  const now = Date.now(), mode = still ? "idle" : pet.mode;
  const walking = !still && mode === "idle" && now >= pet.pauseUntil && now >= pet.reactUntil && !pet.hover;
  const dancing = !still && pet.dance > now;
  if (!still && (mode === "happy" || (mode === "wave" && pet.armsUp) || (dancing && pet.step % 2 === 0) || pet.expr === "happy")) return "happy";
  if (!still && (pet.expr === "surprised" || pet.expr === "dizzy")) return "surprised";
  if (mode === "sleep") return "sleep";
  if (mode === "think") return "think";
  if (!still && now < pet.blinkUntil) return "blink";
  if (walking || dancing) return c?.version === 2 ? `walk${pet.walkFrame + 1}` : pet.step % 2 ? "walk1" : "walk3";
  return still || c?.version !== 2 ? "idle1" : Math.floor(now / 600) % 2 ? "idle2" : "idle1";
};
// Built once per (sprite, frame, outline colour): frames repeat constantly (spec §8).
const RECTS = new Map();
const creatureRects = (c, frame, edge) => {
  const rows = spriteRows(c, frame), key = rows.join("|") + (edge || "");
  if (RECTS.has(key)) return RECTS.get(key);
  const rects = [outlineRects(rows, (ch) => !!c.palette[ch], edge)];
  rows.forEach((row, y) => [...row].forEach((ch, x) => { if (c.palette[ch]) rects.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="${c.palette[ch]}"/>`); }));
  if (RECTS.size > 400) RECTS.clear();
  RECTS.set(key, rects.join(""));
  return RECTS.get(key);
};
const drawPet = () => {
  const still = reduceMotion(), c = petSprite();
  if (c) {
    const f = frameFor(c, still);
    $("petSvg").innerHTML = creatureRects(c, f, scene.edge);
    // Asleep and thinking: the 1 px breathing bob, every 1.2 s and 600 ms (design creatures-v2 §3).
    const bob = c.version === 2 && !still && ((f === "sleep" && Math.floor(Date.now() / 1200) % 2) || (f === "think" && Math.floor(Date.now() / 600) % 2));
    $("petSvg").setAttribute("viewBox", `0 ${bob ? -1 : 0} ${c.width} ${c.height}`);
    $("petSvg").style.transform = pet.facing < 0 ? "scaleX(-1)" : "";
    return;
  }
  // Claude (classic), unchanged from v0.15.
  const mode = still ? "idle" : pet.mode;
  const walking = !still && mode === "idle" && Date.now() >= pet.pauseUntil && Date.now() >= pet.reactUntil && !pet.hover;
  const dancing = !still && pet.dance > Date.now();
  const arms = !still && (mode === "happy" || (mode === "wave" && pet.armsUp) || (dancing && pet.step % 2 === 0));
  const legs = walking || dancing ? (pet.step % 2 ? "stepA" : "stepB") : "stand";
  const rows = [...(arms ? armsUp(BODY) : BODY), ...LEGS[legs]];
  let expr = still ? "normal" : pet.expr;
  if (!still && expr === "normal") expr = mode === "sleep" || !pet.eyesOpen ? "closed" : mode === "think" ? "up" : mode === "happy" ? "happy" : "normal";
  const rects = [outlineRects(rows, (ch) => ch === "#" || ch === "E", scene.edge)]; // FR-216
  rows.forEach((row, y) => [...row].forEach((ch, x) => { if (ch === "#" || ch === "E") rects.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="${ORANGE}"/>`); }));
  for (const [x, y] of EYES[expr]) for (const dx of [0, 6]) rects.push(`<rect x="${x + dx}" y="${y}" width="1" height="1" fill="${INK}"/>`);
  if (!still && pet.blush) for (const x of [3, 12]) rects.push(`<rect x="${x}" y="6" width="1" height="1" fill="${BLUSH}"/>`);
  $("petSvg").innerHTML = rects.join("");
  $("petSvg").style.transform = pet.facing < 0 ? "scaleX(-1)" : "";
};
// The whole-number scale that keeps a sprite 64-72 px tall on Home and 48-56 px in the chat band, or the nearest one
// (worlds-v2 FR-221).
const spriteScale = (h, band = CHAT) => {
  const [lo, hi] = band ? [48, 56] : [64, 72];
  let best = 0;
  for (let k = 1; k <= 8; k++) if (h * k >= lo && h * k <= hi) best = k;
  if (best) return best;
  let near = 1;
  for (let k = 1; k <= 8; k++) if (Math.min(Math.abs(h * k - lo), Math.abs(h * k - hi)) < Math.min(Math.abs(h * near - lo), Math.abs(h * near - hi))) near = k;
  return near;
};
const creatureScale = (c) => spriteScale(c.height);
// Claude (classic) as creature frames (eyes drawn in), for thumbnails and the dialog previews.
const classicFrame = (legs, eyes, arms) => [...(arms ? armsUp(BODY) : BODY), ...LEGS[legs]].map((r, y) => [...r].map((c, x) => (EYES[eyes].some(([ex, ey]) => ey === y && (ex === x || ex + 6 === x)) ? "k" : c)).join(""));
const CLAUDE_CLASSIC = { palette: { "#": ORANGE, E: ORANGE, k: INK }, width: 16, height: 14,
  frames: { stand: classicFrame("stand", "normal"), walkA: classicFrame("stepA", "normal"), walkB: classicFrame("stepB", "normal"), blink: classicFrame("stand", "closed"), happy: classicFrame("stand", "happy", true) } };
// Size, label and frame of the character for the active pair (Claude, Claude (classic) or a custom creature).
const fitCreature = () => {
  const c = petSprite(), w = c ? c.width : 16, h = c ? c.height : 14, s = spriteScale(h);
  SIZE.w = w * s; SIZE.h = h * s;
  for (const n of [$("pet"), $("petSvg")]) { n.style.width = `${SIZE.w}px`; n.style.height = `${SIZE.h}px`; }
  $("petSvg").setAttribute("viewBox", `0 0 ${w} ${h}`);
  $("pet").setAttribute("aria-label", CW?.creature ? `${CW.name}, your companion` : "Claude, your assistant");
};
const placePet = () => {
  $("pet").style.transform = `translate(${Math.round(pet.x)}px, ${Math.round(pet.y)}px)`;
  parallax();
  // Size grows from the feet up as Claude comes closer; the speech bubble stays above the head.
  $("petSvg").style.scale = pet.scale.toFixed(3);
  $("pet").style.setProperty("--s", pet.scale.toFixed(3));
  if (CHAT) fitSay();
};
// The chat band can be narrow (phone): keep the speech bubble inside it instead of centred over Claude.
const fitSay = () => {
  const s = $("petSay"), w = s.offsetWidth, W = worldSize().W;
  const left = Math.max(4, Math.min(W - w - 4, pet.x + SIZE.w / 2 - w / 2));
  s.style.left = `${Math.round(left - pet.x)}px`;
};
// Claude walks in the meadow: feet on the grass, inside the window.
const bounds = () => {
  const gt = scene.groundTop || groundTopFor();
  const { W, H } = worldSize();
  if (CHAT) { // walk only where the chat area shows the meadow (world coordinates = window coordinates)
    const st = $("world").parentElement.getBoundingClientRect();
    // Open panels float over the meadow (desktop): stay between them so Claude is never hidden under one.
    const side = $("sidebar").getBoundingClientRect(), outs = $("outputs").getBoundingClientRect();
    const left = side.width && side.right < innerWidth / 2 ? Math.max(st.left, side.right) : st.left;
    const right = outs.width && outs.left > innerWidth / 2 ? Math.min(st.right, outs.left) : st.right;
    const minY = Math.max(gt - SIZE.h + 8, 36);
    return { minX: left + 8, maxX: Math.max(left + 8, right - SIZE.w - 8), minY, maxY: Math.max(minY, H - SIZE.h - 6) };
  }
  const minY = CHAT ? Math.max(gt - SIZE.h + 8, 36) : gt - SIZE.h + 8; // chat band: room for the speech bubble above
  return { minX: 8, maxX: Math.max(8, W - SIZE.w - (CHAT ? 8 : 24)), minY, maxY: Math.max(minY, H - SIZE.h - 6) };
};
const keepPetInside = () => {
  const b = bounds();
  pet.x = Math.min(b.maxX, Math.max(b.minX, pet.x));
  pet.y = Math.min(b.maxY, Math.max(b.minY, pet.y));
  if (reduceMotion()) Object.assign(pet, homeSpot());
  if ($("pet")) placePet();
};
// Prefer spots where Claude can be seen (not under a panel or text); it may still walk behind content on the way.
const visibleAt = (x, y) => {
  const r = worldEl().getBoundingClientRect();
  const hit = document.elementFromPoint(r.left + x + SIZE.w / 2, r.top + y + SIZE.h / 2);
  return !hit || !!hit.closest(".roam") || hit.id === "messages"; // chat: open space in the conversation
};
const pickTarget = () => {
  const b = bounds();
  for (let i = 0; i < 24; i++) {
    pet.tx = rand(b.minX, b.maxX);
    pet.ty = rand(b.minY, b.maxY);
    if (visibleAt(pet.tx, pet.ty)) return;
  }
};
// Start (and, with reduced motion, stay) on the left of the meadow.
const homeSpot = () => { const b = bounds(); return { x: Math.min(b.maxX, Math.max(b.minX, Math.round(worldSize().W * 0.08))), y: b.minY + 12 }; };

const say = (text) => {
  $("petSay").textContent = text;
  $("petLive").textContent = text;
  $("pet").classList.add("talking");
  pet.sayUntil = Date.now() + 5000;
  if (CHAT) fitSay();
};
const setPet = (mode) => {
  if (pet.mode === mode && mode !== "happy") return;
  // A click reaction keeps Claude close; only work (a turn) or sleep ends a check-in early.
  if ((mode === "think" || mode === "sleep") && pet.checkin) endCheckin();
  pet.mode = mode;
  $("pet").classList.toggle("happy", mode === "happy");
  $("pet").classList.toggle("sleep", mode === "sleep");
  say(LINES[mode]());
  drawPet();
};
// What Claude should be doing right now (outside of the timed wave, happy and reaction states).
const restingMode = () => {
  // Thinks while any chat in this channel is running, as the server reports it (spec reliable-chats FR-81).
  if (activity.running || activity.localBusy) return "think";
  const h = new Date().getHours();
  if (h >= 23 || h < 5 || Date.now() - pet.lastInput > 10 * 60 * 1000) return "sleep";
  return "idle";
};

// ---------- reactions (FR-31a) ----------
const particle = (svg, cls, dx = 0) => {
  if (reduceMotion()) return;
  const p = el("div", "particle " + cls);
  p.innerHTML = svg;
  p.style.left = `${pet.x + SIZE.w / 2 - 14 + dx}px`;
  p.style.top = `${pet.y + SIZE.h * (1 - pet.scale) - 6}px`; // above the head, whatever Claude's size
  $("pet").parentElement.append(p);
  setTimeout(() => p.remove(), 1400);
};
const reactSay = (text, ms = 1800) => { say(text); pet.reactUntil = Date.now() + ms; };
const REACTIONS = {
  happy: () => { setPet("happy"); pet.happyUntil = Date.now() + 1800; pet.reactUntil = pet.happyUntil; },
  heart: () => { pet.expr = "happy"; particle(pixelSvg(HEART, { h: "#e5484d" }, 4), "float"); reactSay(cwLine("happy", "Thanks! ❤")); },
  spin: () => { pet.expr = "happy"; if (!reduceMotion()) { $("petSvg").classList.remove("spin"); void $("petSvg").offsetWidth; $("petSvg").classList.add("spin"); } reactSay(cwLine("happy", "Wheee!"), 1200); },
  dance: () => { pet.expr = "happy"; pet.dance = Date.now() + 1600; reactSay(cwLine("happy", "♪ La la la"), 1700); },
  sparkles: () => { pet.expr = "happy"; for (const dx of [-26, 0, 26]) particle(pixelSvg(SPARK, { s: "#f8c84a" }, 4), "burst", dx); reactSay(cwLine("happy", "Ta-da! ✨")); },
};
const onClickPet = () => {
  const now = Date.now();
  pet.lastInput = now;
  if (now < pet.dizzyUntil) return;                                  // still dizzy: clicks are ignored
  pet.clicks = pet.clicks.filter((t) => now - t < 2000).concat(now);
  if (pet.clicks.length >= 4) {                                     // too many clicks: dizzy (FR-31a)
    pet.clicks = [];
    pet.dizzyUntil = now + 2500;
    pet.expr = "dizzy";
    if (!reduceMotion()) $("pet").classList.add("dizzy");
    reactSay("Whoa… dizzy @_@", 2500);
    drawPet();
    return;
  }
  pet.clickCount++;
  let kind = "happy";
  if (pet.clickCount > 1) {
    const options = Object.keys(REACTIONS).filter((k) => k !== pet.lastReaction);
    kind = options[Math.floor(Math.random() * options.length)];
  }
  pet.lastReaction = kind;
  pet.blush = false;
  REACTIONS[kind]();
  drawPet();
};
const onHover = (e) => {
  if (pet.mode === "sleep" || Date.now() < pet.dizzyUntil || Date.now() < pet.reactUntil) return;
  pet.hover = true;
  pet.expr = "surprised";
  pet.blush = true;
  pet.facing = e.clientX - worldEl().getBoundingClientRect().left >= pet.x + SIZE.w / 2 ? 1 : -1;
  pet.pauseUntil = Date.now() + 2500;
  say(cwLine("hover", HOVER_LINES[Math.floor(Math.random() * HOVER_LINES.length)]));
  drawPet();
};
const onLeave = () => {
  if (!pet.hover) return;
  pet.hover = false;
  pet.blush = false;
  if (pet.expr === "surprised") pet.expr = "normal";
  pet.pauseUntil = Date.now() + 1000;
  drawPet();
};

// Walking: move toward the target, pause on arrival, then pick a new one (FR-30a).
const walk = () => {
  const now = performance.now();
  const dt = Math.min(0.1, (now - (pet.last || now)) / 1000);
  pet.last = now;
  if (!reduceMotion() && pet.mode === "idle" && !pet.hover && Date.now() >= pet.pauseUntil && Date.now() >= pet.reactUntil && Date.now() >= pet.dizzyUntil && pet.dance < Date.now()) {
    const dx = pet.tx - pet.x, dy = pet.ty - pet.y, dist = Math.hypot(dx, dy);
    if (dist < 2) {
      if (pet.checkin) checkinArrived();
      else { pet.pauseUntil = Date.now() + rand(2000, 5000); pickTarget(); drawPet(); }
    } else {
      const stepPx = Math.min(dist, SPEED * dt * wxWalk(dx));
      pet.x += (dx / dist) * stepPx; pet.y += (dy / dist) * stepPx;
      pet.walked += stepPx;
      if (pet.walked >= 6) { pet.walked = 0; pet.walkFrame = (pet.walkFrame + 1) % 4; drawPet(); } // one step per 6 px (design creatures-v2 §3)
      if (Math.abs(dx) > 1) pet.facing = dx > 0 ? 1 : -1;
      if (pet.checkin) { const p = Math.min(1, Math.max(0, 1 - dist / pet.checkin.dist)); pet.scale = 1 + BIG * (pet.checkin.phase === "in" ? p : 1 - p); }
      placePet();
    }
  }
};

// Checking in (now and then): walk to the front middle growing bigger, say hello, then walk back shrinking.
const startCheckin = () => {
  if (reduceMotion() || pet.mode !== "idle" || pet.hover || pet.checkin || document.hidden || Date.now() < pet.reactUntil || Date.now() < pet.dizzyUntil) return;
  const b = bounds();
  pet.tx = Math.min(b.maxX, Math.max(b.minX, (b.minX + b.maxX) / 2 + rand(-40, 40)));
  pet.ty = b.maxY;
  pet.checkin = { phase: "in", dist: Math.max(1, Math.hypot(pet.tx - pet.x, pet.ty - pet.y)) };
  pet.pauseUntil = 0;
  $("pet").classList.add("checking");
};
const checkinArrived = () => {
  const c = pet.checkin;
  if (c.phase === "in") {
    pet.scale = 1 + BIG;
    c.phase = "hold";
    pet.blush = true;
    say(cwLine("checkin", CHECKIN_LINES[Math.floor(Math.random() * CHECKIN_LINES.length)]));
    pet.pauseUntil = Date.now() + 3500;
  } else if (c.phase === "hold") {
    c.phase = "out";
    pet.blush = false;
    const b = bounds();
    pickTarget();
    pet.ty = Math.min(pet.ty, b.minY + (b.maxY - b.minY) * 0.4); // back into the meadow
    c.dist = Math.max(1, Math.hypot(pet.tx - pet.x, pet.ty - pet.y));
  } else {
    endCheckin();
    pet.pauseUntil = Date.now() + rand(2000, 5000);
    pickTarget();
  }
  placePet();
  drawPet();
};
const endCheckin = () => {
  pet.checkin = null;
  if (pet.scale > 1) { // cut short: shrink smoothly rather than snapping
    $("petSvg").classList.add("shrinking");
    setTimeout(() => $("petSvg").classList.remove("shrinking"), 700);
  }
  pet.scale = 1;
  pet.blush = false;
  $("pet").classList.remove("checking");
  placePet();
};

const startPet = () => {
  Object.assign(pet, homeSpot());
  placePet();
  setPet(reduceMotion() ? "idle" : "wave");
  pickTarget();
  pet.pauseUntil = Date.now() + 1500;
  setTimeout(() => { if (pet.mode === "wave") setPet(restingMode()); }, 2000);
  $("pet").onclick = onClickPet;
  $("pet").onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClickPet(); } };
  $("pet").addEventListener("pointerenter", onHover);
  $("pet").addEventListener("pointerleave", onLeave);
  for (const ev of ["mousemove", "keydown", "pointerdown", "scroll", "touchstart"]) addEventListener(ev, () => {
    pet.lastInput = Date.now();
    if (pet.mode === "sleep" && restingMode() !== "sleep") setPet("idle");
  }, { passive: true });
  addEventListener("studio-chats", () => { if (pet.mode !== "wave" && pet.mode !== "happy" && Date.now() >= pet.reactUntil) setPet(restingMode()); });
  // Same page (chat): think while a turn runs, cheer when it ends.
  // A panel opened or closed (chat page): if Claude is heading for a spot that is now covered, pick a new one.
  addEventListener("studio-panels", () => {
    if (pet.checkin) return;
    const b = bounds();
    if (pet.tx < b.minX || pet.tx > b.maxX || pet.x < b.minX || pet.x > b.maxX) { pickTarget(); pet.pauseUntil = 0; }
  });
  addEventListener("studio-busy", (e) => {
    if (e.detail) { pet.reactUntil = 0; setPet("think"); return; }
    setPet(restingMode());
    pet.expr = "happy";
    reactSay(cwLine("done", "Done! ✨"));
    drawPet();
  });
  setInterval(() => {
    pet.tick++;
    const now = Date.now();
    if (pet.dizzyUntil && now >= pet.dizzyUntil) { pet.dizzyUntil = 0; pet.expr = "normal"; $("pet").classList.remove("dizzy"); }
    if (pet.expr === "happy" && now >= pet.reactUntil && pet.mode !== "happy") pet.expr = "normal";
    if (pet.mode === "happy" && now > pet.happyUntil) setPet(restingMode());
    else if (pet.mode !== "wave" && pet.mode !== "happy" && now >= pet.reactUntil && pet.tick % 4 === 0) setPet(restingMode());
    if (now > pet.sayUntil) $("pet").classList.remove("talking");
    if (reduceMotion()) return;                       // stands still in the idle pose
    pet.eyesOpen = pet.tick % 14 !== 0;               // classic: blink every ~4 s
    if (now >= pet.blinkAt) { pet.blinkUntil = now + 150; pet.blinkAt = now + rand(3000, 5500); setTimeout(drawPet, 160); } // v2: 150 ms, every 3-5.5 s
    pet.armsUp = pet.mode === "wave" ? !pet.armsUp : false;
    if (pet.dance > now && pet.tick % 2 === 0) pet.facing *= -1;
    pet.step++;
    drawPet();
  }, 250);
  setInterval(walk, 33); // about 30 steps a second; a timer keeps walking steady in every browser
  setInterval(() => {
    if (Date.now() < pet.nextCheckin) return;
    startCheckin();
    pet.nextCheckin = Date.now() + rand(45000, 90000);
  }, 1000);
};

// ---------- switching companions and places (FR-148, worlds-v2 FR-206, design D-2, D-6) ----------
const applyColours = () => { const host = document.querySelector(".home-page, .chat-stage"); if (host) worldVarsOn(host, CW, effectiveTheme()); };
// A theme switch changes the place's colours: repaint the canvases with them.
const recolour = () => { applyColours(); if (document.querySelector(".scene .sky-cv")) drawLand(); };
// pair = { companion, place }: the worlds of the active companion and place (null = Claude, the Meadow).
const applyWorld = (pair) => {
  const companion = pair?.companion || null, place = pair?.place || null, world = pairOf(companion, place);
  const same = JSON.stringify(world) === JSON.stringify(CW);
  CW = world;
  store.set("world", { companion, place }); // first paint of the next page load, before the server answers
  if (same) return;
  applyColours();
  fitCreature();
  drawLand();
  if (pet.mode) say(LINES[pet.mode]()); // the new companion says the current line in its own voice
  if (!reduceMotion()) $("world").animate([{ opacity: 0.3 }, { opacity: 1 }], { duration: 300 });
};
// The server's library wins over the cached copy; other tabs pick up a switch within a minute.
const syncWorld = async () => {
  try {
    const lib = await (await fetch("/api/worlds")).json();
    applyWorld({ companion: lib.activeCompanion === CLASSIC_ID ? CLASSIC_COMPANION : lib.companions.find((x) => x.id === lib.activeCompanion)?.world || null,
      place: lib.places.find((x) => x.id === lib.activePlace)?.world || null });
    // Once on Home after the split (worlds-v2 FR-208): the companion says so, after its hello.
    if (lib.splitNotice && !CHAT && !store.get("splitSeen", 0)) {
      store.set("splitSeen", 1);
      setTimeout(() => reactSay("Your worlds were split into companions and places.", 5000), 2600);
    }
  } catch {} // unreachable: keep what is shown
};
addEventListener("studio-world", (e) => applyWorld(e.detail));
new MutationObserver(recolour).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", recolour);

// Previews for the 🐾 dialog, drawn by the same renderer: a still thumbnail (a place, or a companion on a plain tile)
// and a small stage where the companion walks in front of a still picture of the place. pair = { creature?, scene? }.
// The sprite of a pair for the previews, and its FR-216 ring on a ground colour ([r, g, b]).
const pairSprite = (pair) => pair?.creature || (pair?.classic ? CLAUDE_CLASSIC : CLAUDE_V2);
const ringOn = (c, ground) => pxOutline(c.version === 2 ? pxHex(c.palette.o) : pxMainColour(c.frames.stand, c.palette), ground);
const worldThumb = (pair, size, { tile = false, theme = effectiveTheme() } = {}) => {
  const box = el("span", "cw-thumb" + (tile ? " tile" : "")), c = pairSprite(pair);
  box.style.width = box.style.height = `${size}px`;
  box.setAttribute("aria-hidden", "true");
  let gy = Math.round(size * 0.86), edge = null;
  if (!tile) { const cv = el("canvas"); box.append(cv); const f = pxFlat(cv, pair?.scene, theme, size, size, 2, 0.6); gy = Math.round(size * 0.8); edge = ringOn(c, f.P.ground); }
  if (tile || pair?.creature !== undefined) {
    const k = Math.max(1, Math.floor((size * (tile ? 1 : 0.5)) / Math.max(c.width, c.height))); // a 24 px sprite fills a 48 px tile at 2×
    box.insertAdjacentHTML("beforeend", `<svg width="${c.width * k}" height="${c.height * k}" viewBox="0 0 ${c.width} ${c.height}" shape-rendering="crispEdges" style="left:${Math.round((size - c.width * k) / 2)}px;top:${gy - c.height * k}px">${creatureRects(c, "idle1", edge)}</svg>`);
  }
  return box;
};
// Returns stop(): call it before replacing or closing the stage.
const mountWorldStage = (stage, pair, theme) => {
  const W = stage.clientWidth || 520, H = stage.clientHeight || 200;
  stage.querySelectorAll(".cw-scene").forEach((n) => n.remove());
  const sc = el("div", "cw-scene"), cv = el("canvas", "cw-place"), box = el("div", "cw-critter");
  sc.setAttribute("aria-hidden", "true");
  sc.append(cv, box);
  stage.prepend(sc);
  const { gt, P } = pxFlat(cv, pair?.scene, theme, W, H, 3, 0.64);
  const c = pairSprite(pair), k = Math.max(1, Math.min(spriteScale(c.height, true), Math.floor((H * 0.42) / c.height)));
  const edge = ringOn(c, P.ground), feet = gt + Math.round((H - gt) * 0.45), still = reduceMotion();
  let x = 24, dir = 1, tick = 0;
  const paint = () => {
    const step = Math.floor(tick / 4), f = still ? "idle1" : tick % 40 > 36 ? "blink" : c.version === 2 ? `walk${(step % 4) + 1}` : step % 2 ? "walk1" : "walk3";
    box.innerHTML = `<svg width="${c.width * k}" height="${c.height * k}" viewBox="0 0 ${c.width} ${c.height}" shape-rendering="crispEdges" aria-hidden="true">${creatureRects(c, f, edge)}</svg>`;
    box.style.transform = `translate(${Math.round(x)}px, ${feet - c.height * k}px)` + (dir < 0 ? " scaleX(-1)" : "");
  };
  paint();
  if (still) return () => {};
  const t = setInterval(() => { tick++; x += dir * 1.5; if (x > W - c.width * k - 8 || x < 8) dir = -dir; paint(); }, 33);
  return () => clearInterval(t);
};

// Chat: pin the window-wide meadow to the window whatever the chat area width (sidebar shown or hidden).
const pinWorld = () => { const st = $("world").parentElement; st.style.setProperty("--world-left", `${-Math.round(st.getBoundingClientRect().left)}px`); };
if (CHAT) { pinWorld(); new ResizeObserver(pinWorld).observe($("world").parentElement); }
// The cached copy came from the server, but browser storage is not trusted further than its colours being colours.
// A cache in the v0.10 shape (one world) is ignored (design D-3).
const cached = store.get("world", null);
const HEXC = /^#[0-9a-fA-F]{6}$/;
const okCompanion = (c) => !c || (c.classic === true && !c.creature) || (c.creature?.palette && Object.values(c.creature.palette).every((v) => HEXC.test(v)));
const okPlace = (p) => !p || ["light", "dark"].every((t) => p.scene?.[t] && Object.values(p.scene[t]).every((v) => HEXC.test(v)));
CW = cached && "place" in cached && okCompanion(cached.companion) && okPlace(cached.place) ? pairOf(cached.companion, cached.place) : null;
applyColours();
fitCreature();
buildScene();
updateCelestialLabel();
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", updateCelestialLabel);
addEventListener("studio-theme", updateCelestialLabel); // a time-based theme switched
startPet();
syncWorld();
setInterval(() => { if (!document.hidden) syncWorld(); }, 60_000);
