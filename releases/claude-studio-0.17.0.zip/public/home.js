// Claude Studio Home page: greeting, check-in actions, recent projects and chats, Claude Home, and the Claude pet.
// Spec: specs/look-and-feel.md sections E, F, G (v0.4). Helpers come from look.js.

// Old links to /#<chat id> now open the chat page.
if (/^#[0-9a-f-]{36}$/.test(location.hash)) location.replace("/chat" + location.hash);

// Hand an action to the chat page (project to open, first message to send) and go there.
const goChat = (pending, hash = "") => {
  try { if (pending) sessionStorage.setItem("studio.pending", JSON.stringify(pending)); } catch {}
  location.href = "/chat" + hash;
};

let data = { projects: [], recentChats: [] };
let showAll = false;

// ---------- top bar, settings ----------
const loadInfo = async () => {
  const info = await (await api("/api/info")).json();
  $("channel").textContent = info.channel.toUpperCase();
  $("channel").className = "channel " + info.channel;
  $("homePath").textContent = info.home;
  // A Home saved for the next start (spec home-picker FR-129, FR-135): a note, Restart now, and a dot on 📁 for phones.
  const pending = info.savedHome;
  $("homePending").hidden = !pending;
  $("homePending").replaceChildren(...(pending ? ["→ ", el("code", null, pending), " after restart"] : []));
  $("homePending").title = pending ? `→ ${pending} after restart` + (info.canRestart ? "" : " · Restart Studio yourself to use it") : "";
  $("restartNow").hidden = !(pending && info.canRestart);
  $("changeHome").querySelector(".dot").hidden = !pending;
  $("changeHome").setAttribute("aria-label", pending ? "Change Claude Home, restart pending" : "Change Claude Home");
  document.title = (info.channel === "dev" ? "[DEV] " : "") + "Claude Studio";
};
const openSettings = (focusHome) => {
  const s = lookSettings();
  $("setStyle").value = s.style;
  $("setTheme").value = s.theme;
  mountChatSettings($("chatSettings"));
  showPermSummary();
  mountUpdates($("updatesPanel"));
  mountHomeSetting($("homeSetting")).then(() => { if (focusHome) $("homeSetting").querySelector("input")?.focus(); });
  $("settings").showModal();
};
$("openSettings").onclick = () => openSettings(false);
// Home's Settings has no tabs: a summary, and the chat page's Permissions panel in its own dialog (design permissions 6).
const showPermSummary = async () => {
  try {
    const { local } = await permApi();
    $("permSummary").textContent = `${local.allow.length} allowed · ${local.ask.length} ask first · ${local.deny.length} blocked`;
  } catch (e) { $("permSummary").textContent = e.message; }
};
$("managePerms").onclick = () => { $("settings").close(); mountPermissions($("permPanel")); $("permDialog").showModal(); };
$("changeHome").onclick = () => openHomePicker({ back: $("changeHome"), onSaved: (body) => {
  if (body.restartNeeded) return;
  // Same Home: say so briefly where the pending note sits (design 3.1).
  $("homePending").hidden = false;
  $("homePending").classList.add("plain");
  $("homePending").textContent = "Studio already uses this Home.";
  setTimeout(() => { $("homePending").classList.remove("plain"); loadInfo(); }, 3000);
} });
$("restartNow").onclick = restartStudio;
addEventListener("studio-home-saved", () => { if (!$("homePending").classList.contains("plain")) loadInfo(); });
$("setStyle").onchange = (e) => { const s = store.get("settings", {}); delete s.accent; store.set("settings", { ...s, style: e.target.value }); applyLook(); drawPet(); };
$("setTheme").onchange = (e) => { store.set("settings", { ...store.get("settings", {}), theme: e.target.value }); applyLook(); updateCelestialLabel(); };

// ---------- check-in actions (FR-27) ----------
$("actAsk").onclick = () => goChat({ project: "General" });
const focusProjects = () => {
  $("projects").scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  $("projGrid").querySelector("button")?.focus({ preventScroll: true });
};
$("actProject").onclick = focusProjects;
$("navProjects").onclick = (e) => { e.preventDefault(); focusProjects(); };
$("askForm").onsubmit = async (e) => {
  e.preventDefault();
  closeMenu();
  const text = $("homeAsk").value.trim();
  if (/^\/help$/.test(text)) { $("homeAsk").value = "/"; return renderMenu(true); }
  // A command sent before the list arrived waits for it, so a console command doesn't slip into a chat.
  if (text.startsWith("/") && !claudeCommands) {
    commandsLoad ||= api("/api/commands").then((r) => (r.ok ? r.json() : [])).catch(() => []);
    claudeCommands = await commandsLoad;
  }
  // Console commands run in the command console, so they never create a chat (spec command-console FR-101).
  if (isConsoleText(text)) { $("homeAsk").value = ""; return studioConsole.open({ run: text }); }
  // The chat page runs Studio commands (/new, /model, /btw) itself and sends everything else to Claude as typed.
  if (text) goChat({ project: "General", text });
};

// ---------- slash commands ----------
// The same / menu as the chat composer (app.js): Studio commands, then console commands (they open the command
// console), then skills and custom commands, then Claude Code built-ins. /rename is left out here: there is no chat yet.
let claudeCommands = null, commandsLoad = null;
const menu = { items: [], index: 0 };
const homeCommands = () => {
  const studio = STUDIO_COMMANDS.filter((c) => c.name !== "rename").map((c) => ({ ...c, key: c.name, desc: c.description, aliases: c.aliases || [], group: "Studio" }));
  const taken = new Set(STUDIO_COMMANDS.flatMap((c) => [c.name, ...(c.aliases || [])]));
  const rest = (claudeCommands || []).filter((c) => !taken.has(c.name)).map((c) => ({ ...c, key: c.name, desc: c.description, group: c.console ? "Console" : c.builtin ? "Claude Code" : "Skills and commands" }));
  return [...studio, ...rest];
};
const isConsoleText = (text) => { const name = /^\/(\S+)/.exec(text)?.[1]; return !!name && !!claudeCommands?.some((c) => c.console && c.name === name); };
const closeMenu = () => { $("cmdMenu").hidden = true; $("homeAsk").setAttribute("aria-expanded", "false"); $("homeAsk").removeAttribute("aria-activedescendant"); menu.items = []; };
const pickCommand = (c) => {
  if (c.console && !c.argumentHint) { closeMenu(); $("homeAsk").value = ""; return studioConsole.open({ run: "/" + c.name }); }
  const runsNow = STUDIO_COMMANDS.some((s) => s.name === c.name) && !c.argumentHint; // /new and /help run at once
  $("homeAsk").value = "/" + c.name + (runsNow ? "" : " ");
  closeMenu();
  $("homeAsk").focus();
  if (runsNow) $("askForm").requestSubmit();
};
const highlight = (i) => {
  if (!menu.items.length) return;
  menu.index = (i + menu.items.length) % menu.items.length;
  $("cmdMenu").querySelectorAll(".cmd-item").forEach((o, k) => o.setAttribute("aria-selected", String(k === menu.index)));
  const cur = $("cmd-" + menu.index);
  $("homeAsk").setAttribute("aria-activedescendant", cur.id);
  cur.scrollIntoView({ block: "nearest" });
};
const renderMenu = async (all = false) => {
  const v = $("homeAsk").value;
  const m = /^\/([^\s]*)$/.exec(v);
  if (!m && !all) return closeMenu();
  const box = $("cmdMenu");
  if (!claudeCommands) {
    box.innerHTML = "";
    box.append(el("p", "cmd-empty", "Loading commands…"));
    box.hidden = false;
    $("homeAsk").setAttribute("aria-expanded", "true");
    // One request however fast the user types; the first one can take a few seconds while Studio reads Claude Code's list.
    commandsLoad ||= api("/api/commands").then((r) => (r.ok ? r.json() : [])).catch(() => []);
    claudeCommands = await commandsLoad;
    if ($("homeAsk").value !== v) return; // the text changed meanwhile; its own input event renders the menu
  }
  const f = (m ? m[1] : "").toLowerCase();
  menu.items = rankMatches(homeCommands(), f, ["Studio", "Console", "Skills and commands", "Claude Code"]).slice(0, 60);
  menu.index = 0;
  box.innerHTML = "";
  if (!menu.items.length) box.append(el("p", "cmd-empty", `No command matches /${f}. Press Enter to send it to Claude as typed.`));
  let group = null;
  menu.items.forEach((c, i) => {
    if (!f && c.group !== group) { group = c.group; box.append(el("div", "cmd-group", group)); }
    box.append(resultRow({ id: "cmd-" + i, name: "/" + c.name, hint: c.argumentHint, desc: c.description, tag: f ? (c.group === "Skills and commands" ? "Skill" : c.group) : c.console ? "›_" : "", onPick: () => pickCommand(c) }));
  });
  box.hidden = false;
  $("homeAsk").setAttribute("aria-expanded", "true");
  highlight(0);
};
$("homeAsk").oninput = () => renderMenu();
$("homeAsk").onblur = () => setTimeout(closeMenu, 150);
$("homeAsk").onkeydown = (e) => {
  if (!$("cmdMenu").hidden && menu.items.length) {
    if (e.key === "ArrowDown") { e.preventDefault(); return highlight(menu.index + 1); }
    if (e.key === "ArrowUp") { e.preventDefault(); return highlight(menu.index - 1); }
    if (e.key === "Tab" || (e.key === "Enter" && !e.isComposing)) { e.preventDefault(); return pickCommand(menu.items[menu.index]); }
  }
  if (e.key === "Escape" && !$("cmdMenu").hidden) { e.preventDefault(); closeMenu(); }
};
const openNewProject = () => { $("newProjectError").textContent = ""; $("newProjectName").value = ""; $("newProject").showModal(); $("newProjectName").focus(); };
$("actNew").onclick = openNewProject;
$("cancelNewProject").onclick = () => $("newProject").close();
$("newProjectForm").onsubmit = async (e) => {
  e.preventDefault();
  const name = $("newProjectName").value;
  const res = await api("/api/projects", { method: "POST", body: JSON.stringify({ name }) });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) { $("newProjectError").textContent = body.error || "Could not create the project."; return; }
  $("newProject").close();
  await loadHome();
  [...$("projGrid").querySelectorAll(".pcard")].find((c) => c.dataset.name === body.name)?.focus();
};

// ---------- recent projects and chats (FR-28, FR-29) ----------
const initials = (name) => {
  const parts = name.split(/[-_ .]+/).filter(Boolean);
  return (parts.length > 1 ? parts.slice(0, 2).map((p) => p[0]) : [name.slice(0, 2)]).join("").toUpperCase();
};
const projectCard = (p) => {
  const b = el("button", "pcard");
  b.type = "button";
  b.dataset.name = p.name;
  const top = el("span", "top-row");
  const mono = el("span", "mono", initials(p.name)); mono.setAttribute("aria-hidden", "true");
  const name = el("span");
  name.append(el("b", null, p.name), el("br"), el("small", null, `${p.lastActivity ? ago(p.lastActivity) : "no activity"} · ${p.chats} chat${p.chats === 1 ? "" : "s"}`));
  top.append(mono, name);
  b.append(top, el("span", "last", p.lastChat ? p.lastChat.title : "No chats yet"));
  const fresh = typeof awNewCount === "function" ? awNewCount(p.name) : 0; // "2 new" (spec away-status FR-196)
  if (p.tags.length || fresh) {
    const tags = el("span", "tags");
    for (const t of p.tags) tags.append(el("span", t.kind === "wait" || t.kind === "work" ? "state-pill " + t.kind : "tag" + (t.kind === "live" ? " live" : ""), t.text));
    if (fresh) tags.append(el("span", "state-pill new", `${fresh} new`));
    b.append(tags);
  }
  b.onclick = () => goChat({ project: p.name });
  return b;
};
const renderProjects = () => {
  const grid = $("projGrid");
  grid.innerHTML = "";
  const term = $("projectSearch").value.trim().toLowerCase();
  const list = showAll ? data.projects.filter((p) => p.name.toLowerCase().includes(term)) : data.projects.slice(0, 3);
  for (const p of list) grid.append(projectCard(p));
  if (showAll && !list.length) grid.append(el("p", "hint", "No projects match."));
  const add = el("button", "pcard new", "＋ New project");
  add.type = "button";
  add.onclick = openNewProject;
  grid.append(add);
  $("projectsTitle").textContent = showAll ? "All projects" : "Recent projects";
  $("moreProjects").textContent = showAll ? "Show recent only" : `More projects (${data.projects.length}) →`;
  $("moreProjects").hidden = !showAll && data.projects.length <= 3;
  $("moreProjects").setAttribute("aria-expanded", String(showAll));
  $("moreSearchBox").hidden = !showAll;
};
$("moreProjects").onclick = () => { showAll = !showAll; $("projectSearch").value = ""; renderProjects(); if (showAll) $("projectSearch").focus(); };
$("projectSearch").oninput = renderProjects;

const renderChats = () => {
  const box = $("recentChats");
  box.innerHTML = "";
  for (const c of data.recentChats) {
    const a = el("a");
    a.href = "/chat#" + c.id;
    a.append(el("span", "t", c.title));
    if (c.project && c.project !== "General") a.append(el("span", "tag", c.project));
    // Working / Needs you take the place of the time (spec reliable-chats FR-80).
    if (c.waiting) a.append(el("span", "state-pill wait", "Needs you"));
    else if (c.running) { const s = el("span", "state"); const d = el("span", "dot"); d.setAttribute("aria-hidden", "true"); s.append(d, "Working"); a.append(s); }
    else if (typeof awIsNew === "function" && awIsNew(c)) a.append(el("span", "state-pill new", "New")); // spec away-status FR-196
    else a.append(el("small", null, c.updated ? ago(c.updated) : ""));
    box.append(a);
  }
  if (!data.recentChats.length) box.append(el("p", "hint", "No chats yet. Ask something to start one."));
  const last = data.recentChats[0];
  $("actContinue").hidden = !last;
  if (last) {
    $("continueInfo").textContent = `${last.title} · ${last.updated ? ago(last.updated) : ""}`;
    $("actContinue").onclick = () => goChat(null, "#" + last.id);
  }
};

const loadHome = async () => {
  data = await (await api("/api/home")).json();
  renderProjects();
  renderChats();
};
// The poller (look.js) reports running and waiting chats; refresh Home when that changes.
let lastActivity = "";
addEventListener("studio-chats", (e) => {
  const sig = e.detail.filter((c) => c.running || c.waiting).map((c) => `${c.id}:${c.waiting ? "w" : "r"}`).join(",");
  if (sig !== lastActivity) { const first = !lastActivity && !sig; lastActivity = sig; if (!first) loadHome(); }
});

// New results seen or arriving (away.js): redraw the markers.
addEventListener("studio-seen", () => { if (data) { renderProjects(); renderChats(); } });

// ---------- start ----------
$("greeting").textContent = `${greetingWord()}! What are we working on?`;
loadInfo();
loadHome();
