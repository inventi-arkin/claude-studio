// Place renderer (spec worlds-v2 FR-211 to FR-216, design worlds-v2 §3, ported from design/worlds-v2-mockup.html).
// Everything is drawn at "art" resolution (1 art pixel = px screen pixels) into small canvases that are scaled up with
// pixelated rendering, so edges stay crisp. All colours come from the 10 place roles, mixed with white or black in fixed
// amounts, so the Meadow, v0.10 places and new places get the same treatment. Loaded before world.js.

const pxHex = (h) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(h).trim()); const v = m ? m[1] : "888888"; return [0, 2, 4].map((i) => parseInt(v.slice(i, i + 2), 16)); };
const pxMix = (a, b, t) => a.map((v, i) => Math.round(v * (1 - t) + b[i] * t));
const pxCss = (c) => `rgb(${c[0]},${c[1]},${c[2]})`;
const pxLum = (c) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
const PX_WHITE = [255, 255, 255], PX_BLACK = [0, 0, 0];
const pxRng = (seed) => () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
const PX_ROLES = ["skyTop", "skyBottom", "cloud", "hillFar", "hill", "ground", "groundDetail", "accentA", "accentB", "accentC"];
const PX_VARS = { skyTop: "--sky-top", skyBottom: "--sky-bottom", cloud: "--cloud", hillFar: "--hill-far", hill: "--hill", ground: "--grass",
  groundDetail: "--grass-dark", accentA: "--flower-a", accentB: "--flower-b", accentC: "--flower-c" };
// The Meadow's colours (the same values as styles.css), for previews drawn outside the page's scene.
const PX_MEADOW = {
  light: { skyTop: "#9fd0f5", skyBottom: "#e6f4fd", cloud: "#ffffff", hillFar: "#a9cfb4", hill: "#86bd7c", ground: "#9ccc72", groundDetail: "#6fa552", accentA: "#f2a29a", accentB: "#f6d27a", accentC: "#fff8e6" },
  dark: { skyTop: "#070b18", skyBottom: "#1b2442", cloud: "#2a3350", hillFar: "#1a2a3c", hill: "#1f3a2e", ground: "#1f3328", groundDetail: "#2f5039", accentA: "#9a5866", accentB: "#9a8650", accentC: "#c9c2a8" },
};
// Role colours as [r, g, b]: read from the page's custom properties, or from a place's data (null = the Meadow).
const pxRolesFrom = (el) => { const cs = getComputedStyle(el); return Object.fromEntries(PX_ROLES.map((k) => [k, pxHex(cs.getPropertyValue(PX_VARS[k]))])); };
const pxRolesOf = (scene, theme) => Object.fromEntries(PX_ROLES.map((k) => [k, pxHex((scene?.[theme] || PX_MEADOW[theme])[k])]));
// Any CSS colour (custom properties, color-mix) as [r, g, b], through a hidden probe in the given element.
const pxProbe = (host, css) => {
  const p = document.createElement("i");
  p.style.cssText = "position:absolute;visibility:hidden;color:" + css;
  host.append(p);
  const c = getComputedStyle(p).color;
  p.remove();
  const v = (c.match(/-?\d*\.?\d+(e-?\d+)?/gi) || ["136", "136", "136"]).slice(0, 3).map(Number);
  return (c.startsWith("color(") ? v.map((x) => x * 255) : v).map(Math.round);
};

// The Meadow's plants and objects: characters name a role or a shade made from one (design D-2).
const PX_SPRITES = {
  flower: [".a.", "aca", ".a.", ".g.", ".g."],
  flower2: [".b.", "bcb", ".b.", "gg.", ".g."],
  bush: ["..GGGG..", ".GgGGgG.", "GgGGGGgG", "gGGgGGGg", ".gggggg."],
  tree: ["..GG..", ".GgGG.", "GgGGgG", "GGGgGG", ".GggG.", "..tt..", "..tt.."],
  oak: ["...GGGGG....", "..GgGGGGG...", ".GGGGgGGGGG.", "GgGGGGGGgGGG", "GGGgGGGGGGgG", ".GGGGGgGGGG.", "..gGGGGGGg..", "....tTt.....", "....tTt.....", "....tTt.....", "...ttTtt...."],
  rock: [".kKK.", "kKKKK", "kkKKk"],
};
const PX_MEADOW_DECOR = [["tree", "far"], ["flower", "near"], ["bush", "near"], ["tree", "near"], ["flower2", "near"], ["oak", "near"], ["flower", "near"], ["rock", "near"]];
const pxShade = (ch, P) => ({
  a: P.accentA, b: P.accentB, c: P.accentC, g: P.groundDetail, G: pxMix(P.hill, P.groundDetail, 0.5), t: pxMix(P.groundDetail, PX_BLACK, 0.45),
  T: pxMix(P.groundDetail, PX_BLACK, 0.3), k: pxMix(P.hillFar, PX_BLACK, 0.25), K: pxMix(P.hillFar, PX_WHITE, 0.1),
})[ch];
// Decorations as { rows, colour(ch), depth, keep }: the Meadow's own, or a place's (palette char → role). "keep" is the
// share of a kind's turns that are drawn, so "many" shows more of a kind than "few".
const pxDecor = (scene, P) => {
  if (!scene) return PX_MEADOW_DECOR.map(([k, depth]) => ({ rows: PX_SPRITES[k], colour: (ch) => pxShade(ch, P), depth, keep: 1 }));
  return (scene.decor || []).map((d) => ({ rows: d.rows, colour: (ch) => P[d.palette[ch]], depth: d.depth || "near",
    keep: { few: 0.4, some: 0.7, many: 1 }[d.density] ?? 0.7 }));
};

// ---------- the layers (all sizes in art pixels) ----------
// Sky: 6 bands, each edge dithered with a 2×2 checker into the next band.
const pxSky = (g, w, gt, top, bottom) => {
  for (let y = 0; y < gt; y++) {
    const f = (y / gt) * 5, i = Math.floor(f), fr = f - i;
    const a = pxMix(top, bottom, i / 5), b = pxMix(top, bottom, Math.min(5, i + 1) / 5);
    g.fillStyle = pxCss(a); g.fillRect(0, y, w, 1);
    if (fr > 0.78) { g.fillStyle = pxCss(b); for (let x = y % 2; x < w; x += 2) g.fillRect(x, y, 1, 1); }
  }
};
const pxRidge = (shape, x, base, amp, f1, f2, seed) => {
  if (shape === "gentle") amp *= 0.5; if (shape === "flat") amp = 1; if (shape === "dunes") { f1 *= 1.8; f2 *= 1.8; }
  let y = base - amp * (0.6 * Math.sin(x / f1 + seed) + 0.4 * Math.sin(x / f2 + seed * 2));
  if (shape === "jagged") y -= amp * 0.5 * Math.abs(Math.sin(x / 3.3 + seed)) + amp * 0.25 * ((Math.floor(x / 2) * 7) % 3) / 3;
  return Math.round(y);
};
// One hill layer: the ridge, a lit top edge, a dithered shade band, flat shade below. Returns the ridge tops.
// The colour distance fades towards: the sky near the horizon by day, a moonlit mist at night, so far layers are always
// a little lighter than near ones (QA F-2).
const pxHaze = (P, dark) => (dark ? pxMix(P.cloud, PX_WHITE, 0.3) : P.skyBottom);
const pxHill = (g, w, bottom, shape, base, amp, f1, f2, seed, col, haze, P, dark) => {
  const cc = pxMix(col, pxHaze(P, dark), haze), c = pxCss(cc), tops = [];
  // The lit edge stays brighter than the hazed body, also at night.
  const lit = pxCss(pxMix(cc, dark ? pxMix(P.cloud, PX_WHITE, 0.5) : PX_WHITE, dark ? 0.18 : 0.28)), band = pxCss(pxMix(cc, PX_BLACK, dark ? 0.25 : 0.12)), deep = pxCss(pxMix(cc, PX_BLACK, dark ? 0.18 : 0.08));
  for (let x = 0; x < w; x++) {
    const y0 = pxRidge(shape, x, base, amp, f1, f2, seed);
    tops.push(y0);
    g.fillStyle = lit; g.fillRect(x, y0, 1, 1);
    g.fillStyle = c; g.fillRect(x, y0 + 1, 1, Math.max(0, Math.min(5, bottom - y0 - 1)));
    g.fillStyle = band; for (let y = y0 + 3; y <= y0 + 5 && y < bottom; y++) if ((x + y) % 2 === 0) g.fillRect(x, y, 1, 1);
    if (bottom > y0 + 6) { g.fillStyle = deep; g.fillRect(x, y0 + 6, 1, bottom - y0 - 6); }
  }
  return tops;
};
// Tall near objects (7 rows or more: trees, pines, cacti) are drawn 1-3× so they stand about 24 art rows tall, taller
// than a companion; flowers, bushes and rocks stay 1× (design creatures-v2 §5a).
const pxDecorScale = (d) => (d.rows.length >= 7 ? Math.min(3, Math.max(1, Math.round(24 / d.rows.length))) : 1);
const pxSprite = (g, d, x, yBottom, haze, toward, k = 1) => {
  const n = d.rows.length;
  for (let ry = 0; ry < n; ry++) for (let rx = 0; rx < d.rows[ry].length; rx++) {
    const ch = d.rows[ry][rx]; if (ch === ".") continue;
    let c = d.colour(ch); if (!c) continue;
    if (haze) c = pxMix(c, toward, haze);
    g.fillStyle = pxCss(c); g.fillRect(x + rx * k, yBottom - (n - ry) * k, k, k);
  }
};
// Ground: base, a dithered band where it meets the hills, soft patches, then sparse clumped detail by pattern.
const pxGround = (g, w, h, gt, P, pattern, dark) => {
  const dot = (x, y, c) => { g.fillStyle = pxCss(c); g.fillRect(x, y, 1, 1); };
  g.fillStyle = pxCss(P.ground); g.fillRect(0, gt, w, h - gt);
  const shadow = pxLum(P.groundDetail) < pxLum(P.ground) ? P.groundDetail : pxMix(P.ground, PX_BLACK, 0.5); // always darker (QA F-2)
  for (let y = gt; y < gt + 2; y++) for (let x = 0; x < w; x++) dot(x, y, pxMix(P.ground, shadow, (x + y) % 2 ? 0.55 : 0.35));
  const r = pxRng(23), rows = Math.max(1, h - gt - 3);
  for (let i = 0; i < w * (h - gt) / 260; i++) {
    const cx = Math.floor(r() * w), cy = gt + 3 + Math.floor(r() * rows), rx = 4 + Math.floor(r() * 8), ry = 1 + Math.floor(r() * 2), light = r() > 0.5;
    const c = pxMix(P.ground, light ? PX_WHITE : P.groundDetail, light ? (dark ? 0.06 : 0.12) : 0.28);
    for (let y = -ry; y <= ry; y++) for (let x = -rx; x <= rx; x++) if ((x * x) / (rx * rx) + (y * y) / (ry * ry) <= 1 && ((x + y) % 2 === 0 || Math.abs(x) < rx - 2)) dot(cx + x, cy + y, c);
  }
  for (let i = 0; i < w * (h - gt) / 38; i++) {
    const x = Math.floor(r() * w), y = gt + 3 + Math.floor(r() * rows);
    if (pattern === "grass") { dot(x, y, P.groundDetail); dot(x - 1, y, P.groundDetail); dot(x - 1, y - 1, P.groundDetail); if (r() > 0.4) { dot(x + 1, y, P.groundDetail); dot(x + 1, y - 1, pxMix(P.groundDetail, P.ground, 0.4)); } }
    else if (pattern === "snow") { dot(x, y, pxMix(P.groundDetail, P.ground, 0.45)); dot(x + 1, y, pxMix(P.groundDetail, P.ground, 0.6)); if (r() > 0.85) dot(x, y - 2, PX_WHITE); }
    else if (pattern === "sand") { for (let k = 0; k < 3 + Math.floor(r() * 3); k++) dot(x + k, y + (k > 2 ? 1 : 0), pxMix(P.groundDetail, P.ground, 0.35)); }
    else if (pattern === "stone") { const n = 2 + Math.floor(r() * 2); for (let k = 0; k < n; k++) { dot(x + k, y, pxMix(P.ground, PX_WHITE, 0.22)); dot(x + k, y + 1, P.groundDetail); } }
    else { dot(x, y, P.groundDetail); dot(x + 1, y, pxMix(P.groundDetail, P.ground, 0.5)); }
  }
};

// Paints a place into art-resolution layer contexts { far, mid, near, ground, decor } (any may be the same context).
// The hill layers are hw wide (wider than the ground in the page, for the parallax). Returns the near ridge tops.
const pxPaint = (L, o) => {
  const { w, h, gt, P, scene, dark, band } = o, hw = o.hw || w;
  const shape = scene?.hills || "rolling", S = band ? 0.45 : 1, decor = pxDecor(scene, P);
  const farTops = pxHill(L.far, hw, gt, shape, gt - 26 * S, 9 * S, 40, 14, 1.3, P.hillFar, 0.35, P, dark);
  if (!band) { // far decorations stand on the far ridge, hazed (FR-212)
    const far = decor.filter((d) => d.depth === "far"), r = pxRng(11);
    if (far.length) for (let i = 0; i < hw / 14; i++) {
      const d = far[i % far.length], x = Math.floor(r() * hw);
      if (r() < d.keep) pxSprite(L.far, d, x, farTops[Math.min(hw - 1, x)] + 3, 0.3, pxHaze(P, dark));
    }
  }
  pxHill(L.mid, hw, gt, shape, gt - 15 * S, 7 * S, 30, 11, 4.1, pxMix(P.hillFar, P.hill, 0.5), dark ? 0.15 : 0.12, P, dark);
  const nearTops = pxHill(L.near, hw, gt, shape, gt - 7 * S, 5 * S, 18, 8, 2.2, P.hill, 0, P, dark);
  pxGround(L.ground, w, h, gt, P, scene?.ground || "grass", dark);
  // Near decorations on the ground, no overlaps, drawn back to front (FR-212).
  const near = decor.filter((d) => d.depth !== "far"), r = pxRng(31), placed = [];
  if (near.length) for (let i = 0; i < Math.round(w / (band ? 22 : 16)); i++) {
    const d = near[i % near.length], k = pxDecorScale(d), sw = d.rows[0].length * k;
    const x = Math.floor(r() * Math.max(1, w - sw)), y = gt + 3 + Math.floor(r() * Math.max(1, h - gt - 6)), keep = r() < d.keep;
    if (!keep || placed.some((p) => Math.abs(p.x - x) < sw + 2 && Math.abs(p.y - y) < 4)) continue;
    placed.push({ d, x, y, k });
  }
  placed.sort((a, b) => a.y - b.y).forEach((p) => pxSprite(L.decor, p.d, p.x, p.y, 0, null, p.k));
  return nearTops;
};

// A canvas at art size, shown px times larger.
const pxCanvas = (cv, w, h, px) => {
  if (cv.width !== w) cv.width = w; if (cv.height !== h) cv.height = h;
  cv.style.width = `${w * px}px`; cv.style.height = `${h * px}px`;
  const g = cv.getContext("2d"); g.clearRect(0, 0, w, h); return g;
};
// A two-tone cloud (lit top, shaded base): the union of 4 circles (FR-211).
const pxCloud = (g, cx, cy, P, dark) => {
  const blobs = [[0, 0, 3], [3, -1, 4], [7, 0, 3], [10, 1, 2]];
  for (let y = -6; y <= 2; y++) for (let x = -4; x <= 14; x++) {
    if (!blobs.some(([bx, by, br]) => (x - bx) ** 2 + (y - by) ** 2 <= br * br)) continue;
    g.fillStyle = pxCss(y >= 1 ? pxMix(P.cloud, P.hillFar, dark ? 0.25 : 0.22) : y <= -3 ? pxMix(P.cloud, PX_WHITE, dark ? 0.08 : 0.3) : P.cloud);
    g.fillRect(cx + x, cy + y, 1, 1);
  }
};
// A flattened, still picture of a place for previews and thumbnails: sky, stars or a cloud, hills, ground, plants.
// Returns the ground top in CSS pixels and the place's colours.
const pxFlat = (canvas, scene, theme, wCss, hCss, px, gtFrac = 0.62) => {
  const w = Math.max(1, Math.ceil(wCss / px)), h = Math.max(1, Math.ceil(hCss / px)), gt = Math.round(h * gtFrac), dark = theme === "dark";
  const g = pxCanvas(canvas, w, h, px), P = pxRolesOf(scene, theme), r = pxRng(5);
  pxSky(g, w, gt, P.skyTop, P.skyBottom);
  if (dark) for (let i = 0; i < w * gt / 170; i++) { g.fillStyle = pxCss(pxMix([244, 239, 216], P.skyTop, r() * 0.5)); g.fillRect(Math.floor(r() * w), Math.floor(r() * gt * 0.7), 1, 1); }
  else if (w > 40) pxCloud(g, Math.round(w * 0.2), Math.round(gt * 0.3), P, false);
  pxPaint({ far: g, mid: g, near: g, ground: g, decor: g }, { w, h, gt, P, scene, dark, band: h < 50 });
  return { gt: gt * px, P };
};
// The FR-216 outline: a 1 px edge around a companion whose main colour is close to the ground's, or null.
const pxOutline = (main, ground) => {
  if (Math.abs(pxLum(main) - pxLum(ground)) >= 0.28) return null;
  return pxCss(pxLum(ground) > 0.5 ? pxMix(ground, PX_BLACK, 0.7) : pxMix(ground, PX_WHITE, 0.75));
};
// The colour most of a sprite is drawn in.
const pxMainColour = (rows, palette) => {
  const n = {};
  for (const row of rows) for (const ch of row) if (palette[ch]) n[ch] = (n[ch] || 0) + 1;
  const top = Object.entries(n).sort((a, b) => b[1] - a[1])[0];
  return pxHex(top ? palette[top[0]] : "#888888");
};
