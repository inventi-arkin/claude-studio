// Command console (spec command-console FR-100 to FR-110, design command-console.md): a terminal-like dialog with its
// own Claude session for readouts and session commands, on Home and the chat page. Loaded after look.js (api, $, el,
// rankMatches, resultRow, terminalText) and before palette.js, which opens it through window.studioConsole.
(() => {
  const dlg = el("dialog", "console");
  dlg.setAttribute("aria-labelledby", "ccTitle");
  dlg.innerHTML = `<div class="cc-head"><div class="tt"><h2 id="ccTitle">Command console</h2><div class="cc-sub">Runs commands in its own session · not a chat</div></div>
      <button type="button" class="btn ghost sm" id="ccNew" aria-label="New session"><span class="cc-long">New session</span><span class="cc-short">New</span></button>
      <button type="button" class="icon-btn" id="ccClose" aria-label="Close" title="Close">✕</button></div>
    <div class="cc-log" id="ccLog" role="log" aria-live="polite"></div>
    <div class="cc-note" id="ccNote" role="status" hidden><span class="msg"><strong aria-hidden="true">⚠</strong> <span id="ccNoteText"></span></span>
      <button type="button" class="btn primary sm" id="ccNoteGo"></button><button type="button" class="icon-btn" id="ccNoteX" aria-label="Dismiss" title="Dismiss">✕</button></div>
    <form class="cc-prompt" id="ccForm">
      <div class="cmd-menu" id="ccMenu" role="listbox" aria-label="Console commands" hidden></div>
      <span class="cc-mark" aria-hidden="true">❯</span>
      <input id="ccInput" autocomplete="off" spellcheck="false" placeholder="Type / for console commands" aria-label="Console command"
        role="combobox" aria-autocomplete="list" aria-controls="ccMenu" aria-expanded="false">
    </form>`;
  document.body.append(dlg);
  const log = dlg.querySelector("#ccLog"), input = dlg.querySelector("#ccInput"), box = dlg.querySelector("#ccMenu");
  const cc = { commands: null, loading: null, items: [], index: 0, busy: false, poll: null, back: null, note: null };
  const STUDIO = [
    { name: "clear", key: "clear", desc: "Start a new console session.", description: "Start a new console session.", group: "Studio" },
    { name: "help", key: "help", desc: "Show all console commands.", description: "Show all console commands.", group: "Studio" },
  ];

  // Console commands are the ones the server marks console: true in /api/commands (FR-100).
  const loadCommands = async () => {
    cc.loading ||= api("/api/commands").then((r) => (r.ok ? r.json() : [])).catch(() => []);
    cc.commands = (await cc.loading).filter((c) => c.console).map((c) => ({ ...c, key: c.name, desc: c.description, group: "Console" }));
    return cc.commands;
  };
  const isConsole = (name) => !!cc.commands?.some((c) => c.name === name);

  // ---------- transcript ----------
  const time = (at) => new Date(at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const nearBottom = () => log.scrollHeight - log.scrollTop - log.clientHeight < 40;
  const toBottom = () => { log.scrollTop = log.scrollHeight; };
  // Markdown answers (/context: headings and tables) are rendered sanitised; everything else as terminal text (FR-62).
  const markdown = (text) => DOMPurify.sanitize(marked.parse(text, { gfm: true, breaks: false }));
  const output = (raw) => {
    const s = String(raw || "");
    const text = s.replace(/<\/?local-command-(stdout|stderr)>/g, "").trim() || "(no output)";
    const out = el("div", "cmd-out" + (/<local-command-stderr>/.test(s) ? " err" : ""));
    const elbow = el("span", "cmd-elbow", "⎿"); elbow.setAttribute("aria-hidden", "true");
    let body;
    if (/^#{1,6} /m.test(text) || /^\|.*\|\s*\n\|[\s:|-]+\|/m.test(text)) { body = el("div", "md cmd-md"); body.innerHTML = markdown(keepBackslashes(text)); }
    else body = terminalText(text);
    out.append(elbow, body);
    return out;
  };
  const waiting = () => {
    const out = el("div", "cmd-out waiting");
    const elbow = el("span", "cmd-elbow", "⎿"); elbow.setAttribute("aria-hidden", "true");
    out.append(elbow, el("pre", null, "Running…"));
    return out;
  };
  const entry = (command, at) => {
    const e = el("div", "cc-entry");
    const line = el("div", "cmd-line");
    line.append(el("span", "cc-cmd", command), el("span", "cc-time", time(at)));
    e.append(line);
    return e;
  };
  const showEmpty = (mark) => {
    log.innerHTML = "";
    const empty = el("div", "cc-empty");
    if (mark) empty.append(el("div", "cc-started", mark));
    empty.append(el("div", null, "No commands yet."));
    const chips = el("div", "chips");
    for (const name of ["usage", "context", "mcp"].filter(isConsole)) {
      const b = el("button", "btn sm", "/" + name);
      b.type = "button";
      b.onclick = () => submit("/" + name);
      chips.append(b);
    }
    empty.append(chips);
    log.append(empty);
  };
  const render = (data) => {
    log.setAttribute("aria-busy", "true");
    log.innerHTML = "";
    for (const x of data.entries) { const e = entry(x.command, x.at); e.append(output(x.output)); log.append(e); }
    if (data.pending) { const e = entry(data.pending.command, data.pending.at); e.append(waiting()); log.append(e); }
    if (!log.children.length) showEmpty();
    log.removeAttribute("aria-busy");
    toBottom();
  };
  const setBusy = (on, command = "") => {
    cc.busy = on;
    input.disabled = on;
    input.placeholder = on ? `Running ${command.split(/\s/)[0]}…` : "Type / for console commands";
    dlg.querySelector("#ccNew").disabled = on;
    if (!on && dlg.open) input.focus();
  };
  // Another tab (or a closed and reopened console) may be running a command: follow it until it ends (FR-104).
  const watch = (on) => {
    clearInterval(cc.poll);
    cc.poll = on ? setInterval(async () => {
      const data = await api("/api/console").then((r) => r.json()).catch(() => null);
      if (data && !data.running) { watch(false); render(data); setBusy(false); }
    }, 2000) : null;
  };
  const load = async () => {
    if (cc.busy && !cc.poll) return; // this tab's own command is still running; its result fills in by itself
    log.innerHTML = "";
    log.append(el("p", "cmd-empty", "Loading…"));
    await loadCommands();
    const data = await api("/api/console").then((r) => (r.ok ? r.json() : null)).catch(() => null);
    if (!data) { log.innerHTML = ""; const e = el("div", "cc-entry"); e.append(output("<local-command-stderr>Couldn't reach Studio.</local-command-stderr>")); log.append(e); return; }
    render(data);
    setBusy(data.running, data.pending?.command);
    watch(data.running);
  };

  // ---------- running a command ----------
  const run = async (command) => {
    log.querySelector(".cc-empty")?.remove();
    const e = entry(command, Date.now());
    const wait = waiting();
    e.append(wait);
    log.append(e);
    toBottom(); // a command you send is always brought into view
    setBusy(true, command);
    let raw;
    try {
      const r = await api("/api/console", { method: "POST", body: JSON.stringify({ command }) });
      const j = await r.json().catch(() => ({}));
      if (r.ok) raw = j.output;
      else if (r.status === 409) { wait.replaceWith(output(`<local-command-stderr>${j.error || "A console command is already running."}</local-command-stderr>`)); watch(true); return; }
      else raw = `<local-command-stderr>${j.error || `Request failed (${r.status})`}</local-command-stderr>`;
    } catch {
      raw = "<local-command-stderr>Couldn't reach Studio.</local-command-stderr>";
    }
    const keep = nearBottom();
    wait.replaceWith(output(raw));
    // A long answer is shown from its command line, not its last line; a short one just keeps the view at the end.
    if (keep) { if (e.offsetHeight > log.clientHeight) log.scrollTop += e.getBoundingClientRect().top - log.getBoundingClientRect().top - 8; else toBottom(); }
    setBusy(false);
  };
  const reset = async () => {
    hideNote();
    const r = await api("/api/console/reset", { method: "POST" }).catch(() => null);
    if (!r?.ok) { showNote("Couldn't start a new session.", null); return; }
    showEmpty(`New session started · ${time(Date.now())}`);
    input.value = "";
    input.focus();
  };

  // ---------- note: commands only (FR-105) ----------
  const hideNote = () => { dlg.querySelector("#ccNote").hidden = true; cc.note = null; };
  const showNote = (text, go) => {
    dlg.querySelector("#ccNoteText").textContent = text;
    const btn = dlg.querySelector("#ccNoteGo");
    btn.hidden = !go;
    if (go) btn.textContent = go.label;
    cc.note = go;
    dlg.querySelector("#ccNote").hidden = false;
  };
  const startChat = (text) => {
    dlg.close();
    try { sessionStorage.setItem("studio.pending", JSON.stringify({ project: "General", text })); } catch {}
    location.href = "/chat";
  };
  dlg.querySelector("#ccNoteGo").onclick = () => cc.note && startChat(cc.note.text);
  dlg.querySelector("#ccNoteX").onclick = () => { hideNote(); input.focus(); };

  const submit = async (raw) => {
    const text = raw.trim();
    closeMenu();
    if (!text || cc.busy) return;
    if (cc.note && cc.note.text === text) return startChat(text); // Enter again on the same text presses the note's button
    hideNote();
    if (text === "/clear") return reset();
    if (text === "/help") { input.value = "/"; return renderMenu(true); }
    if (!text.startsWith("/")) return showNote("The console runs commands only.", { label: "Start a chat with this", text });
    await loadCommands();
    const name = text.slice(1).split(/\s/)[0];
    if (!isConsole(name)) return showNote(`/${name} runs in a chat.`, { label: `Start a chat with /${name}`, text });
    input.value = "";
    run(text);
  };
  dlg.querySelector("#ccForm").onsubmit = (e) => { e.preventDefault(); submit(input.value); };

  // ---------- / menu (same keyboard model as the composer, FR-58) ----------
  const closeMenu = () => { box.hidden = true; input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant"); cc.items = []; };
  const highlight = (i) => {
    if (!cc.items.length) return;
    cc.index = (i + cc.items.length) % cc.items.length;
    box.querySelectorAll(".cmd-item").forEach((o, k) => o.setAttribute("aria-selected", String(k === cc.index)));
    const cur = box.querySelector("#cc-" + cc.index);
    input.setAttribute("aria-activedescendant", cur.id);
    cur.scrollIntoView({ block: "nearest" });
  };
  const pick = (c) => {
    closeMenu();
    if (c.argumentHint) { input.value = "/" + c.name + " "; input.focus(); }
    else submit("/" + c.name);
  };
  const renderMenu = async (all = false) => {
    const v = input.value;
    const m = /^\/([^\s]*)$/.exec(v);
    if (!m && !all) return closeMenu();
    if (!cc.commands) { await loadCommands(); if (input.value !== v) return; }
    const f = (m ? m[1] : "").toLowerCase();
    cc.items = rankMatches([...cc.commands, ...STUDIO], f, ["Console", "Studio"]);
    cc.index = 0;
    box.innerHTML = "";
    if (!cc.items.length) box.append(el("p", "cmd-empty", `No console command matches /${f}. Skills and other commands run in a chat.`));
    let group = null;
    cc.items.forEach((c, i) => {
      if (!f && c.group !== group) { group = c.group; box.append(el("div", "cmd-group", group)); }
      box.append(resultRow({ id: "cc-" + i, name: "/" + c.name, hint: c.argumentHint, desc: c.desc, onPick: () => pick(c) }));
    });
    box.hidden = false;
    input.setAttribute("aria-expanded", "true");
    highlight(0);
  };
  input.oninput = () => { if (cc.note && input.value.trim() !== cc.note.text) hideNote(); renderMenu(); };
  input.onblur = () => setTimeout(closeMenu, 150);
  input.onkeydown = (e) => {
    if (!box.hidden && cc.items.length) {
      if (e.key === "ArrowDown") { e.preventDefault(); return highlight(cc.index + 1); }
      if (e.key === "ArrowUp") { e.preventDefault(); return highlight(cc.index - 1); }
      if (e.key === "Tab" || (e.key === "Enter" && !e.isComposing)) { e.preventDefault(); return pick(cc.items[cc.index]); }
    }
    if (e.key === "Escape" && !box.hidden) { e.preventDefault(); closeMenu(); }
  };

  // ---------- open and close ----------
  dlg.querySelector("#ccNew").onclick = reset;
  dlg.querySelector("#ccClose").onclick = () => dlg.close();
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); }); // the backdrop
  dlg.addEventListener("cancel", (e) => { if (!box.hidden) { e.preventDefault(); closeMenu(); } }); // Esc: the menu first
  dlg.addEventListener("close", () => { watch(false); closeMenu(); if (cc.back && document.contains(cc.back)) cc.back.focus(); });

  // run: a command to run at once; fill: text to put in the prompt and wait for Enter (FR-103).
  const open = async ({ run: command, fill } = {}) => {
    if (!dlg.open) { cc.back = document.activeElement; dlg.showModal(); }
    hideNote();
    await load();
    input.focus();
    if (command) submit(command);
    else if (fill) { input.value = fill; input.focus(); }
  };
  window.studioConsole = { open, isConsole: (name) => (cc.commands ? isConsole(name) : null) };
  $("openConsole")?.addEventListener("click", () => open());
})();
