// Weather in the pixel scene on Home and the chat meadow. Spec: specs/weather.md FR-155 to FR-177; design: design/weather.md.
// Loaded after world.js (uses $, el, store, lookSettings, scene, worldEl, worldSize, CHAT, pet, SIZE, say, drawPet, pixelSvg,
// CLOUD, reduceMotion, effectiveTheme, rand, wxWalk, wxLand). Pure decoration: no network, no server data, no Claude calls.

const WX_NAMES = ["clear", "cloudy", "rain", "thunderstorm", "snow", "fog", "windy"];
const WX_LABEL = { clear: "Clear", cloudy: "Cloudy", rain: "Rain", thunderstorm: "Thunderstorm", snow: "Snow", fog: "Fog", windy: "Windy" };
// Brightness scale (FR-176, design §4): [towards --wx-bright, towards --wx-dark] in %, the same in light and dark.
const WX_TONE = { clear: [15, 0], snow: [12, 0], windy: [5, 0], cloudy: [0, 0], fog: [0, 5], rain: [0, 15], thunderstorm: [0, 30] };
const WX_LAND = { clear: 1.06, snow: 1.05, windy: 1.02, cloudy: 1, fog: 0.97, rain: 0.93, thunderstorm: 0.86 };
const WX_BG = { clear: 4, snow: 4, windy: 2, cloudy: 0, fog: 0, rain: -3, thunderstorm: -4 }; // page background (FR-177)
const WX_DIM = { clear: 1, cloudy: 0.85, rain: 0.7, thunderstorm: 0.6, snow: 0.8, fog: 0.55, windy: 1 };
const WX_CAPS = { rain: 85, thunderstorm: 120, snow: 80, windy: 12 }; // Home; the chat band has half (FR-174)
const WX_LINES = {
  clear: ["Skies cleared up.", "Clear skies, clear code.", "Ahh, nice and clear."],
  cloudy: ["Getting a bit cloudy.", "Clouds rolling in. Cozy.", "Grey skies, bright ideas."],
  rain: ["Rain! Good thinking weather.", "Pitter-patter. I'll stay close.", "Rain's here. Puddles soon!"],
  thunderstorm: ["Ooh, thunder!", "Storm's rolling in. Save often!", "Big storm. I'm not scared. Mostly."],
  snow: ["Snow day. I'll keep coding warm.", "It's snowing! ❄", "Brrr. Snow!"],
  fog: ["Foggy… where did the hills go?", "Fog's in. Let's take it slow.", "Misty out here."],
  windy: ["Whoa, windy!", "Hold on to your files!", "The wind's picking up."],
};
const BOLT = ["....ff....", "...ff.....", "...ff.....", "..ff......", "..ff......", ".ff.......", ".fffff....", "...ff.....", "...ff.....", "..ff......", "..ff......", ".ff.......", ".ff.......", "ff........"];
const wxPick = (list) => list[Math.floor(Math.random() * list.length)];

const wx = { shown: null, timer: 0, last: 0, parts: [], spawnAcc: 0, leafAt: 0, cap: 0, capAt: 0, meltT: 0, flashT: 0,
  nextRoll: Date.now() + 60000, lastSurprise: 0, qz: null, colours: {}, picked: false };
const wxScene = () => document.querySelector(".scene");

// ---------- the setting and the Random clock (FR-155 to FR-157, design D-7, D-9) ----------
const wxSetting = () => { const v = lookSettings().weather; return v === "random" || WX_NAMES.includes(v) ? v : "random"; };
// DEV only (design D-8): localStorage "studio.weatherFast" = 1 makes Random last 5-20 s instead of 5-20 minutes.
const wxFast = () => location.port === "4310" && store.get("weatherFast", 0) == 1;
const wxSpan = () => (wxFast() ? Math.floor(rand(5, 21)) : Math.floor(rand(300, 1201))) * 1000;
const wxValid = (n) => !!n && WX_NAMES.includes(n.weather) && Number.isFinite(n.since) && Number.isFinite(n.until)
  && n.until > n.since && n.until - n.since <= 1200000;
// The Random weather now, shared by every page of this channel; the first page to find it over picks the next one.
const wxNow = () => {
  const n = store.get("weatherNow", null);
  if (wxValid(n) && Date.now() < n.until) return n.weather;
  const again = store.get("weatherNow", null); // another tab may have just picked: use its choice
  if (wxValid(again) && Date.now() < again.until) return again.weather;
  const prev = wxValid(n) ? n.weather : wx.shown;
  const now = Date.now(), next = { weather: wxPick(WX_NAMES.filter((w) => w !== prev)), since: now, until: now + wxSpan() };
  store.set("weatherNow", next);
  wx.picked = true;
  return next.weather;
};
const wxCurrent = () => (wxSetting() === "random" ? wxNow() : wxSetting());

// ---------- colours and readability (FR-173, FR-176, FR-177, design §6) ----------
// Resolve any CSS colour (custom properties, color-mix) to [r, g, b] through a hidden probe in the given element.
const wxRgb = (host, css) => {
  const p = document.createElement("i");
  p.style.cssText = "position:absolute;visibility:hidden;color:" + css;
  host.append(p);
  const c = getComputedStyle(p).color;
  p.remove();
  // color-mix() comes back as color(srgb r g b) with 0-1 channels, everything else as rgb(0-255).
  const v = (c.match(/-?\d*\.?\d+(e-?\d+)?/gi) || ["255", "255", "255"]).slice(0, 3).map(Number);
  return c.startsWith("color(") ? v.map((x) => x * 255) : v;
};
const wxLum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
const wxContrast = (a, b) => { const [x, y] = [wxLum(a), wxLum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
// Step a brightness amount towards 0 until every text colour reads at 4.5:1 on the mixed background.
const wxReadable = (up, down, mixed, texts) => {
  for (; up > 0 || down > 0; up = Math.max(0, up - 1), down = Math.max(0, down - 1)) {
    const bgs = mixed(up, down);
    if (texts.every((t) => bgs.every((b) => wxContrast(t, b) >= 4.5))) break;
  }
  return [up, down];
};
const wxColours = () => {
  const sc = wxScene();
  for (const k of ["rain", "snow", "snow-edge", "flash", "flower-a", "flower-b", "grass-dark"]) wx.colours[k] = `rgb(${wxRgb(sc, `var(--${k})`).join(",")})`;
};
const wxTone = () => {
  const w = wx.shown, sc = wxScene();
  let [up, down] = WX_TONE[w];
  // Home: the greeting sits on the sky, so the sky may only change as far as the greeting stays readable.
  if (!CHAT && $("greeting")) {
    const text = wxRgb($("greeting"), "currentColor");
    const sky = (u, d, v) => wxRgb(sc, `color-mix(in srgb, color-mix(in srgb, var(${v}), var(--wx-bright) ${u}%), var(--wx-dark) ${d}%)`);
    [up, down] = wxReadable(up, down, (u, d) => [sky(u, d, "--sky-top"), sky(u, d, "--sky-bottom")], [text]);
  }
  sc.style.setProperty("--wx-up", up + "%");
  sc.style.setProperty("--wx-down", down + "%");
  // Fog washes the sky towards the fog colour, but never so far that it ends up brighter than Cloudy (QA F-1):
  // on a night sky or a dark custom world the fog colour is the lighter one, so the wash is cut back there.
  let fogmix = 0;
  if (w === "fog") {
    const lum = (v, f) => wxLum(wxRgb(sc, `color-mix(in srgb, color-mix(in srgb, var(${v}), var(--wx-dark) ${down}%), var(--fog) ${f}%)`));
    const usual = ["--sky-top", "--sky-bottom"].map((v) => wxLum(wxRgb(sc, `var(${v})`)));
    for (fogmix = 20; fogmix > 0 && ["--sky-top", "--sky-bottom"].some((v, i) => lum(v, fogmix) >= usual[i] * 0.99); fogmix -= 2);
  }
  sc.style.setProperty("--wx-fogmix", fogmix + "%");
  sc.style.setProperty("--wx-land", WX_LAND[w]);
  sc.style.setProperty("--wx-stars", { clear: 1, windy: 1, fog: 0.5 }[w] ?? 0.2);
  // Page background: --text and --muted keep 4.5:1 on it (FR-177).
  const b = document.body, texts = [wxRgb(b, "var(--text)"), wxRgb(b, "var(--muted)")];
  const page = (u, d) => [wxRgb(b, `color-mix(in srgb, color-mix(in srgb, var(--bg), #ffffff ${u}%), var(--wx-bg-dark) ${d}%)`)];
  const [bu, bd] = wxReadable(Math.max(0, WX_BG[w]), Math.max(0, -WX_BG[w]), page, texts);
  b.style.setProperty("--wx-bg-up", bu + "%");
  b.style.setProperty("--wx-bg-down", bd + "%");
  skyTween(); // the sky canvas follows the new colours as they ease (worlds-v2 FR-211)
};

// ---------- showing a weather (FR-159 to FR-168) ----------
const wxShow = (w, { instant = false, announce = false } = {}) => {
  const sc = wxScene(), prev = wx.shown;
  wx.shown = w;
  instant = instant || reduceMotion();
  if (instant) { sc.classList.add("wx-instant"); document.body.classList.add("wx-instant"); }
  sc.classList.toggle("wx-cloudy", ["cloudy", "rain", "thunderstorm", "snow"].includes(w));
  sc.classList.toggle("wx-foggy", w === "fog");
  sc.classList.toggle("wx-windy", w === "windy" && !reduceMotion());
  $("celestial")?.style.setProperty("--wx-dim", WX_DIM[w]);
  const rate = w === "windy" ? 4 : ["cloudy", "rain", "thunderstorm"].includes(w) ? 0.7 : 1;
  for (const c of sc.querySelectorAll(".cloud")) for (const a of c.getAnimations()) a.playbackRate = rate;
  wxTone();
  wxSnowCap(prev);
  if (instant) { getComputedStyle(sc).opacity; requestAnimationFrame(() => { sc.classList.remove("wx-instant"); document.body.classList.remove("wx-instant"); }); }
  if (announce) wxLine(w);
  wxSelect();
  wxStart();
};
// The companion notices: one line, unless asleep or thinking (FR-169). After the hello wave on page load.
const wxLine = (w) => {
  if (pet.mode === "wave") { setTimeout(() => wx.shown === w && wxLine(w), 2600); return; }
  if (pet.mode === "sleep" || pet.mode === "think") return;
  say(wxPick(WX_LINES[w]));
};
// Re-read the setting and the clock; show the weather if it changed.
const wxRefresh = (announce = true) => {
  wx.picked = false;
  const w = wxCurrent();
  if (w !== wx.shown) wxShow(w, { instant: wx.shown === null, announce: announce && (wx.shown !== null || wx.picked) });
  else wxSelect();
};

// ---------- land-bound layers: flash, snow cap, fog, canvas (design §4, §5) ----------
const wxBuild = () => {
  const sc = wxScene();
  const flash = el("div", "wx-flash");
  sc.querySelector(".land-ground").before(flash);
  sc.append(el("div", "wx-cap"), el("div", "wx-fog"), el("canvas", "wx-fx"));
  // Four more clouds for the cloudy weathers, drawn and drifting like the others.
  const clouds = sc.querySelector(".clouds");
  for (let i = 0; i < 4; i++) {
    const c = el("div", "cloud wx-extra");
    c.innerHTML = pixelSvg(CLOUD, CLOUD_PAL, CHAT ? [3, 4, 3, 4][i] : [5, 6, 4, 7][i]);
    c.style.top = `${CHAT ? [20, 30, 44, 12][i] : [6, 18, 34, 10][i]}%`;
    c.style.animationDuration = `${[140, 120, 160, 180][i]}s`;
    c.style.animationDelay = `${-[10, 70, 40, 100][i]}s`;
    clouds.append(c);
  }
};
const wxCapSvg = () => {
  const { W, H } = worldSize(), gt = scene.groundTop, rows = wx.cap * Math.ceil(scene.px / 2), r = []; // thick enough for the art pixels
  if (rows > 0) {
    r.push(`<rect x="-16" y="${gt}" width="${W + 32}" height="${rows}" fill="var(--snow)"/><rect x="-16" y="${gt + rows}" width="${W + 32}" height="1" fill="var(--snow-edge)"/>`);
    for (const [x, y, s] of scene.tops || []) r.push(`<rect x="${x}" y="${y}" width="${s}" height="${rows}" fill="var(--snow)"/><rect x="${x}" y="${y + rows}" width="${s}" height="1" fill="var(--snow-edge)"/>`);
  }
  wxScene().querySelector(".wx-cap").innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" preserveAspectRatio="none" shape-rendering="crispEdges" overflow="visible">${r.join("")}</svg>`;
};
// Snow builds a cap over about 2 minutes and it melts over a minute after the weather changes (FR-163).
const wxSnowCap = (prev) => {
  const cap = wxScene().querySelector(".wx-cap");
  if (wx.shown === "snow") {
    clearTimeout(wx.meltT);
    cap.classList.remove("melting");
    if (reduceMotion()) wx.cap = 4; else if (!wx.cap) { wx.cap = 1; wx.capAt = Date.now(); }
    wxCapSvg();
  } else if (prev === "snow" || wx.cap) {
    if (reduceMotion()) { wx.cap = 0; wxCapSvg(); return; }
    cap.classList.add("melting");
    clearTimeout(wx.meltT);
    wx.meltT = setTimeout(() => { wx.cap = 0; wxCapSvg(); cap.classList.remove("melting"); }, 60000);
  }
};
const wxCapGrow = () => {
  if (wx.shown !== "snow" || wx.cap >= 4 || Date.now() - wx.capAt < 30000) return;
  wx.cap++; wx.capAt = Date.now(); wxCapSvg();
};
const wxFogBands = () => {
  const { W } = worldSize(), gt = scene.groundTop;
  const bands = CHAT ? [[gt - 34, 28, 0.6, 70], [gt - 14, 24, 0.45, 55], [gt + 16, 20, 0.35, 80]]
    : [[gt - 112, 40, 0.6, 70], [gt - 48, 32, 0.45, 55], [gt + 20, 24, 0.35, 80]];
  wxScene().querySelector(".wx-fog").innerHTML = bands.map(([y, h, o, dur], i) => {
    let d = `M0 ${h}`;
    for (let x = 0; x <= W * 2; x += 8) d += ` L${x} ${(Math.round(Math.sin(x / 37 + i) * 2) + 2) * 2} L${x + 8} ${(Math.round(Math.sin(x / 37 + i) * 2) + 2) * 2}`;
    return `<svg class="wx-band" style="top:${y}px;height:${h}px;opacity:${o};animation-duration:${dur}s;animation-direction:${i === 1 ? "alternate-reverse" : "alternate"}" viewBox="0 0 ${W * 2} ${h}" preserveAspectRatio="none" shape-rendering="crispEdges"><path d="${d} L${W * 2} ${h} Z" fill="var(--fog)"/></svg>`;
  }).join("");
};
// Home: no particles or bolts over the greeting and its sub-line, plus 12 px around them (design D-4, FR-173).
const wxQuietZone = () => {
  const g = !CHAT && $("greeting");
  if (!g) { wx.qz = null; return; }
  const w = worldEl().getBoundingClientRect(), sub = g.parentElement.querySelector(".sub");
  const boxes = [g, sub].filter(Boolean).map((n) => n.getBoundingClientRect());
  wx.qz = { x: Math.min(...boxes.map((b) => b.left)) - w.left - 12, y: Math.min(...boxes.map((b) => b.top)) - w.top - 12,
    r: Math.max(...boxes.map((b) => b.right)) - w.left + 12, b: Math.max(...boxes.map((b) => b.bottom)) - w.top + 12 };
};
const wxQuiet = (x, y) => !!wx.qz && x > wx.qz.x && x < wx.qz.r && y > wx.qz.y && y < wx.qz.b;
// Called by world.js whenever the land is redrawn (resize, world switch).
wxLand = () => {
  if (!wxScene()?.querySelector(".wx-fx")) return;
  const { W, H } = worldSize(), cv = wxScene().querySelector(".wx-fx"), dpr = devicePixelRatio || 1;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  cv.getContext("2d").setTransform(dpr, 0, 0, dpr, 0, 0);
  wxScene().querySelector(".wx-flash").style.clipPath = `inset(0 0 ${Math.max(0, H - scene.groundTop)}px 0)`; // sky and hills only
  wxQuietZone();
  wxCapSvg();
  wxFogBands();
  if (wx.shown) { wxColours(); wxTone(); if (reduceMotion()) wxStill(); }
};

// ---------- particles (design §5, FR-174) ----------
const wxCap = () => Math.round((WX_CAPS[wx.shown] || 0) * (CHAT ? 0.5 : 1) * (worldSize().W < 600 ? 0.5 : 1));
const wxSpawn = () => {
  const { W, H } = worldSize(), gt = scene.groundTop, w = wx.shown;
  if (w === "rain" || w === "thunderstorm") return { k: "drop", x: rand(-40, W), y: rand(-30, -4), v: w === "rain" ? rand(380, 460) : rand(480, 560), land: rand(gt, H - 8) };
  if (w === "snow") return { k: "flake", x: rand(0, W), y: rand(-20, -4), v: rand(22, 42), big: Math.random() < 0.3, ph: rand(0, 6), per: rand(2.5, 4), land: rand(gt, H - 8) };
  return { k: "leaf", x: -8, y: rand(gt * 0.3, H - 20), v: rand(160, 240), ph: rand(0, 6), c: Math.random() < 0.5 ? "flower-a" : "flower-b" };
};
const wxFrame = () => {
  const now = performance.now(), dt = Math.min(0.1, (now - (wx.last || now)) / 1000);
  wx.last = now;
  const { W, H } = worldSize(), cv = wxScene().querySelector(".wx-fx"), ctx = cv.getContext("2d"), c = wx.colours, w = wx.shown;
  const cap = wxCap();
  if (w === "windy") {
    if (Date.now() >= wx.leafAt) { for (let i = Math.ceil(rand(0, 3)); i > 0 && wx.parts.length < cap; i--) wx.parts.push(wxSpawn()); wx.leafAt = Date.now() + rand(2000, 4000); }
  } else if (cap) {
    // Spawn at the rate that keeps about "cap" particles in the air: cap / (time to fall through the scene).
    const life = H / (w === "snow" ? 32 : w === "rain" ? 420 : 520);
    wx.spawnAcc += (cap * dt) / life;
    for (; wx.spawnAcc >= 1; wx.spawnAcc--) if (wx.parts.length < cap) wx.parts.push(wxSpawn());
  }
  ctx.clearRect(0, 0, W, H);
  const block = (x, y, s, col) => { ctx.fillStyle = col; ctx.fillRect(Math.round(x / 2) * 2, Math.round(y / 2) * 2, s, s); };
  for (const p of wx.parts) {
    if (p.k === "drop") {
      if (p.splash != null) { // a 1-2 frame splash where the drop lands (FR-161)
        const o = p.splash++ < 1 ? 4 : 6;
        if (!wxQuiet(p.x, p.y)) { block(p.x - o, p.y - 2, 2, c.rain); block(p.x + o, p.y - 2, 2, c.rain); }
        if (p.splash > 2) p.dead = true;
        continue;
      }
      p.y += p.v * dt; p.x += p.v * dt * 0.18;
      if (p.y >= p.land) { p.y = p.land; p.splash = 0; continue; }
      if (!wxQuiet(p.x, p.y)) for (let j = 0; j < 3; j++) block(p.x - j, p.y - j * 3, 2, c.rain);
    } else if (p.k === "flake") {
      p.y += p.v * dt;
      const x = p.x + Math.sin((Date.now() / 1000) * (2 * Math.PI / p.per) + p.ph) * 6;
      if (p.y >= p.land) { p.dead = true; continue; }
      if (!wxQuiet(x, p.y)) {
        block(x, p.y, p.big ? 4 : 2, c.snow);
        if (p.big) block(x + 2, p.y + 2, 2, c["snow-edge"]);
        else if (effectiveTheme() === "light") block(x, p.y + 2, 2, c["snow-edge"]); // reads on a bright sky (design D-5)
      }
    } else {
      p.x += p.v * dt;
      const y = p.y + Math.sin(Date.now() / 300 + p.ph) * 10;
      if (p.x > W + 8) { p.dead = true; continue; }
      if (!wxQuiet(p.x, y)) { block(p.x, y, 4, c[p.c]); block(p.x + 4, y - 2, 2, c["grass-dark"]); }
    }
  }
  wx.parts = wx.parts.filter((p) => !p.dead);
  if (!wx.parts.length && !cap) wxStop(); // nothing falling and nothing to spawn: no timer (design D-2)
};
const wxStop = () => { clearInterval(wx.timer); wx.timer = 0; wx.last = 0; };
const wxStart = () => {
  clearTimeout(wx.flashT);
  if (reduceMotion()) { wxStop(); wx.parts = []; wxStill(); return; }
  if (document.hidden) return;
  if (!wx.timer && (wxCap() || wx.parts.length)) wx.timer = setInterval(wxFrame, 33); // at most 30 frames a second
  if (wx.shown === "thunderstorm") wxFlashLater();
};
// Reduced motion: one still pattern, redrawn only on resize or theme change (FR-172).
const wxStill = () => {
  const { W, H } = worldSize(), ctx = wxScene().querySelector(".wx-fx").getContext("2d"), c = wx.colours, w = wx.shown, gt = scene.groundTop;
  ctx.clearRect(0, 0, W, H);
  let seed = 3;
  const r = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  const block = (x, y, s, col) => { ctx.fillStyle = col; ctx.fillRect(Math.round(x / 2) * 2, Math.round(y / 2) * 2, s, s); };
  const n = Math.round(wxCap() * (w === "snow" ? 1 : 0.4));
  for (let i = 0; i < n; i++) {
    const x = r() * W, y = r() * (H - 10);
    if (wxQuiet(x, y)) continue;
    if (w === "rain" || w === "thunderstorm") for (let j = 0; j < 3; j++) block(x - j, y - j * 3, 2, c.rain);
    if (w === "snow") { const big = r() < 0.3; block(x, y, big ? 4 : 2, c.snow); if (big) block(x + 2, y + 2, 2, c["snow-edge"]); }
  }
  if (w === "windy") { block(W * 0.3, gt + 30, 4, c["flower-a"]); block(W * 0.7, gt + 46, 4, c["flower-b"]); }
};

// ---------- lightning (FR-162): every 8-25 s, at most 150 ms, sky and hills only ----------
const wxFlashLater = () => { clearTimeout(wx.flashT); wx.flashT = setTimeout(wxFlash, rand(8000, 25000)); };
const wxFlash = () => {
  if (wx.shown !== "thunderstorm" || reduceMotion() || document.hidden) return;
  const f = wxScene().querySelector(".wx-flash");
  f.innerHTML = "";
  if (Math.random() < 0.5) { // a pixel bolt in the far sky, clear of the greeting and the sun or moon
    const { W } = worldSize(), sun = $("celestial")?.getBoundingClientRect(), wr = worldEl().getBoundingClientRect();
    for (let i = 0; i < 10; i++) {
      const x = rand(20, W - 50), y = rand(8, Math.max(12, scene.groundTop * 0.45 - 42));
      const overSun = sun && sun.width && x + 30 > sun.left - wr.left && x < sun.right - wr.left && y < sun.bottom - wr.top;
      if (wxQuiet(x, y) || wxQuiet(x + 30, y + 42) || overSun) continue;
      f.innerHTML = pixelSvg(BOLT, { f: "var(--flash)" }, 3);
      Object.assign(f.firstChild.style, { left: `${Math.round(x)}px`, top: `${Math.round(y)}px` });
      break;
    }
  }
  f.animate([{ opacity: 0.55 }, { opacity: 0.55, offset: 0.33 }, { opacity: 0 }], { duration: 150 });
  // The companion looks surprised, at most once a minute (FR-170). Custom creatures have no expressions: skipped.
  if (wxCalm() && Date.now() - wx.lastSurprise >= 60000) {
    wx.lastSurprise = Date.now();
    pet.expr = "surprised"; drawPet();
    setTimeout(() => { if (pet.expr === "surprised" && !pet.hover) { pet.expr = "normal"; drawPet(); } }, 1000);
  }
  wxFlashLater();
};

// ---------- the companion (FR-170, FR-171) ----------
// Weather reactions only while the companion is free: not asleep, thinking, checking in, hovered or reacting to a click.
const wxCalm = () => !reduceMotion() && pet.mode === "idle" && !pet.checkin && !pet.hover && Date.now() >= pet.reactUntil
  && Date.now() >= pet.dizzyUntil && pet.dance < Date.now();
const wxReact = () => {
  if (Date.now() < wx.nextRoll) return;
  wx.nextRoll = Date.now() + 60000; // at most one reaction a minute
  if (!wxCalm() || Math.random() >= 0.5) return;
  const p = $("pet");
  if (wx.shown === "rain" || wx.shown === "thunderstorm") {
    pet.pauseUntil = Math.max(pet.pauseUntil, Date.now() + 900);
    p.classList.remove("wx-hop"); void p.offsetWidth; p.classList.add("wx-hop");
    setTimeout(() => p.classList.remove("wx-hop"), 600);
    const fx = pet.x + SIZE.w / 2, fy = pet.y + SIZE.h; // a puddle splash at its feet
    wx.parts.push({ k: "drop", x: fx - 6, y: fy, splash: 0 }, { k: "drop", x: fx + 6, y: fy, splash: 0 });
  } else if (wx.shown === "snow") {
    p.classList.remove("wx-shiver"); void p.offsetWidth; p.classList.add("wx-shiver");
    setTimeout(() => p.classList.remove("wx-shiver"), 600);
  }
};
// Walking into the wind is slower, with it faster (wind blows left to right, like the clouds).
wxWalk = (dx) => (wx.shown === "windy" ? (dx > 0 ? 1.15 : 0.8) : 1);

// ---------- Settings and Ctrl K (FR-155, FR-156, FR-158) ----------
const wxSelect = () => {
  const sel = $("setWeather");
  if (!sel) return;
  const s = wxSetting();
  sel.innerHTML = `<option value="random">Random${s === "random" && wx.shown ? " · now " + WX_LABEL[wx.shown] : ""}</option>`
    + WX_NAMES.map((n) => `<option value="${n}">${WX_LABEL[n]}</option>`).join("");
  sel.value = s;
  if ($("wxHint")) $("wxHint").hidden = s !== "random";
  if ($("wxRm")) $("wxRm").hidden = !reduceMotion();
};
const wxChoose = (v) => {
  if (v !== "random" && !WX_NAMES.includes(v)) return;
  store.set("settings", { ...store.get("settings", {}), weather: v });
  wxRefresh(true);
};
if ($("setWeather")) $("setWeather").onchange = (e) => wxChoose(e.target.value);

// ---------- start, and keep in step with other pages, the theme and visibility ----------
wxBuild();
// Still clouds (reduced motion) are spread across the sky (see styles.css).
wxScene().querySelectorAll(".cloud").forEach((c, i) => c.style.setProperty("--rm-left", `${[8, 58, 30, 78, 44, 18, 68, 88][i % 8]}%`));
wxColours();
wxLand();
wxRefresh(true);
addEventListener("storage", (e) => { if (e.key === "studio.settings" || e.key === "studio.weatherNow") wxRefresh(true); });
setInterval(() => { if (document.hidden) return; wxRefresh(true); wxCapGrow(); wxReact(); }, 5000);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) { wxStop(); clearTimeout(wx.flashT); return; }
  wxRefresh(true); // a change that came due while hidden happens now
  wxStart();
});
const wxRetheme = () => { if (!wx.shown) return; wxColours(); wxTone(); if (reduceMotion()) wxStill(); };
new MutationObserver(wxRetheme).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme", "data-style"] });
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", wxRetheme);
matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", () => { wxShow(wx.shown, { instant: true }); });
addEventListener("studio-theme", wxRetheme);
addEventListener("studio-world", () => setTimeout(wxRetheme, 0));
