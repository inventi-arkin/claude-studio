// Ctrl K palette (spec look-and-feel FR-44, FR-45, design 6.4): one search over chats, projects, actions and
// commands, on Home and the chat page. Loaded last; uses look.js (api, $, el, store, ago, applyLook, STUDIO_COMMANDS,
// rankMatches, resultRow)
// and, on the chat page, app.js (openChat, newChat, chooseProject, pickCommand).
(() => {
  const onChatPage = typeof openChat === "function";
  const dlg = el("dialog", "palette");
  dlg.setAttribute("aria-label", "Search Claude Studio");
  dlg.innerHTML = `<div class="palette-box">
    <div class="palette-search"><span aria-hidden="true">🔍</span>
      <input id="paletteInput" type="text" autocomplete="off" spellcheck="false" placeholder="Search chats, projects, actions and commands"
        role="combobox" aria-expanded="true" aria-controls="paletteList" aria-autocomplete="list" aria-label="Search Claude Studio"></div>
    <div class="palette-list" id="paletteList" role="listbox" aria-label="Results"></div></div>`;
  document.body.append(dlg);
  const input = dlg.querySelector("#paletteInput"), list = dlg.querySelector("#paletteList");
  const p = { data: null, items: [], index: 0, back: null };

  // From Home, a choice opens the chat page (the pending hand-over that home.js already uses).
  const toChat = (pending, hash = "") => {
    try { if (pending) sessionStorage.setItem("studio.pending", JSON.stringify(pending)); } catch {}
    location.href = "/chat" + hash;
  };
  const switchTheme = () => {
    const dark = (document.documentElement.dataset.theme || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")) === "dark";
    store.set("settings", { ...store.get("settings", {}), theme: dark ? "light" : "dark" });
    applyLook();
    dispatchEvent(new Event("studio-theme"));
  };
  const actions = () => [
    { name: "New chat", run: () => (onChatPage ? newChat() : toChat(null)) },
    { name: "Home", run: () => { location.href = "/"; } },
    { name: "Settings", run: () => $("openSettings")?.click() },
    { name: "Companion, world & weather", aliases: ["companion", "world", "weather", "pet", "paw"], run: () => openScene() }, // spec scene-menu FR-183
    { name: "Command console", run: () => studioConsole.open() },
    ...(onChatPage ? [
      { name: "Toggle sidebar", run: () => (matchMedia("(max-width: 860px)").matches || document.querySelector(".app").classList.contains("side-hidden") ? $("toggleSidebar") : $("hideSidebar")).click() },
      { name: "Toggle files panel", run: () => $("toggleOutputs").click() },
    ] : []),
    { name: "Switch theme", run: switchTheme },
    // Weather (spec weather FR-158): sets the same setting as Settings → Look.
    ...(typeof wxChoose === "function" ? ["random", ...WX_NAMES].map((w) => ({ name: "Weather: " + (w === "random" ? "Random" : WX_LABEL[w]), aliases: ["weather " + w, w], run: () => wxChoose(w) })) : []),
  ].map((a) => ({ ...a, key: a.name, group: "Actions", tag: "Action", desc: "" }));

  const load = async () => {
    const get = (u) => api(u).then((r) => (r.ok ? r.json() : [])).catch(() => []);
    const [chats, projects, commands] = await Promise.all([get("/api/chats"), get("/api/projects"), get("/api/commands")]);
    const studio = STUDIO_COMMANDS.map((c) => ({ ...c, aliases: c.aliases || [], studio: true }));
    const taken = new Set(studio.flatMap((c) => [c.name, ...c.aliases]));
    return {
      chats: [...chats].sort((a, b) => (b.updated || 0) - (a.updated || 0)).map((c) => ({ name: c.title, key: c.title, desc: (c.project || "General") + " · " + ago(c.updated || c.created || Date.now()), group: "Chats", tag: "Chat",
        run: () => (onChatPage ? openChat(c) : toChat(null, "#" + c.id)) })),
      projects: projects.map((name) => ({ name, key: name, desc: "", group: "Projects", tag: "Project",
        run: () => (onChatPage ? chooseProject(name) : toChat({ project: name })) })),
      commands: [...studio, ...commands.filter((c) => !taken.has(c.name))].map((c) => ({ name: "/" + c.name, key: c.name, aliases: c.aliases || [], hint: c.argumentHint, desc: c.description || "", group: "Commands", tag: c.console ? "Console" : "Command",
        // Console commands open the command console on both pages (design command-console 2.3).
        run: () => (c.console ? studioConsole.open(c.argumentHint ? { fill: "/" + c.name + " " } : { run: "/" + c.name })
          : onChatPage ? pickCommand(c) : toChat({ draft: "/" + c.name + " " })) })),
    };
  };

  // Shared matching with the / menu (rankMatches in look.js). Empty: recent chats, projects and actions;
  // text starting with "/" searches commands only, as in the message box.
  const ORDER = ["Projects", "Actions", "Commands", "Chats"];
  const rank = (q) => {
    const d = p.data, f = q.trim();
    if (!f) return [...d.chats.slice(0, 5).map((c) => ({ ...c, group: "Recent chats" })), ...d.projects, ...actions()];
    const all = f.startsWith("/") ? d.commands : [...d.projects, ...actions(), ...d.commands, ...d.chats];
    return rankMatches(all, f, ORDER).slice(0, 50);
  };
  const render = () => {
    const q = input.value;
    p.items = p.data ? rank(q) : [];
    p.index = 0;
    list.innerHTML = "";
    if (!p.data) { list.append(el("p", "cmd-empty", "Loading…")); return; }
    if (!p.items.length) { list.append(el("p", "cmd-empty", `Nothing matches “${q.trim()}”.`)); input.removeAttribute("aria-activedescendant"); return; }
    let group = null;
    p.items.forEach((x, i) => {
      if (!q.trim() && x.group !== group) { group = x.group; list.append(el("div", "cmd-group", group)); }
      list.append(resultRow({ id: "pal-" + i, name: x.name, hint: x.hint, desc: x.desc, tag: x.tag, onPick: () => choose(i) }));
    });
    move(0);
  };
  const move = (i) => {
    if (!p.items.length) return;
    p.index = (i + p.items.length) % p.items.length;
    list.querySelectorAll(".cmd-item").forEach((o, k) => o.setAttribute("aria-selected", String(k === p.index)));
    const cur = dlg.querySelector("#pal-" + p.index);
    input.setAttribute("aria-activedescendant", cur.id);
    cur.scrollIntoView({ block: "nearest" });
  };
  const choose = (i) => {
    const x = p.items[i];
    if (!x) return;
    p.back = null; // the choice decides where focus goes
    dlg.close();
    x.run();
  };
  const open = async () => {
    if (dlg.open) return;
    p.back = document.activeElement;
    input.value = "";
    dlg.showModal();
    input.focus();
    render();
    p.data = await load();
    if (dlg.open) render();
  };
  window.openPalette = open;
  input.oninput = render;
  input.onkeydown = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); move(p.index + 1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); move(p.index - 1); }
    else if (e.key === "Enter") { e.preventDefault(); choose(p.index); }
  };
  dlg.addEventListener("close", () => { if (p.back && document.contains(p.back)) p.back.focus(); });
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); }); // the backdrop
  addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === "k") { e.preventDefault(); dlg.open ? dlg.close() : open(); }
  });
  $("openPalette")?.addEventListener("click", open);
})();
