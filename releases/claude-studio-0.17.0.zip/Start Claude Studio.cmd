@echo off
cd /d "%~dp0"
start "" http://localhost:4300
npm run live
