@echo off
rem Installs Claude Studio from this folder (a release from the website). Spec updates FR-227.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\migrate.ps1" -Import "%~dp0."
pause
