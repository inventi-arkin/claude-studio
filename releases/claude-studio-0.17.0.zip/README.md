# Claude Studio

A local web UI for Claude Code, built on the Claude Agent SDK. It runs on this PC only (bound to 127.0.0.1) and uses the Home setup in `C:\claude`: settings, hooks, skills, memory and `projects\`.

## Two channels

| Channel | URL | Runs | Use it for |
|---|---|---|---|
| **DEV** | http://localhost:4310 | The working copy in this folder; restarts when `server.js` changes | Building and trying changes |
| **LIVE** | http://localhost:4300 | A committed, deployed release in `.deploy/releases/<sha>` | Daily use; never changes until you deploy |

Changes reach LIVE only through a commit plus `npm run deploy`, so an edit in progress can't break the version you use every day.

## Commands

```
npm run dev        # DEV server on 4310
npm run deploy     # deploy HEAD to LIVE (working tree must be clean)
npm run deploy -- <sha|tag>   # deploy a specific commit
npm run rollback   # switch LIVE back to the previous release
npm run releases   # list releases (* = live)
npm run live       # run the LIVE supervisor on 4300 (restarts itself on deploy/rollback)
```

Double-click `Start Claude Studio.cmd` to start LIVE and open it in the browser.

## Another PC

The easy way: double-click **`Export Claude Studio.cmd`** here, copy the zip to the other PC, unzip it and double-click **`Install Claude Studio.cmd`**. The installer offers to install what is missing (Node.js LTS and Git with winget, Claude Code with its official installer, asking first) and opens the Claude sign-in if needed.

Behind both is `scripts/migrate.ps1`, which moves Studio (the committed code and its git history; no chats, no Home setup) to another Windows PC:

```
powershell -ExecutionPolicy Bypass -File scripts\migrate.ps1 -Export          # here: zip in <Home>\output\migrate
powershell -ExecutionPolicy Bypass -File migrate.ps1 -Import <zip>            # there, from the unzipped folder
```

The import needs Node 22+, Git and Claude Code (signed in with `claude`). It clones into `C:\claude\projects\Claude-Studio` (`-ClaudeHome` to change; a minimal Home is created if none exists), runs `npm ci` and `npm run deploy`, creates the Claude Studio desktop shortcut and starts LIVE. It never overwrites an existing Studio folder.

## Layout

- `server.js`: Express server. Runs Claude through `query()` from `@anthropic-ai/claude-agent-sdk` with `cwd` = Home and settings sources user/project/local. It streams SDK messages to the browser as NDJSON and sends permission prompts and `AskUserQuestion` to the page.
- `public/`: the page. **Look and feel tokens live in `public/theme.css`**; the in-app Settings dialog (theme, accent, text size, font, width) overrides them per browser.
- Weather (`public/weather.js`, v0.11): browser-only decoration. To test Random quickly on DEV, run `localStorage.setItem("studio.weatherFast", "1")` in the page console. Random then changes every 5–20 seconds instead of 5–20 minutes. This starts from the next change: the weather showing now keeps its 5–20 minutes. To switch straight away, also run `localStorage.removeItem("studio.weatherNow")` and reload (a new weather is picked at once, with the short timing). LIVE (port 4300) ignores this. Remove the key to go back.
- `scripts/deploy.mjs`, `scripts/live.mjs`: release export (`git archive`), rollback, and the LIVE supervisor.
- `updater.js`, `scripts/update-finish.mjs`, `scripts/publish.mjs`, `site/`, `release.json` (v0.17): updates from the website, and publishing to it.
- Chat index: `data/chats.json` (DEV) and `.deploy/data/chats.json` (LIVE). Chat history itself is read from Claude Code's own session files.

## Security

- The server listens on 127.0.0.1 only.
- It rejects other Host headers and cross-site Origins.
- Every write request needs the `X-Studio: 1` header, so other websites can't drive Claude.
- **Outbound:** Studio itself makes one kind of outbound request, the update check (v0.17, spec `specs/updates.md`).
  - **What it reads:** LIVE fetches `latest.json` and its signature from https://inventi-arkin.github.io/claude-studio/ when it starts, every 6 hours, and on Check for updates. It sends nothing about you, the PC, chats or files: just a plain GET.
  - **Turning it off:** Settings → Updates → "Check for updates automatically".
  - **Installing:** the release zip is downloaded only when you click Update. It's installed only if `latest.json`'s Ed25519 signature matches the public key in `scripts/release-key.pub.js` and the zip's SHA-256 matches.
  - **Claude itself:** Claude Code's own traffic to Anthropic is separate and unchanged.

## Publishing a release (this PC only)

- **One-time setup:**
  - `node scripts/release-key.mjs` makes the signing key: the private key goes to `%USERPROFILE%\.claude-studio\release-key.pem` (back it up; never share it), and the public key to `scripts/release-key.pub.js` (commit it).
  - On GitHub, create the public repository `inventi-arkin/claude-studio`, empty (no README). Its `main` branch appears with the first publish; after that, once, in Settings → Pages choose "Deploy from a branch", `main`, `/` (root).
- **Each release:** after QA, with LIVE running the committed HEAD, run `npm run publish-release`. It asks for the version, title and release notes, commits `release.json`, deploys, builds a snapshot zip (app files only: no history, specs, designs, tests or site), signs `latest.json`, renders `site\` and pushes it to the repository's main branch. `--dry-run` builds without pushing; `--push` retries a failed push.
- **Older installs:** a Studio from before v0.17 has no updater. On that PC, unzip the latest release and double-click "Install Claude Studio.cmd": it offers to upgrade the existing Studio in place, keeping its data.
- **What the site holds:** the website, `latest.json` with its signature, and the last 5 release zips, in `%USERPROFILE%\.claude-studio\site`. Each publish adds one commit there, by "Claude Studio releases".
