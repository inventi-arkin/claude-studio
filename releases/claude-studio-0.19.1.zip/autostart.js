// Start LIVE when I sign in to Windows (spec autostart FR-235 to FR-244).
// The only record is one launcher file in the user's Startup folder (FR-238): a small .vbs that runs
// scripts/live.mjs hidden, with --if-free so a copy that is already running is left alone (FR-240).
// Nothing is taken from the page: the folder and node path are always this server's own (FR-243).
import fs from "node:fs";
import path from "node:path";

const NAME = "Claude Studio (LIVE).vbs";
const MARK = "' Claude Studio (LIVE) startup launcher. Made by Settings > Updates > Startup; turn it off there.";

// Windows Script Host reads UTF-16 with a byte order mark, so a folder with accents or symbols still works.
const readLauncher = (file) => {
  const buf = fs.readFileSync(file);
  return buf[0] === 0xff && buf[1] === 0xfe ? buf.subarray(2).toString("utf16le") : buf.toString("utf8");
};
const writeLauncher = (file, text) => fs.writeFileSync(file, Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(text, "utf16le")]));
const q = (s) => s.replace(/"/g, '""');

export const setupAutostart = (app, { CHANNEL, APP_DIR }) => {
  // The same layout check as updates: LIVE runs from <Studio folder>\.deploy\releases\<sha>.
  const ROOT = path.resolve(APP_DIR, "..", "..", "..");
  const live = CHANNEL === "live" && process.platform === "win32" && fs.existsSync(path.join(ROOT, "scripts", "live.mjs")) && path.basename(path.dirname(APP_DIR)) === "releases";
  const dir = process.env.APPDATA ? path.join(process.env.APPDATA, "Microsoft", "Windows", "Start Menu", "Programs", "Startup") : null;
  const file = dir && path.join(dir, NAME);

  const body = () => [
    MARK,
    'Set sh = CreateObject("WScript.Shell")',
    `sh.CurrentDirectory = "${q(ROOT)}"`,
    `sh.Run """${q(process.execPath)}"" scripts\\live.mjs --if-free", 0, False`,
    "",
  ].join("\r\n");

  // What the launcher on disk says: on or off, and whether it still fits this folder (FR-238, FR-239).
  const read = () => {
    if (!live) return { live: false };
    if (!fs.existsSync(dir)) return { live: true, error: "Couldn't read the Startup folder." };
    if (!fs.existsSync(file)) return { live: true, on: false };
    let text;
    try { text = readLauncher(file); } catch { return { live: true, error: "Couldn't read the Startup folder." }; }
    const folder = /sh\.CurrentDirectory = "((?:[^"]|"")*)"/.exec(text)?.[1]?.replace(/""/g, '"');
    const node = /sh\.Run """((?:[^"]|"")*?)"" /.exec(text)?.[1]?.replace(/""/g, '"');
    const stale = !folder || !fs.existsSync(path.join(folder, "scripts", "live.mjs")) ? "missing" : !node || !fs.existsSync(node) ? "node" : path.resolve(folder).toLowerCase() !== ROOT.toLowerCase() ? "other" : null;
    return { live: true, on: true, ...(stale ? { stale, folder: folder || "" } : {}) };
  };
  const view = () => read();
  const write = (res) => {
    try { writeLauncher(file, body()); res.json(view()); }
    catch { res.status(500).json({ ...view(), error: "Couldn't change the Startup folder: it isn't writable." }); }
  };

  app.get("/api/autostart", (req, res) => res.json(view()));
  app.post("/api/autostart", (req, res) => {
    if (!live) return res.status(400).json({ error: "Switch this on from the LIVE channel." });
    if (typeof req.body?.on !== "boolean") return res.status(400).json({ error: "Say on or off." });
    if (req.body.on) return write(res);
    try { fs.rmSync(file, { force: true }); res.json(view()); }
    catch { res.status(500).json({ ...view(), error: "Couldn't change the Startup folder: it isn't writable." }); }
  });
  app.post("/api/autostart/fix", (req, res) => {
    if (!live) return res.status(400).json({ error: "Switch this on from the LIVE channel." });
    write(res);
  });
};
