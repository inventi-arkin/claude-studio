// Claude Studio: a local web UI for Claude Code (Agent SDK), served on 127.0.0.1 only.
import express from "express";
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { fileURLToPath } from "node:url";
import os from "node:os";
import { query, getSessionMessages } from "@anthropic-ai/claude-agent-sdk";
import { setupUpdates } from "./updater.js";
import { setupAutostart } from "./autostart.js";
import { COMPANION_SCHEMA, PLACE_SCHEMA, COMPANION_PROMPT, PLACE_PROMPT, MAX_WORLDS, checkWorld, checkCompanion, checkPlace, toCompanion, toPlace, readable } from "./worlds.js";

const APP_DIR = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 4310);
const CHANNEL = process.env.STUDIO_CHANNEL || "dev"; // "dev" or "live"
const VERSION = process.env.STUDIO_VERSION || "working copy";

// Home is the nearest ancestor holding .claude/ and projects/ (works for the project folder and deployed releases).
const findHome = (dir) => {
  for (let d = dir; d !== path.dirname(d); d = path.dirname(d)) {
    // The same rule as homeProblem: a fresh Home on another PC has no Home scripts yet (scripts/migrate.ps1).
    if (fs.existsSync(path.join(d, ".claude")) && fs.existsSync(path.join(d, "projects"))) return d;
  }
  throw new Error("Could not find Home (a folder with .claude/ and projects/)");
};
const DATA = path.resolve(process.env.STUDIO_DATA || path.join(APP_DIR, "data"));
const CHATS_FILE = path.join(DATA, "chats.json");
const CONFIG_FILE = path.join(DATA, "config.json");
fs.mkdirSync(DATA, { recursive: true });

// A Claude Home must be an absolute local folder (not a network share, no "..") holding .claude\ and projects\.
const homeProblem = (p) => {
  if (typeof p !== "string" || !p.trim()) return "Enter a folder path.";
  if (p.length > 260) return "The path is too long.";
  if (/^[\\/]{2}/.test(p)) return "Network shares are not allowed; use a folder on this PC.";
  if (!path.isAbsolute(p) || (process.platform === "win32" && !/^[A-Za-z]:[\\/]/.test(p))) return "Use a full path, for example C:\\claude.";
  if (p.split(/[\\/]/).includes("..")) return 'The path may not contain "..".';
  let st;
  try { st = fs.statSync(p); } catch { return "That folder does not exist."; }
  if (!st.isDirectory()) return "That is not a folder.";
  for (const sub of [".claude", "projects"]) {
    try { if (!fs.statSync(path.join(p, sub)).isDirectory()) throw 0; } catch { return `That folder has no ${sub}\\ folder inside, so it is not a Claude Home.`; }
  }
  return null;
};
const loadConfig = () => { try { return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8")); } catch { return {}; } };

// Home resolution (FR-36): STUDIO_HOME set by the user, then the saved config, then the nearest ancestor Home.
const resolveHome = () => {
  if (process.env.STUDIO_HOME) return { home: path.resolve(process.env.STUDIO_HOME), source: "env" };
  const saved = loadConfig().home;
  if (saved && !homeProblem(saved)) return { home: path.resolve(saved), source: "config" };
  if (saved) console.warn(`Saved Claude Home "${saved}" is not usable (${homeProblem(saved)}); using the default.`);
  return { home: findHome(APP_DIR), source: "auto" };
};
const { home: HOME_GIVEN, source: HOME_SOURCE } = resolveHome();
// The full real path (no 8.3 short names like TOGODB~1): Claude Code files sessions under the path it is given, but
// getSessionMessages looks them up by the real path, so a short Home would show empty history (QA v0.6 F-5).
const HOME = (() => { try { return fs.realpathSync.native(HOME_GIVEN); } catch { return HOME_GIVEN; } })();
const PROJECTS = path.join(HOME, "projects");
const OUTPUT = path.join(HOME, "output");
const SESSIONS = path.join(HOME, ".claude", "sessions");

// ---------- chat index (title, project, Claude session id) ----------
const loadChats = () => { try { return JSON.parse(fs.readFileSync(CHATS_FILE, "utf8")); } catch { return []; } };
const saveChats = (chats) => fs.writeFileSync(CHATS_FILE, JSON.stringify(chats, null, 2));
const upsertChat = (chat) => {
  const chats = loadChats().filter((c) => c.id !== chat.id);
  chats.unshift(chat);
  saveChats(chats);
};
// Change some fields of a saved chat without overwriting the rest (a rename or removal made meanwhile survives).
const patchChat = (id, fields) => {
  const chats = loadChats();
  const c = chats.find((x) => x.id === id);
  if (!c) return null;
  for (const [k, v] of Object.entries(fields)) { if (v === undefined) delete c[k]; else c[k] = v; }
  saveChats(chats);
  return c;
};

const listProjects = () => fs.existsSync(PROJECTS)
  ? fs.readdirSync(PROJECTS, { withFileTypes: true }).filter((d) => d.isDirectory() && !d.name.startsWith(".")).map((d) => d.name)
  : [];

// ---------- roles: the chips above the composer (spec look-and-feel D) ----------
const ROLES_FILE = path.join(DATA, "roles.json");
const loadRoles = () => {
  try { const r = JSON.parse(fs.readFileSync(ROLES_FILE, "utf8")); return { projects: r.projects || {}, custom: r.custom || [] }; }
  catch { return { projects: {}, custom: [] }; }
};
const saveRoles = (roles) => fs.writeFileSync(ROLES_FILE, JSON.stringify(roles, null, 2));

// Skills and slash commands for the role chips: the same cached list as the / menu (readCommands, /api/commands),
// so both always agree. A list over a minute old is refreshed in the background; refresh re-reads it at once.
const loadCommands = async (refresh = false) => {
  let data = !refresh && commandsCache?.data;
  if (data && Date.now() - commandsCache.at > 60 * 1000) refreshCommands().catch(() => {});
  data ||= await refreshCommands();
  return data.map((c) => ({ name: c.name, description: c.description || "" }));
};

// Chip label: the skill's optional `label:` front matter, else "ui-designer" -> "UI Designer".
const skillLabel = (name, rest) => {
  try {
    const front = fs.readFileSync(path.join(HOME, ".claude", "skills", name, "SKILL.md"), "utf8").match(/^---\r?\n([\s\S]*?)\r?\n---/);
    const label = front?.[1].match(/^label:\s*(.+)$/m)?.[1].trim().replace(/^["']|["']$/g, "");
    if (label) return label.slice(0, 24);
  } catch {}
  return rest.split("-").filter(Boolean).map((w) => (w.length <= 2 ? w.toUpperCase() : w[0].toUpperCase() + w.slice(1))).join(" ");
};

const chipsFor = (project, commands, roles = loadRoles()) => {
  const prefs = roles.projects[project] || {};
  const prefix = project.toLowerCase() + "-";
  const discovered = project === "General" ? [] : commands
    .filter((c) => c.name.startsWith(prefix))
    .map((c) => ({ id: "skill:" + c.name, kind: "skill", skill: c.name, label: skillLabel(c.name, c.name.slice(prefix.length)), discovered: true }));
  const custom = roles.custom
    .filter((c) => c.scope === "all" || c.scope === project)
    .map((c) => ({ id: c.id, kind: c.kind, skill: c.skill, text: c.text, label: c.label, scope: c.scope, discovered: false }));
  const order = prefs.order || [];
  const rank = (id) => (order.includes(id) ? order.indexOf(id) : Infinity);
  return [...discovered, ...custom]
    .map((c) => ({ ...c, defaultLabel: c.label, label: prefs.renamed?.[c.id] || c.label, hidden: (prefs.hidden || []).includes(c.id) }))
    .sort((a, b) => rank(a.id) - rank(b.id));
};

// The SessionStart hook reads .claude/sessions/<session id>.json, so set the project before the session starts.
const setSessionProject = (sessionId, project) => {
  fs.mkdirSync(SESSIONS, { recursive: true });
  const general = !project || project === "General";
  fs.writeFileSync(path.join(SESSIONS, `${sessionId}.json`), JSON.stringify({
    project: general ? "General" : project, focus: !general, pid: null, updated: new Date().toISOString(),
  }, null, 2));
};

// ---------- running turns (spec reliable-chats Q, R) ----------
// A turn belongs to the server, not to the browser connection that started it: closing the page never stops it.
// turnId -> { id, chat, events, seq, listeners: Set(res), pending: Map(requestId -> card), q, abortController, afterUuid }
const turns = new Map();
const chatTurns = new Map(); // chat id -> its running turn
const CARD_TIMEOUT_MS = Number(process.env.STUDIO_CARD_TIMEOUT_MS) || 30 * 60 * 1000;

// Every event gets a sequence number, is kept for tabs that attach later, and goes to every attached tab.
const emit = (turn, event) => {
  const e = { ...event, seq: ++turn.seq };
  turn.events.push(e);
  const line = JSON.stringify(e) + "\n";
  for (const res of turn.listeners) if (!res.writableEnded) res.write(line);
};
const attachTurn = (turn, res, chat, after) => {
  res.setHeader("Content-Type", "application/x-ndjson; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache");
  res.flushHeaders();
  res.write(JSON.stringify({ type: "chat", chat, turnId: turn.id }) + "\n");
  for (const e of turn.events) if (e.seq > after) res.write(JSON.stringify(e) + "\n");
  turn.listeners.add(res);
  res.on("close", () => turn.listeners.delete(res));
};
// A card is settled once: by an answer, the 30-minute limit, Stop, or the turn ending. Every tab hears the outcome.
const settle = (turn, requestId, result, info) => {
  const card = turn.pending.get(requestId);
  if (!card) return false;
  turn.pending.delete(requestId);
  clearTimeout(card.timer);
  card.resolve(result);
  const s = { type: "permission-settled", requestId, at: Date.now(), ...info };
  emit(turn, s);
  record(turn.chat.id, { ...s, type: "settled", turnId: turn.id });
  return true;
};
const chatState = (c) => {
  const t = chatTurns.get(c.id);
  if (!t) return c;
  const first = t.pending.keys().next().value;
  // startedAt and waitingSince let pages say "started 1m 20s ago" and "waiting since 2 min" (spec away-status FR-189, FR-192).
  return { ...c, running: true, turnId: t.id, startedAt: t.startedAt, waiting: !!first, ...(first ? { waitingId: first, waitingSince: t.pending.get(first).at } : {}) };
};

// ---------- turn record (spec reliable-chats S): data/turns/<chat id>.jsonl, one line per thing that happened ----------
const TURNS_DIR = path.join(DATA, "turns");
fs.mkdirSync(TURNS_DIR, { recursive: true });
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const recordFile = (chatId) => (UUID.test(chatId) ? path.join(TURNS_DIR, chatId + ".jsonl") : null);
const record = (chatId, entry) => {
  const f = recordFile(chatId);
  if (f) try { fs.appendFileSync(f, JSON.stringify(entry) + "\n"); } catch (e) { console.warn("Turn record not written:", e.message); }
};
// Lines that don't parse (a crash mid-write) are skipped.
const readRecord = (chatId) => {
  const f = recordFile(chatId);
  try { return fs.readFileSync(f, "utf8").split("\n").flatMap((l) => { try { return l.trim() ? [JSON.parse(l)] : []; } catch { return []; } }); }
  catch { return []; }
};
// Card inputs are kept like the card shows them: up to 4,000 characters.
const capInput = (input) => {
  const s = JSON.stringify(input ?? {});
  if (s.length <= 4000) return input;
  const cut = (v, n) => (typeof v === "string" ? v.slice(0, n) : undefined);
  return { command: cut(input.command, 4000), file_path: cut(input.file_path, 1000), url: cut(input.url, 1000), description: cut(input.description, 500), truncated: true };
};
// FR-76: turns that never ended (restart, crash, power cut) are closed as interrupted when Studio starts.
const closeInterrupted = () => {
  for (const f of fs.readdirSync(TURNS_DIR)) {
    const chatId = f.replace(/\.jsonl$/, "");
    if (!recordFile(chatId) || f === chatId) continue;
    const open = new Set(), cards = new Map();
    for (const r of readRecord(chatId)) {
      if (r.type === "start") open.add(r.turnId);
      else if (r.type === "end") open.delete(r.turnId);
      else if (r.type === "permission") cards.set(r.requestId, r.turnId);
      else if (r.type === "settled") cards.delete(r.requestId);
    }
    if (!open.size) continue;
    const at = Date.now();
    for (const [requestId, turnId] of cards) if (open.has(turnId)) record(chatId, { type: "settled", turnId, requestId, outcome: "deny", by: "cancelled", reason: "closed", at });
    let last = null;
    for (const turnId of open) { record(chatId, { type: "end", turnId, at, status: "interrupted", reason: "Studio closed before this reply finished" }); last = turnId; }
    patchChat(chatId, { lastEnd: { turnId: last, status: "interrupted", at } });
  }
};
closeInterrupted();

const app = express();
app.use(express.json({ limit: "2mb" }));

// Only this machine's browser may drive Claude: reject other Host names (DNS rebinding) and cross-site requests.
const LOCAL_HOSTS = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);
app.use((req, res, next) => {
  if (!LOCAL_HOSTS.has(req.headers.host)) return res.status(403).send("Forbidden host");
  // Sandboxed output pages send "Origin: null", which fails this check too. No CORS headers are ever sent.
  const origin = req.headers.origin;
  if (origin && !LOCAL_HOSTS.has(origin.replace(/^https?:\/\//, ""))) return res.status(403).send("Forbidden origin");
  if (req.method !== "GET" && req.headers["x-studio"] !== "1") return res.status(403).send("Missing header");
  next();
});

// sendFile with a root: Express refuses absolute paths that pass through a dot folder, and LIVE runs from
// .deploy\releases\<sha>, so files are always given relative to their folder.
const PUBLIC = path.join(APP_DIR, "public"), MODULES = path.join(APP_DIR, "node_modules");
// Home is the landing page (/); the chat page lives at /chat (spec look-and-feel FR-25).
app.get("/", (req, res) => res.sendFile("home.html", { root: PUBLIC }));
app.get("/chat", (req, res) => res.sendFile("index.html", { root: PUBLIC }));
app.use(express.static(PUBLIC, { index: false }));
app.get("/vendor/marked.js", (req, res) => res.sendFile("marked/lib/marked.umd.js", { root: MODULES }));
app.get("/vendor/purify.js", (req, res) => res.sendFile("dompurify/dist/purify.min.js", { root: MODULES }));

// ---------- Claude Home folder browser and restart (spec home-picker FR-127 to FR-138) ----------
const STARTED_AT = Date.now();
const realPath = (p) => { try { return fs.realpathSync.native(p); } catch { return path.resolve(p); } };
const samePath = (a, b) => realPath(a).toLowerCase() === realPath(b).toLowerCase();
// DEV runs under node --watch (which sets WATCH_REPORT_DEPENDENCIES in the child); LIVE runs under scripts/live.mjs,
// the only launcher that sets the live channel and starts the server again after it exits.
const RESTART = process.env.WATCH_REPORT_DEPENDENCIES === "1" ? "watch" : CHANNEL === "live" ? "supervisor" : null;
// A Home saved for the next start that differs from the one in use (FR-129, FR-37).
// With STUDIO_HOME set, that wins over the saved one at every start, so nothing is pending.
const savedHome = () => { const h = loadConfig().home; return h && HOME_SOURCE !== "env" && !samePath(h, HOME) ? h : null; };
// Updates from the website (spec updates FR-228 to FR-234): LIVE only; busy() names a chat that is still working.
const updates = setupUpdates(app, { CHANNEL, DATA, APP_DIR, PORT, busy: () => { for (const t of turns.values()) return t.chat?.title || "A chat"; return null; } });
setupAutostart(app, { CHANNEL, APP_DIR });
app.get("/api/info", (req, res) => res.json({ channel: CHANNEL, version: VERSION, releaseVersion: updates.releaseVersion(), home: HOME, homeSource: HOME_SOURCE, port: PORT,
  startedAt: STARTED_AT, canRestart: !!RESTART, ...(savedHome() ? { savedHome: savedHome() } : {}) }));

// Folder names only, for the Choose Claude Home dialog (FR-132 to FR-134): never files, contents, sizes or dates.
const FOLDER_CAP = 2000;
const isClaudeHome = (p) => fs.existsSync(path.join(p, ".claude")) && fs.existsSync(path.join(p, "projects"));
app.get("/api/folders", (req, res) => {
  const hidden = req.query.hidden === "1";
  const asked = req.query.path;
  if (asked == null || asked === "") {
    const drives = [];
    for (let c = 65; c <= 90; c++) { const d = String.fromCharCode(c) + ":\\"; if (fs.existsSync(d)) drives.push({ name: d.slice(0, 2), path: d, claudeHome: isClaudeHome(d), inUse: samePath(d, HOME) }); }
    return res.json({ path: null, parent: null, folders: drives });
  }
  if (typeof asked !== "string" || asked.length > 260 || /^[\\/]{2}/.test(asked) || !/^[A-Za-z]:[\\/]?/.test(asked) || asked.split(/[\\/]/).includes("..")) {
    return res.status(400).json({ error: "Use a full local path, for example C:\\claude." });
  }
  let dir = path.resolve(/^[A-Za-z]:$/.test(asked) ? asked + "\\" : asked);
  try { if (!fs.statSync(dir).isDirectory()) throw 0; } catch { return res.status(404).json({ error: "That folder does not exist." }); }
  dir = realPath(dir);
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return res.status(403).json({ error: "Can't open this folder." }); }
  const names = entries.filter((e) => e.isDirectory() && (hidden || !/^[.$]/.test(e.name))).map((e) => e.name)
    .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
  const folders = names.slice(0, FOLDER_CAP).map((name) => {
    const p = path.join(dir, name);
    return { name, path: p, claudeHome: isClaudeHome(p), inUse: samePath(p, HOME), ...(/^[.$]/.test(name) ? { hidden: true } : {}) };
  });
  const parent = path.dirname(dir) === dir ? null : path.dirname(dir);
  res.json({ path: dir, parent, folders, ...(names.length > FOLDER_CAP ? { truncated: true } : {}) });
});

// Restart this channel so a newly saved Home is used (FR-135, FR-137). The answer goes out first.
app.post("/api/restart", (req, res) => {
  if (!RESTART) return res.status(409).json({ error: "Studio wasn't started by npm run dev or the LIVE launcher, so it can't restart itself. Close it and start it again." });
  res.status(202).json({ ok: true });
  setTimeout(() => {
    if (RESTART === "watch") { const now = new Date(); fs.utimesSync(fileURLToPath(import.meta.url), now, now); } // the watcher restarts; content unchanged
    else process.exit(0); // the LIVE supervisor starts the server again
  }, 300);
});
app.get("/api/projects", (req, res) => res.json(["General", ...listProjects()]));

// ---------- Home page data (spec look-and-feel E, G) ----------
const SKIP_DIRS = new Set(["node_modules", ".git", ".deploy"]);
// Last change in a project: the folder, its entries, and the entries one folder below.
const folderActivity = (dir) => {
  let latest = 0;
  const seen = (p) => { try { latest = Math.max(latest, fs.statSync(p).mtimeMs); } catch {} };
  seen(dir);
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP_DIRS.has(e.name)) continue;
    const full = path.join(dir, e.name);
    seen(full);
    if (e.isDirectory()) { try { for (const f of fs.readdirSync(full)) if (!SKIP_DIRS.has(f)) seen(path.join(full, f)); } catch {} }
  }
  return latest;
};
const gitState = (dir) => new Promise((resolve) => {
  if (!fs.existsSync(path.join(dir, ".git"))) return resolve(null);
  execFile("git", ["-C", dir, "status", "--porcelain"], { timeout: 2000, windowsHide: true }, (err, stdout) => {
    if (err) return resolve("unknown");
    const n = stdout.split("\n").filter((l) => l.trim()).length;
    resolve(n ? `${n} uncommitted` : "clean");
  });
});
const liveVersion = async () => {
  try {
    const r = await fetch("http://127.0.0.1:4300/api/info", { signal: AbortSignal.timeout(500) });
    return r.ok ? (await r.json()).version : null;
  } catch { return null; }
};

app.get("/api/home", async (req, res) => {
  const chats = loadChats().filter((c) => !c.removed).map(chatState);
  const live = await liveVersion();
  const projects = await Promise.all(listProjects().map(async (name) => {
    const dir = path.join(PROJECTS, name);
    const own = chats.filter((c) => c.project === name).sort((a, b) => (b.updated || 0) - (a.updated || 0));
    const lastActivity = Math.max(own[0]?.updated || 0, folderActivity(dir));
    const tags = [];
    // Running and waiting chats come first (spec reliable-chats FR-80).
    const working = own.filter((c) => c.running).length;
    if (own.some((c) => c.waiting)) tags.push({ kind: "wait", text: "Needs you" });
    else if (working) tags.push({ kind: "work", text: `${working} working` });
    if (name === "Claude-Studio" && live) tags.push({ kind: "live", text: `LIVE ${live}` });
    const git = await gitState(dir);
    if (git) tags.push({ kind: "git", text: git });
    return { name, lastActivity, chats: own.length, lastChat: own[0] ? { id: own[0].id, title: own[0].title } : null, tags: tags.slice(0, 3) };
  }));
  projects.sort((a, b) => b.lastActivity - a.lastActivity);
  const recentChats = [...chats].sort((a, b) => (b.updated || 0) - (a.updated || 0)).slice(0, 3);
  res.json({ home: HOME, homeSource: HOME_SOURCE, projects, recentChats });
});

// New project (FR-27): same characters as project.js create rejects, plus the Windows rules (QA F-1).
const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
const projectNameProblem = (name) => {
  if (typeof name !== "string" || !name.length) return "Enter a name.";
  if (name.length > 64) return "Use 64 characters or fewer.";
  if (/[<>:"/\\|?*\x00-\x1f]/.test(name)) return 'A name can\'t contain < > : " / \\ | ? * or control characters.';
  if (name === "." || name === ".." || /^[ .]|[ .]$/.test(name)) return "A name can't start or end with a space or a dot.";
  if (RESERVED.test(name)) return "That name is reserved by Windows.";
  if (listProjects().some((p) => p.toLowerCase() === name.toLowerCase())) return "A project with that name already exists.";
  return null;
};
app.post("/api/projects", (req, res) => {
  const name = req.body?.name;
  const problem = projectNameProblem(name);
  if (problem) return res.status(400).json({ error: problem });
  const dir = path.join(PROJECTS, name);
  if (path.dirname(dir) !== PROJECTS) return res.status(400).json({ error: "Invalid name." });
  fs.mkdirSync(dir);
  res.status(201).json({ name });
});

// Claude Home setting (FR-34, FR-35): validated, saved per channel, used after a restart.
app.put("/api/config/home", (req, res) => {
  const p = req.body?.path;
  const problem = homeProblem(p);
  if (problem) return res.status(400).json({ error: problem });
  // Same folder in another spelling (c:\claude, an 8.3 short name) needs no restart (FR-131) and changes nothing on
  // disk, except that it cancels another folder saved earlier and still waiting for a restart (QA v0.9 F-1).
  const same = samePath(p, HOME);
  const { home: pending, ...rest } = loadConfig();
  if (!same) fs.writeFileSync(CONFIG_FILE, JSON.stringify({ ...rest, home: path.resolve(p) }, null, 2));
  else if (pending && !samePath(pending, HOME)) {
    const next = HOME_SOURCE === "config" ? { ...rest, home: HOME } : rest;
    if (Object.keys(next).length) fs.writeFileSync(CONFIG_FILE, JSON.stringify(next, null, 2));
    else fs.rmSync(CONFIG_FILE, { force: true });
  }
  res.json({ saved: path.resolve(p), current: HOME, restartNeeded: !same, canRestart: !!RESTART });
});
// The chat list leaves out chats in the Recycle bin; ?removed=1 lists only those (spec reliable-chats FR-82, FR-83).
app.get("/api/chats", (req, res) => {
  const bin = req.query.removed === "1";
  res.json(loadChats().filter((c) => (bin ? c.removed : !c.removed)).map(chatState));
});

app.patch("/api/chats/:id", (req, res) => {
  const chat = loadChats().find((c) => c.id === req.params.id);
  if (!chat) return res.status(404).end();
  const title = typeof req.body?.title === "string" ? req.body.title.trim() : "";
  if (!title || title.length > 120) return res.status(400).json({ error: "title must be 1 to 120 characters" });
  chat.title = title;
  upsertChat(chat);
  res.json(chat);
});

// ---------- Recycle bin (spec reliable-chats U) ----------
const SESSIONS_DIR = path.join(process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), ".claude"), "projects", HOME.replace(/[^a-zA-Z0-9]/g, "-"));
const sessionFile = (sessionId) => path.join(SESSIONS_DIR, sessionId + ".jsonl");
const BIN_DAYS = 30;
// Delete forever: the chat, its turn record, and Claude Code's session file. The session file goes only when its
// path is inside this Home's session folder and no other chat uses the same session.
const deleteForever = (ids) => {
  const chats = loadChats();
  const gone = chats.filter((c) => ids.includes(c.id));
  const kept = chats.filter((c) => !ids.includes(c.id));
  saveChats(kept);
  for (const c of gone) {
    const rec = recordFile(c.id);
    if (rec) fs.rmSync(rec, { force: true });
    if (!UUID.test(c.sessionId || "") || kept.some((k) => k.sessionId === c.sessionId)) continue;
    const f = sessionFile(c.sessionId);
    if (path.dirname(f) === SESSIONS_DIR) fs.rmSync(f, { force: true });
  }
  return gone.length;
};
// FR-86: chats removed more than 30 days ago are deleted forever, at start and then once a day.
const purgeBin = () => {
  const cutoff = Date.now() - BIN_DAYS * 86400000;
  const old = loadChats().filter((c) => c.removed && c.removed < cutoff).map((c) => c.id);
  if (old.length) console.log(`Recycle bin: deleted ${deleteForever(old)} chat(s) removed over ${BIN_DAYS} days ago.`);
};
purgeBin();
setInterval(purgeBin, 86400000).unref();

app.delete("/api/chats/:id", (req, res) => {
  const chat = loadChats().find((c) => c.id === req.params.id);
  if (!chat) return res.status(404).end();
  if (req.query.forever === "1") {
    if (!chat.removed) return res.status(409).json({ error: "Only chats in the Recycle bin can be deleted forever." });
    deleteForever([chat.id]);
    return res.status(204).end();
  }
  if (chatTurns.has(chat.id)) return res.status(409).json({ error: "This chat is working on a reply. Stop it first." });
  patchChat(chat.id, { removed: Date.now() });
  res.status(204).end();
});
app.delete("/api/chats", (req, res) => {
  if (req.query.removed !== "1") return res.status(400).json({ error: "Only the Recycle bin can be emptied (removed=1)." });
  res.json({ deleted: deleteForever(loadChats().filter((c) => c.removed).map((c) => c.id)) });
});
app.post("/api/chats/:id/restore", (req, res) => {
  const chat = loadChats().find((c) => c.id === req.params.id);
  if (!chat) return res.status(404).end();
  res.json(chatState(patchChat(chat.id, { removed: undefined })));
});

// A running chat streams its turn: every event so far after ?after=<seq>, then live ones (spec reliable-chats FR-67).
app.get("/api/chats/:id/live", (req, res) => {
  const chat = loadChats().find((c) => c.id === req.params.id);
  if (!chat) return res.status(404).end();
  const turn = chatTurns.get(chat.id);
  if (!turn) return res.status(204).end();
  attachTurn(turn, res, chat, Math.max(0, parseInt(req.query.after, 10) || 0));
});

// History of a past chat, read from Claude Code's own session store.
// A command's printed output (/usage, /context…) is kept in the session file as a system entry that
// getSessionMessages doesn't return. Read those entries and place each one right after the command it answers.
const commandOutputs = (sessionId) => {
  const out = new Map();
  try {
    for (const line of fs.readFileSync(sessionFile(sessionId), "utf8").split("\n")) {
      if (!line.includes('"local_command"')) continue;
      const j = JSON.parse(line);
      if (j.type === "system" && j.subtype === "local_command" && j.parentUuid) out.set(j.parentUuid, String(j.content || ""));
    }
  } catch {}
  return out;
};
app.get("/api/chats/:id/messages", async (req, res) => {
  const chat = loadChats().find((c) => c.id === req.params.id);
  if (!chat) return res.status(404).end();
  try {
    const outputs = commandOutputs(chat.sessionId);
    let msgs = await sessionMessages(chat.sessionId);
    // A running turn's messages come only from its live events, so nothing shows twice (FR-69).
    const running = chatTurns.get(chat.id);
    if (running) {
      const i = running.afterUuid ? msgs.findIndex((m) => m.uuid === running.afterUuid) : -1;
      msgs = i >= 0 ? msgs.slice(0, i + 1) : running.afterUuid ? msgs : [];
    }
    const inserts = recordInserts(chat.id, msgs, running?.id);
    const list = [];
    msgs.forEach((m, i) => {
      list.push(...(inserts.get(i) || []));
      list.push(m);
      if (outputs.has(m.uuid)) list.push({ type: "system", subtype: "local_command", content: outputs.get(m.uuid), parent_tool_use_id: null });
    });
    list.push(...(inserts.get(msgs.length) || []));
    res.json(list);
  } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});
const sessionMessages = async (sessionId) => { try { return await getSessionMessages(sessionId, { dir: HOME }); } catch { return []; } };

// FR-77: the turn record placed into the history. Index i means "before message i" (msgs.length = at the end).
// A turn's messages run from just after its start message (afterUuid) to the next recorded turn. Each card goes right
// after the assistant message holding its tool call (else at the end of its turn); each turn ends with its end line.
const recordInserts = (chatId, msgs, skipTurnId) => {
  const turnsInRecord = [];
  const byId = new Map();
  for (const r of readRecord(chatId)) {
    if (r.turnId === skipTurnId) continue;
    if (r.type === "start") { const t = { start: r, cards: [], settled: new Map(), end: null }; turnsInRecord.push(t); byId.set(r.turnId, t); }
    const t = byId.get(r.turnId);
    if (!t) continue;
    if (r.type === "permission") t.cards.push(r);
    else if (r.type === "settled") t.settled.set(r.requestId, r);
    else if (r.type === "end") t.end = r;
  }
  const index = new Map(msgs.map((m, i) => [m.uuid, i]));
  const toolAt = new Map();
  msgs.forEach((m, i) => { if (m.type === "assistant") for (const b of m.message?.content || []) if (b.type === "tool_use") toolAt.set(b.id, i); });
  const startOf = (t) => (t.start.afterUuid ? (index.has(t.start.afterUuid) ? index.get(t.start.afterUuid) + 1 : msgs.length) : 0);
  const inserts = new Map();
  const add = (i, item) => { if (!inserts.has(i)) inserts.set(i, []); inserts.get(i).push(item); };
  turnsInRecord.forEach((t, k) => {
    const next = turnsInRecord[k + 1];
    const end = next ? Math.max(startOf(t), startOf(next)) : msgs.length;
    for (const card of t.cards) {
      const at = toolAt.get(card.toolUseId);
      add(at != null && at < end ? at + 1 : end, { type: "studio", kind: "card", card, settled: t.settled.get(card.requestId) || null });
    }
    if (t.end) add(end, { type: "studio", kind: "end", end: t.end });
  });
  return inserts;
};

// Files newest first: Home\output for General, or the selected project's folder (the panel follows the project).
// Project folders skip dot files and folders (.git, .deploy, .env…) and node_modules.
app.get("/api/outputs", (req, res) => {
  const project = typeof req.query.project === "string" ? req.query.project : "General";
  if (!isProject(project)) return res.status(400).json({ error: "Unknown project." });
  const root = project === "General" ? OUTPUT : path.join(PROJECTS, project);
  const files = [];
  let seen = 0;
  const walk = (dir, depth) => {
    if (depth > 4 || seen > 5000 || !fs.existsSync(dir)) return;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (root !== OUTPUT && (e.name.startsWith(".") || e.name === "node_modules")) continue;
      seen++;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) walk(full, depth + 1);
      else if (e.isFile()) {
        const st = fs.statSync(full);
        files.push({ path: path.relative(root, full).replaceAll("\\", "/"), size: st.size, mtime: st.mtimeMs });
      }
    }
  };
  walk(root, 0);
  files.sort((a, b) => b.mtime - a.mtime);
  res.json(files.slice(0, 300));
});

// Open a file from Home\output or a project folder: no path traversal, no dot files (sendFile refuses them),
// and run it in an opaque origin, since files may hold fetched web content, so they can't reach the API.
const sendSandboxed = (root, rel, res) => {
  const full = path.resolve(root, rel);
  if (!full.startsWith(root + path.sep) || !fs.existsSync(full)) return res.status(404).end();
  res.setHeader("Content-Security-Policy", "sandbox allow-scripts allow-popups allow-forms allow-modals allow-downloads");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.sendFile(path.relative(root, full), { root });
};
// Markdown files directly in a project's specs\ or tests\ folder, newest first (FR-43). 404 when the folder is missing,
// so the page can hide that tab. Content is read through /project-file (same rules as /output).
app.get("/api/project-docs", (req, res) => {
  const { project, folder } = req.query;
  if (typeof project !== "string" || !listProjects().includes(project)) return res.status(400).json({ error: "Unknown project." });
  if (!["specs", "tests"].includes(folder)) return res.status(400).json({ error: "Unknown folder." });
  const dir = path.join(PROJECTS, project, folder);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return res.status(404).json({ error: `No ${folder} folder.` });
  const files = fs.readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isFile() && !e.name.startsWith(".") && e.name.toLowerCase().endsWith(".md"))
    .map((e) => ({ path: e.name, mtime: fs.statSync(path.join(dir, e.name)).mtimeMs }))
    .sort((a, b) => b.mtime - a.mtime);
  res.json(files);
});

app.get("/output/*file", (req, res) => sendSandboxed(OUTPUT, [].concat(req.params.file).join("/"), res));
app.get("/project-file/:project/*file", (req, res) => {
  if (!listProjects().includes(req.params.project)) return res.status(404).end();
  const rel = [].concat(req.params.file).join("/");
  if (rel.split("/").includes("node_modules")) return res.status(404).end();
  sendSandboxed(path.join(PROJECTS, req.params.project), rel, res);
});

const isProject = (p) => p === "General" || listProjects().includes(p);
const str = (v, min, max) => typeof v === "string" && v.trim().length >= min && v.trim().length <= max;

app.get("/api/roles", async (req, res) => {
  const project = String(req.query.project || "General");
  if (!isProject(project)) return res.status(400).json({ error: "Unknown project" });
  try {
    const commands = await loadCommands();
    const roles = loadRoles();
    res.json({ project, chips: chipsFor(project, commands, roles), custom: roles.custom, commands });
  } catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});

app.post("/api/roles/refresh", async (req, res) => {
  try { res.json({ count: (await loadCommands(true)).length }); }
  catch (e) { res.status(500).json({ error: String(e.message || e) }); }
});

// Saves one project's chip preferences and the full custom chip list.
app.put("/api/roles", async (req, res) => {
  const { project, prefs = {}, custom = [] } = req.body || {};
  const bad = (error) => res.status(400).json({ error });
  if (typeof project !== "string" || !isProject(project)) return bad("Unknown project");
  const { hidden = [], renamed = {}, order = [] } = prefs;
  if (!Array.isArray(hidden) || hidden.length > 200 || !hidden.every((h) => str(h, 1, 200))) return bad("Invalid hidden list");
  if (typeof renamed !== "object" || Array.isArray(renamed) || !Object.values(renamed).every((l) => str(l, 1, 24))) return bad("Labels must be 1 to 24 characters");
  if (!Array.isArray(order) || order.length > 300 || !order.every((o) => str(o, 1, 200))) return bad("Invalid order");
  if (!Array.isArray(custom) || custom.length > 100) return bad("Invalid custom list");
  const commands = await loadCommands();
  const clean = [];
  for (const c of custom) {
    if (!c || typeof c !== "object") return bad("Invalid custom role");
    if (!str(c.label, 1, 24)) return bad("Labels must be 1 to 24 characters");
    if (!(c.scope === "all" || (typeof c.scope === "string" && isProject(c.scope)))) return bad("Unknown scope");
    const id = typeof c.id === "string" && /^c-[\w-]{1,40}$/.test(c.id) ? c.id : "c-" + randomUUID();
    if (c.kind === "skill") {
      if (!commands.some((k) => k.name === c.skill)) return bad(`Unknown skill: ${c.skill}`);
      clean.push({ id, kind: "skill", label: c.label.trim(), skill: c.skill, scope: c.scope });
    } else if (c.kind === "prompt") {
      if (!str(c.text, 1, 2000)) return bad("Instruction text must be 1 to 2,000 characters");
      clean.push({ id, kind: "prompt", label: c.label.trim(), text: c.text.trim(), scope: c.scope });
    } else return bad("Kind must be skill or prompt");
  }
  const roles = loadRoles();
  roles.projects[project] = { hidden, renamed: Object.fromEntries(Object.entries(renamed).map(([k, v]) => [k, v.trim()])), order };
  roles.custom = clean;
  saveRoles(roles);
  res.json({ project, chips: chipsFor(project, commands, roles), custom: roles.custom });
});

// workFreely is Studio's own trust level (spec trust-levels FR-245): the SDK gets "default" plus the rules of workFreelyRules().
const MODES = ["default", "workFreely", "acceptEdits", "plan", "auto"];
const MODELS = ["opus", "sonnet", "haiku", "fable"];
const MAX_TEXT = 100_000;
// Slash commands Claude Code offers here (built-ins, skills, custom commands), for the composer's / menu.
// Asked from a session that never sends a prompt, so it costs nothing; cached for a minute.
// The cached list is answered at once; when it is over a minute old it is refreshed in the background (QA F-1).
let commandsCache = null, commandsLoading = null;
const readCommands = async () => {
  const abortController = new AbortController();
  const idle = (async function* () { await new Promise((r) => abortController.signal.addEventListener("abort", r)); })();
  try {
    const q = query({ prompt: idle, options: { cwd: HOME, settingSources: ["user", "project", "local"], abortController } });
    const [init, commands] = await Promise.all([q.initializationResult(), q.supportedCommands()]);
    const terminal = new Set(init.terminal_slash_commands || []);
    const data = commands.filter((c) => !terminal.has(c.name)).map((c) => ({ name: c.name, description: c.description, argumentHint: c.argumentHint, aliases: c.aliases || [], builtin: !!c.builtin,
      ...(c.builtin && CONSOLE_COMMANDS.includes(c.name) ? { console: true } : {}) }));
    commandsCache = { at: Date.now(), data };
    return data;
  } finally {
    abortController.abort();
  }
};
const refreshCommands = () => (commandsLoading ??= readCommands().finally(() => { commandsLoading = null; }));
app.get("/api/commands", async (req, res) => {
  if (commandsCache) {
    if (Date.now() - commandsCache.at > 60 * 1000) refreshCommands().catch(() => {});
    return res.json(commandsCache.data);
  }
  try { res.json(await refreshCommands()); }
  catch (e) { res.status(502).json({ error: "Couldn't read the command list: " + String(e?.message || e).slice(0, 200) }); }
});

// ---------- permission rules (spec permissions FR-111 to FR-126) ----------
// Rules use Claude Code's syntax: Tool or Tool(content), e.g. Bash(node --check *) or Edit(/projects/x/**).
const SHELLS = new Set(["Bash", "PowerShell"]);
const MULTI_WORD = new Set(["git", "npm", "npx", "node", "docker", "gh"]); // their second word names the action
// Risky actions are looked for in every word, not only the first, so options or wrappers in front
// (git -C <dir> push, cmd /c del x, npx rimraf x) don't hide them (QA v0.8 F-4).
const DANGER = new Set(["rm", "del", "erase", "rmdir", "rd", "format", "shutdown", "taskkill", "remove-item", "stop-process", "rimraf", "push", "publish"]);
const shellCommand = (input) => String(input?.command || "").trim();
const words = (cmd) => cmd.split(/\s+/).filter(Boolean).map((w) => w.replace(/^["']+|["']+$/g, ""));
const bare = (w) => w.toLowerCase().split(/[\\/]/).pop().replace(/\.(exe|cmd|bat|ps1)$/, "");
// Chained or redirected commands count as risky too: a pattern would hide what else runs (FR-113).
const isRisky = (toolName, input) => {
  if (!SHELLS.has(toolName)) return false;
  const cmd = shellCommand(input);
  if (/[|;&>]/.test(cmd)) return true;
  const w = words(cmd).map(bare);
  return w.some((x) => DANGER.has(x)) ||
    (w.includes("git") && (w.includes("clean") || (w.includes("reset") && w.includes("--hard")) || (w.includes("checkout") && w.includes("--"))));
};
// git's own options come before its action (git -C <dir> status); -C, -c, --git-dir, --work-tree and --namespace take a value.
const gitAction = (w) => {
  let i = 1;
  while (i < w.length && w[i].startsWith("-")) i += /^(-C|-c|--git-dir|--work-tree|--namespace)$/.test(w[i]) ? 2 : 1;
  return { action: w[i], plain: i === 1 };
};
// The kind of action, used to match "Allow for this reply": git -C <dir> status counts as "git status".
const actionKey = (cmd) => {
  const w = words(cmd);
  if (w[0] === "git") return ["git", gitAction(w).action].filter(Boolean).join(" ");
  return w.slice(0, MULTI_WORD.has(w[0]) && w[1] ? 2 : 1).join(" ");
};
// The prefix for a rule pattern, or null when a prefix can't name the action safely: Bash(git -C *) would
// also allow git -C <dir> push, so git with options before its action gets the exact command instead.
const commandPrefix = (cmd) => {
  const w = words(cmd);
  if (w[0] === "git" && !gitAction(w).plain) return null;
  return cmd.split(/\s+/).filter(Boolean).slice(0, MULTI_WORD.has(w[0]) && w[1] ? 2 : 1).join(" ");
};
const ruleText = ({ toolName, ruleContent }) => (ruleContent != null ? `${toolName}(${ruleContent})` : toolName);
// The broadest rule that still names the kind of action (FR-112), the exact one, and whether it is risky.
const ruleSuggestions = (toolName, input, project, suggestions) => {
  const risky = isRisky(toolName, input);
  const offered = suggestions?.find((s) => s.type === "addRules" && s.rules?.length)?.rules[0];
  let suggested = toolName, exact = offered ? ruleText(offered) : null;
  if (SHELLS.has(toolName)) {
    // Exact means the literal command: Claude Code's own suggestion is often a prefix pattern (git push *).
    const cmd = shellCommand(input);
    exact = `${toolName}(${cmd})`;
    const prefix = commandPrefix(cmd);
    suggested = risky || prefix == null ? exact : `${toolName}(${prefix} *)`;
  } else if (["Edit", "Write", "NotebookEdit"].includes(toolName)) {
    // Claude Code matches path rules written as Edit(...) for every editing tool; Write(...) path rules never match.
    suggested = project && project !== "General" ? `Edit(/projects/${project}/**)` : "Edit(/**)";
  } else if (toolName === "WebFetch") {
    try { suggested = `WebFetch(domain:${new URL(input.url).hostname})`; } catch {}
  }
  // FR-258: a command whose exact rule could never match again (long, several lines, or carrying a date or id) gets a note, not a rule.
  const noMatch = SHELLS.has(toolName) && suggested === exact && cannotMatchAgain(shellCommand(input));
  return noMatch ? { suggestedRule: null, exactRule: null, risky, noMatch: true } : { suggestedRule: suggested, exactRule: exact || suggested, risky };
};
const cannotMatchAgain = (cmd) => cmd.length > 200 || /[\r\n]/.test(cmd) ||
  /20\d\d-\d\d-\d\d|\b\d{10}\b|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i.test(cmd);
// "Allow for this reply" covers the same command prefix for shells, else the same tool (FR-125).
const replyKey = (toolName, input) => (SHELLS.has(toolName) ? `${toolName}:${actionKey(shellCommand(input))}` : toolName);
const RULE_HELP = "Use Tool or Tool(…), one line, up to 1000 characters.";
// Why a rule was refused, in words (FR-260); null when it is fine. The browser has the same checks.
const ruleProblem = (rule) => {
  if (typeof rule !== "string" || !rule.trim()) return "The rule is empty.";
  if (rule.length > 1000) return `More than 1000 characters (${rule.length.toLocaleString("en-US")}).`;
  if (/[\r\n]/.test(rule)) return "More than one line.";
  if (!/^([A-Za-z][\w-]*)(?:\((.*)\))?$/.test(rule.trim())) return "Doesn't look like Tool or Tool(…).";
  return null;
};
const parseRule = (rule) => {
  if (typeof rule !== "string" || !rule.trim() || rule.length > 1000 || /[\r\n]/.test(rule)) return null;
  const m = /^([A-Za-z][\w-]*)(?:\((.*)\))?$/.exec(rule.trim());
  return m ? { toolName: m[1], ...(m[2] != null ? { ruleContent: m[2] } : {}) } : null;
};

// Home's local settings: Studio reads and writes only permissions.allow / ask / deny (FR-116, FR-120).
const LOCAL_SETTINGS = path.join(HOME, ".claude", "settings.local.json");
const BACKUPS = path.join(DATA, "settings-backup");
const LISTS = ["allow", "ask", "deny"];
const readSettings = (file) => {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch (e) { if (e.code === "ENOENT") return {}; throw e; }
};
const permissionLists = (s) => Object.fromEntries(LISTS.map((k) => [k, Array.isArray(s?.permissions?.[k]) ? s.permissions[k] : []]));
// A rule that matches one exact command never applies again (FR-118).
const isOneOff = (rule) => !rule.includes("*") && (rule.length > 60 || /["'|>]|\\n/.test(rule));
// An exact rule another allow rule already covers is redundant too (QA v0.8 F-1): the bare tool name, or for a shell
// a wildcard rule matching the command, such as Bash(node --check *) for Bash(node --check app.js).
// Returns { rule: the rule covering it }; wildcard rules are never listed, so Clean up can't remove the broader one.
const coveredRules = (allow) => {
  const covered = {};
  for (const rule of allow) {
    const r = parseRule(rule);
    if (!r || rule.includes("*")) continue;
    const by = allow.find((o) => {
      const p = o !== rule && parseRule(o);
      if (!p || p.toolName !== r.toolName) return false;
      if (p.ruleContent == null) return true;
      if (r.ruleContent == null || !SHELLS.has(r.toolName) || !p.ruleContent.includes("*")) return false;
      const glob = p.ruleContent.replace(/:\*$/, " *").split("*").map((s) => s.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join(".*");
      return new RegExp("^" + glob + "$", "s").test(r.ruleContent);
    });
    if (by) covered[rule] = by;
  }
  return covered;
};
// Write permission lists into a settings file (FR-120): a copy first (the latest 10 per file), every other key kept,
// then a temporary file renamed over the old one.
const writePermissionLists = (file, settings, lists, backupPrefix) => {
  fs.mkdirSync(BACKUPS, { recursive: true });
  if (fs.existsSync(file)) fs.copyFileSync(file, path.join(BACKUPS, `${backupPrefix}.${Date.now()}.json`));
  for (const old of fs.readdirSync(BACKUPS).filter((f) => f.startsWith(backupPrefix + ".")).sort().slice(0, -10)) fs.rmSync(path.join(BACKUPS, old));
  const kept = Object.fromEntries(LISTS.filter((k) => lists[k].length || settings.permissions?.[k]).map((k) => [k, lists[k]]));
  const next = { ...settings, permissions: { ...(settings.permissions || {}), ...kept } };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + ".studio-tmp";
  fs.writeFileSync(tmp, JSON.stringify(next, null, 2) + "\n");
  fs.renameSync(tmp, file);
};

// ---------- project rules (spec project-rules FR-197 to FR-205) ----------
// A project's own Allowed list lives in <Home>\projects\<project>\.claude\settings.local.json, Claude Code's format, so a
// terminal started in that folder uses it too. Only listed projects are accepted; the path is built from the name.
const projectSettingsFile = (name) => path.join(PROJECTS, name, ".claude", "settings.local.json");
const isListedProject = (name) => typeof name === "string" && name !== "General" && listProjects().includes(name);
// Keep a project's rules file out of git without changing tracked files (FR-199): the repo's own .git\info\exclude.
const gitIgnores = (dir) => new Promise((resolve) => execFile("git", ["-C", dir, "check-ignore", "-q", ".claude/settings.local.json"], (err) => resolve(!err)));
const excludeFromGit = async (name) => {
  const dir = path.join(PROJECTS, name);
  if (!fs.statSync(path.join(dir, ".git"), { throwIfNoEntry: false })?.isDirectory()) return false;
  if (await gitIgnores(dir)) return false;
  const exclude = path.join(dir, ".git", "info", "exclude");
  fs.mkdirSync(path.dirname(exclude), { recursive: true });
  const text = fs.existsSync(exclude) ? fs.readFileSync(exclude, "utf8") : "";
  fs.appendFileSync(exclude, (text && !text.endsWith("\n") ? "\n" : "") + ".claude/settings.local.json\n");
  return true;
};
// Add and remove a project's Allowed rules; returns the new list and whether the file was just excluded from git.
const changeProjectRules = async (name, add, remove) => {
  const file = projectSettingsFile(name);
  const settings = readSettings(file); // a file that doesn't parse throws here and is never overwritten (AC-123)
  const lists = permissionLists(settings);
  for (const r of remove) lists.allow = lists.allow.filter((x) => x !== r.trim());
  for (const r of add) if (!lists.allow.includes(r.trim())) lists.allow.push(r.trim());
  writePermissionLists(file, settings, lists, `project-${name}`);
  return { allow: lists.allow, gitExcluded: await excludeFromGit(name) };
};
// A project's Allowed rules for one reply (FR-200): read fresh; a file that can't be read is skipped with a warning.
const projectAllow = (name) => {
  if (!isListedProject(name)) return [];
  try { return permissionLists(readSettings(projectSettingsFile(name))).allow.filter((r) => parseRule(r)); }
  catch (e) { console.warn(`Project rules for ${name} skipped: ${String(e?.message || e).slice(0, 200)}`); return []; }
};

app.get("/api/permissions", (req, res) => {
  const project = req.query.project;
  if (project != null) {
    if (!isListedProject(project)) return res.status(404).json({ error: "Unknown project" });
    const file = projectSettingsFile(project);
    try {
      const allow = permissionLists(readSettings(file)).allow;
      return res.json({ path: file, project, local: { allow }, oneOff: allow.filter(isOneOff), covered: coveredRules(allow) });
    } catch (e) { // shown in the tab; the file is left alone (AC-123)
      return res.json({ path: file, project, local: { allow: [] }, oneOff: [], covered: {}, error: "Couldn't read " + file + ": " + String(e?.message || e).slice(0, 200) });
    }
  }
  try {
    const local = permissionLists(readSettings(LOCAL_SETTINGS));
    const readOnly = [
      { label: "User settings", file: path.join(os.homedir(), ".claude", "settings.json") },
      { label: "Home shared settings", file: path.join(HOME, ".claude", "settings.json") },
    ].map((f) => { try { return { ...f, ...permissionLists(readSettings(f.file)) }; } catch { return { ...f, ...permissionLists({}), error: "Couldn't read this file." }; } });
    res.json({ path: LOCAL_SETTINGS, local, oneOff: local.allow.filter(isOneOff), covered: coveredRules(local.allow), readOnly });
  } catch (e) {
    res.status(500).json({ error: "Couldn't read " + LOCAL_SETTINGS + ": " + String(e?.message || e).slice(0, 200) });
  }
});
// How many rules each project has, for the "Rules for" choices and the chat pill (null: the file can't be read).
app.get("/api/permissions/projects", (req, res) => {
  res.json(Object.fromEntries(listProjects().map((name) => {
    try { return [name, permissionLists(readSettings(projectSettingsFile(name))).allow.length]; } catch { return [name, null]; }
  })));
});
app.post("/api/permissions", async (req, res) => {
  const { add = [], remove = [], project } = req.body || {};
  const ok = (x) => Array.isArray(x) && x.length <= 200 && x.every((c) => c && LISTS.includes(c.list) && parseRule(c.rule));
  if (!ok(add) || !ok(remove)) {
    const badRule = [...(Array.isArray(add) ? add : []), ...(Array.isArray(remove) ? remove : [])].find((c) => c && ruleProblem(c.rule));
    const problem = badRule ? ruleProblem(badRule.rule) : null;
    return res.status(400).json({ error: problem ? `${problem} ${RULE_HELP}` : RULE_HELP, ...(problem ? { problem, hint: RULE_HELP } : {}) });
  }
  if (project != null) {
    if (!isListedProject(project)) return res.status(404).json({ error: "Unknown project" });
    if ([...add, ...remove].some((c) => c.list !== "allow")) return res.status(400).json({ error: "Projects have an Allowed list only." });
    const file = projectSettingsFile(project);
    try {
      const out = await changeProjectRules(project, add.map((c) => c.rule), remove.map((c) => c.rule));
      return res.json({ path: file, project, local: { allow: out.allow }, oneOff: out.allow.filter(isOneOff), covered: coveredRules(out.allow), gitExcluded: out.gitExcluded });
    } catch (e) {
      return res.status(500).json({ error: "Couldn't save " + file + ": " + String(e?.message || e).slice(0, 200) });
    }
  }
  let settings;
  try { settings = readSettings(LOCAL_SETTINGS); } // a file that doesn't parse is never overwritten
  catch (e) { return res.status(500).json({ error: "Couldn't read " + LOCAL_SETTINGS + ": " + String(e?.message || e).slice(0, 200) }); }
  const lists = permissionLists(settings);
  for (const c of remove) lists[c.list] = lists[c.list].filter((r) => r !== c.rule.trim());
  for (const c of add) if (!lists[c.list].includes(c.rule.trim())) lists[c.list].push(c.rule.trim());
  try { writePermissionLists(LOCAL_SETTINGS, settings, lists, "settings.local"); }
  catch (e) { return res.status(500).json({ error: "Couldn't save the rules: " + String(e?.message || e).slice(0, 200) }); }
  res.json({ path: LOCAL_SETTINGS, local: lists, oneOff: lists.allow.filter(isOneOff), covered: coveredRules(lists.allow) });
});

// ---------- trust levels (spec trust-levels FR-245 to FR-265) ----------
// The safe read-only preset of FR-119 (the browser has the same list); Work freely allows it without the preset button.
const SAFE_READ_ONLY = ["Bash(ls *)", "Bash(pwd)", "Bash(git status *)", "Bash(git log *)", "Bash(git diff *)", "Bash(git show *)", "Bash(git branch *)",
  "Bash(grep *)", "Bash(rg *)", "Bash(wc *)", "Bash(head *)", "Bash(tail *)", "Bash(node --check *)", "PowerShell(Get-ChildItem *)", "PowerShell(Get-Content *)"];
// What Work freely allows by rule (FR-246): the project's own files. Edit(...) covers every editing tool; Write(...) path rules never
// match in Claude Code (probe 2026-10-19). Reads inside Home need no rule, and ordinary shell commands are allowed in canUseTool,
// where the risky test is available.
const workFreelyRules = (project) => [`Edit(/projects/${project}/**)`, ...SAFE_READ_ONLY];

// Bookkeeping files (FR-262): updates to logs and memory never wait for a card. Rules are Edit(...) only, for the same reason.
// Claude Code names a Home's folder by turning every character that isn't a letter or digit into "-" (the same as SESSIONS_DIR),
// and keeps it under CLAUDE_CONFIG_DIR when that is set (QA v0.19 F-1).
const memoryDir = () => path.join(process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), ".claude"), "projects", HOME.replace(/[\\/]+$/, "").replace(/[^a-zA-Z0-9]/g, "-"), "memory");
// The rule form that matches outside Home is relative to the user profile: ~/.claude/... (an absolute //C:/ form never matched).
const memoryRule = () => {
  const rel = path.relative(os.homedir(), memoryDir());
  const inProfile = rel && !rel.startsWith("..") && !path.isAbsolute(rel);
  return `Edit(${inProfile ? "~/" + rel.split(path.sep).join("/") : memoryDir().split(path.sep).join("/")}/**)`;
};
const bookkeepingItems = () => [
  { id: "logs", label: "Conversation logs and summary", shown: "logs\\**", rule: "Edit(/logs/**)", dir: path.join(HOME, "logs") },
  { id: "recreate", label: "Setup recreate prompt", shown: "output\\docs\\claude-setup-recreate-prompt.md", rule: "Edit(/output/docs/claude-setup-recreate-prompt.md)",
    file: path.join(HOME, "output", "docs", "claude-setup-recreate-prompt.md") },
  { id: "memory", label: "Memory", shown: memoryDir() + "\\**", rule: memoryRule(), dir: memoryDir() },
];
const bookkeepingState = (lists) => bookkeepingItems().map((i) => ({ id: i.id, label: i.label, shown: i.shown, rule: i.rule,
  allowed: lists.allow.includes(i.rule), asked: lists.ask.includes(i.rule) })); // asked: an Ask first rule with the same text would still win
const insideDir = (dir, file) => { const rel = path.relative(dir, file); return !!rel && !rel.startsWith("..") && !path.isAbsolute(rel); };
// True when shell words are only text: balanced quotes, and outside single quotes no substitution; outside quotes also no
// pipe, chain, redirect or backtick. A pipe inside quotes is text (a log row is a table row).
const plainText = (s) => {
  let q = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q === "'") { if (c === "'") q = null; continue; }
    if (c === "\\") { i++; continue; }
    if (c === "`" || (c === "$" && /[({]/.test(s[i + 1] || ""))) return false;
    if (q === '"') { if (c === '"') q = null; continue; }
    if (c === "'" || c === '"') q = c;
    else if (/[|;&<>]/.test(c)) return false;
  }
  return q === null;
};
// FR-264: one printf or echo that only appends (>>) to a text file on the bookkeeping list, with no other step. Returns the file name.
const bookkeepingAppend = (toolName, input) => {
  if (toolName !== "Bash") return null;
  const cmd = shellCommand(input);
  if (/[\r\n]/.test(cmd)) return null;
  const m = /^(?:printf|echo)\s+([\s\S]*?)\s*>>\s*("[^"]+"|'[^']+'|[^\s"'<>|&;`$]+)$/.exec(cmd);
  if (!m) return null;
  if (!plainText(m[1].replace(/\$\(date [+%A-Za-z0-9:_ -]*\)/g, ""))) return null; // $(date …) is the one allowed substitution
  const target = path.resolve(HOME, m[2].replace(/^["']|["']$/g, ""));
  if (!/\.(md|txt)$/i.test(target)) return null;
  let lists;
  try { lists = permissionLists(readSettings(LOCAL_SETTINGS)); } catch { return null; }
  const on = bookkeepingItems().some((i) => lists.allow.includes(i.rule) && !lists.ask.includes(i.rule) && (i.file ? path.resolve(i.file).toLowerCase() === target.toLowerCase() : insideDir(i.dir, target)));
  return on ? path.basename(target) : null;
};
app.get("/api/permissions/bookkeeping", (req, res) => {
  try { res.json({ items: bookkeepingState(permissionLists(readSettings(LOCAL_SETTINGS))) }); }
  catch (e) { res.status(500).json({ error: "Couldn't read " + LOCAL_SETTINGS + ": " + String(e?.message || e).slice(0, 200) }); }
});
// Allow the ticked items (FR-263): their rules join Allowed, and an Ask first rule with the same text moves out of the way.
app.post("/api/permissions/bookkeeping", (req, res) => {
  const { ids } = req.body || {};
  const known = bookkeepingItems();
  if (!Array.isArray(ids) || !ids.length || !ids.every((id) => known.some((i) => i.id === id))) return res.status(400).json({ error: "Pick at least one of the listed files." });
  let settings;
  try { settings = readSettings(LOCAL_SETTINGS); }
  catch (e) { return res.status(500).json({ error: "Couldn't read " + LOCAL_SETTINGS + ": " + String(e?.message || e).slice(0, 200) }); }
  const lists = permissionLists(settings);
  const moved = [];
  for (const i of known.filter((k) => ids.includes(k.id))) {
    if (!lists.allow.includes(i.rule)) lists.allow.push(i.rule);
    if (lists.ask.includes(i.rule)) { lists.ask = lists.ask.filter((r) => r !== i.rule); moved.push(i.id); }
  }
  try { writePermissionLists(LOCAL_SETTINGS, settings, lists, "settings.local"); }
  catch (e) { return res.status(500).json({ error: "Couldn't save the rules: " + String(e?.message || e).slice(0, 200) }); }
  res.json({ items: bookkeepingState(lists), added: ids, moved });
});

// Is Auto mode available on this account (FR-255)? One cheap turn with the mode set; asked only when Auto is picked or sent,
// remembered while the answer is yes, asked again after five minutes when it was no.
let autoModeCheck = null;
const checkAutoMode = () => (autoModeCheck ??= (async () => {
  const abortController = new AbortController();
  let out;
  try {
    const q = query({ prompt: "Reply with the single word ok. Do not use tools.", options: { cwd: HOME, settingSources: [], tools: [], maxTurns: 1, persistSession: false, permissionMode: "auto", model: "haiku", abortController } });
    let mode = null, ok = false;
    for await (const m of q) {
      if (m.type === "system" && m.subtype === "init") mode = m.permissionMode;
      if (m.type === "result") ok = m.subtype === "success" && !m.is_error;
    }
    out = { available: ok && mode === "auto" };
  } catch (e) { out = { available: false, reason: String(e?.message || e).slice(0, 200) }; }
  finally { abortController.abort(); }
  if (!out.available) setTimeout(() => { autoModeCheck = null; }, 5 * 60 * 1000).unref();
  return out;
})());
app.get("/api/auto-mode", async (req, res) => res.json(await checkAutoMode()));

// ---------- command console (spec command-console FR-100 to FR-110) ----------
// Claude Code built-ins that run in the console: readouts and session upkeep. /api/commands marks them console: true.
const CONSOLE_COMMANDS = ["usage", "context", "mcp", "skill-doctor", "list-agents", "recap", "compact", "reload-skills", "reload-plugins"];
const CONSOLE_FILE = path.join(DATA, "console.json");
const CONSOLE_KEEP = 200, CONSOLE_TIMEOUT_MS = 2 * 60 * 1000;
const loadConsole = () => { try { return JSON.parse(fs.readFileSync(CONSOLE_FILE, "utf8")); } catch { return { sessionId: null, entries: [] }; } };
const saveConsole = (c) => fs.writeFileSync(CONSOLE_FILE, JSON.stringify({ ...c, entries: c.entries.slice(-CONSOLE_KEEP) }, null, 2));
let consoleRunning = null; // { command, at } while a command runs; one at a time (FR-104)

// One console command on the console's own session, resumed between commands (FR-107). No tools, so no cards (FR-110).
const runConsoleCommand = async (command) => {
  const state = loadConsole();
  const abortController = new AbortController();
  const timer = setTimeout(() => abortController.abort(), CONSOLE_TIMEOUT_MS);
  const sessionId = state.sessionId || randomUUID();
  let output = "", reply = "", ok = true;
  try {
    const q = query({ prompt: command, options: {
      cwd: HOME,
      settingSources: ["user", "project", "local"],
      tools: [],
      canUseTool: async () => ({ behavior: "deny", message: "The command console runs no tools." }),
      maxTurns: 1,
      abortController,
      ...(state.sessionId ? { resume: sessionId } : { sessionId }),
    } });
    for await (const msg of q) {
      if (msg.type === "system" && msg.subtype === "local_command_output") output += msg.content;
      else if (msg.type === "assistant" && msg.local_command_source) output += msg.local_command_source;
      else if (msg.type === "result") {
        if (msg.subtype === "success") reply = msg.result || "";
        else { ok = false; reply = (msg.errors || []).join("; ") || msg.subtype; }
      }
    }
  } catch (e) {
    ok = false;
    reply = abortController.signal.aborted ? "No answer within 2 minutes." : String(e?.message || e).slice(0, 300);
  } finally {
    clearTimeout(timer);
  }
  // A command that answers with a model reply instead of printed output (for example /recap) shows that reply.
  const text = output || reply || "(no output)";
  const entry = { id: randomUUID(), command, output: ok ? text : `<local-command-stderr>Couldn't run ${command.split(/\s/)[0]}: ${text}</local-command-stderr>`, ok, at: consoleRunning?.at || Date.now() };
  const latest = loadConsole();
  saveConsole({ ...latest, sessionId, entries: [...latest.entries, entry] });
  return entry;
};

app.get("/api/console", (req, res) => {
  const { entries } = loadConsole();
  res.json({ entries, running: !!consoleRunning, ...(consoleRunning ? { pending: consoleRunning } : {}) });
});
app.post("/api/console", async (req, res) => {
  const { command } = req.body || {};
  const text = typeof command === "string" ? command.trim() : "";
  const name = /^\/([^\s]+)/.exec(text)?.[1];
  // Only console commands that Claude Code offers here; anything else would make the console a hidden chat (FR-109).
  const offered = commandsCache?.data || await refreshCommands().catch(() => []);
  if (!name || text.length > 1000 || !offered.some((c) => c.console && c.name === name)) return res.status(400).json({ error: "The console runs console commands only." });
  if (consoleRunning) return res.status(409).json({ error: "A console command is already running." });
  consoleRunning = { command: text, at: Date.now() };
  try { res.json(await runConsoleCommand(text)); } // closing the request doesn't cancel the command (FR-104)
  finally { consoleRunning = null; }
});
app.post("/api/console/reset", (req, res) => {
  if (consoleRunning) return res.status(409).json({ error: "Wait for the running command to finish." });
  const at = Date.now();
  saveConsole({ sessionId: null, entries: [], resetAt: at });
  res.json({ ok: true, resetAt: at });
});

// /btw: a quick side question about the current chat. It runs on a throwaway fork of the chat's session (never saved),
// with no tools and one reply, so it never changes files or the main conversation. Works while a turn is running.
app.post("/api/btw", async (req, res) => {
  const { text, chatId, model } = req.body || {};
  if (typeof text !== "string" || !text.trim()) return res.status(400).json({ error: "Ask a question after /btw." });
  if (text.trim().length > 4000) return res.status(400).json({ error: "The question is too long." });
  if (model != null && model !== "" && !MODELS.includes(model)) return res.status(400).json({ error: "Unknown model" });
  const chat = chatId != null ? loadChats().find((c) => c.id === chatId) : null;
  if (chatId != null && !chat) return res.status(404).json({ error: "Chat not found" });
  const abortController = new AbortController();
  res.on("close", () => { if (!res.writableFinished) abortController.abort(); });
  try {
    const q = query({ prompt: text.trim(), options: {
      cwd: HOME,
      settingSources: ["user", "project", "local"],
      systemPrompt: { type: "preset", preset: "claude_code", append: "This is a quick side question (/btw) asked in Claude Studio while the main conversation continues. Answer briefly from what you already know of the conversation. You have no tools for this answer." },
      tools: [],
      maxTurns: 1,
      persistSession: false,
      abortController,
      ...(model ? { model } : {}),
      ...(chat ? { resume: chat.sessionId, forkSession: true } : {}),
    } });
    let answer = "";
    for await (const msg of q) if (msg.type === "result") answer = msg.subtype === "success" ? msg.result : (msg.errors || []).join("; ") || "No answer.";
    res.json({ answer });
  } catch (e) {
    if (!res.headersSent) res.status(502).json({ error: String(e?.message || e).slice(0, 300) });
  }
});

// ---------- Companions and places (spec worlds-v2 FR-206 to FR-210; before that custom-world FR-139 to FR-154) ----------
// Two libraries in this channel's data folder; every item in them passed its check (and places the readability fix).
// { version: 2, companions: [item], places: [item], activeCompanion, activePlace, splitNotice? }
// item = { id, name, createdAt, description, model, costUsd, world } where world is a companion { name, creature, lines }
// or a place { name, scene }.
// The libraries live in worlds2.json. worlds.json keeps the v0.10 library as it was, so a Studio rolled back to v0.14 or
// older still finds its worlds, and nothing it saves there can overwrite the companions and places (QA F-4).
const WORLDS_FILE = path.join(DATA, "worlds2.json");
const WORLDS_OLD = path.join(DATA, "worlds.json");
const WORLDS_V1 = path.join(DATA, "worlds.v1.json");
const WORLD_MODELS = ["sonnet", "opus", "haiku"];
// Built-in Claude (classic) (worlds-v2 FR-219): can be in use, but isn't stored, renamed, exported or deleted.
const CLASSIC_ID = "claude-classic";
const KINDS = {
  companion: { check: checkCompanion, list: "companions", active: "activeCompanion", label: "companion", format: "claude-studio-companion", ext: "studio-companion" },
  place: { check: checkPlace, list: "places", active: "activePlace", label: "place", format: "claude-studio-place", ext: "studio-place" },
};
const halves = (item) => {
  const w = item.world, d = item.description || {};
  const base = { createdAt: item.createdAt, model: item.model, costUsd: item.costUsd };
  return [
    { ...base, id: item.id, name: item.name, description: { creature: d.creature || "", changes: d.changes || [], ...(d.imported ? { imported: true } : {}) }, world: { name: w.name, creature: w.creature, lines: w.lines } },
    { ...base, id: randomUUID(), name: item.name, description: { environment: d.environment || "", changes: [], ...(d.imported ? { imported: true } : {}) }, world: { name: w.name, scene: w.scene } },
  ];
};
const saveWorlds = (lib) => { const tmp = WORLDS_FILE + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(lib, null, 2)); fs.renameSync(tmp, WORLDS_FILE); };
const EMPTY_LIB = () => ({ version: 2, companions: [], places: [], activeCompanion: null, activePlace: null });
const readJson = (f) => { try { return { j: JSON.parse(fs.readFileSync(f, "utf8")) }; } catch (e) { return { missing: e.code === "ENOENT" }; } };
// No worlds2.json yet: start from worlds.json. A v0.10 library is split once into the two lists (FR-208), after keeping a
// copy; worlds.json itself isn't changed. A v2 library found there (written by an early v0.15 build) moves to worlds2.json,
// and worlds.json gets its v0.10 copy back.
const firstLoad = () => {
  const { j: old } = readJson(WORLDS_OLD);
  if (old?.version === 2 && !Array.isArray(old.worlds)) {
    saveWorlds(old);
    if (fs.existsSync(WORLDS_V1)) fs.copyFileSync(WORLDS_V1, WORLDS_OLD);
    else fs.writeFileSync(WORLDS_OLD, JSON.stringify({ active: null, worlds: [] }, null, 2));
    console.log(`Moved the companions and places to ${WORLDS_FILE}.`);
    return old;
  }
  if (!Array.isArray(old?.worlds)) return null; // nothing to keep: Claude in the Meadow
  if (!fs.existsSync(WORLDS_V1)) fs.copyFileSync(WORLDS_OLD, WORLDS_V1);
  const lib = { ...EMPTY_LIB(), splitNotice: old.worlds.length > 0 };
  for (const item of old.worlds.filter((x) => x && typeof x.id === "string" && !checkWorld(x.world))) {
    const [c, p] = halves(item);
    lib.companions.push(c); lib.places.push(p);
    if (old.active === item.id) { lib.activeCompanion = c.id; lib.activePlace = p.id; }
  }
  saveWorlds(lib);
  console.log(`Split ${lib.companions.length} world(s) into companions and places (copy kept in ${WORLDS_V1}).`);
  return lib;
};
const loadWorlds = () => {
  const r = readJson(WORLDS_FILE);
  const j = r.j || (r.missing ? firstLoad() : null);
  if (!j) return EMPTY_LIB(); // missing or damaged: Claude in the Meadow
  const ok = (kind) => (Array.isArray(j[KINDS[kind].list]) ? j[KINDS[kind].list] : []).filter((x) => x && typeof x.id === "string" && !KINDS[kind].check(x.world));
  const companions = ok("companion"), places = ok("place");
  return { version: 2, companions, places,
    activeCompanion: j.activeCompanion === CLASSIC_ID || companions.some((x) => x.id === j.activeCompanion) ? j.activeCompanion : null,
    activePlace: places.some((x) => x.id === j.activePlace) ? j.activePlace : null,
    ...(j.splitNotice ? { splitNotice: true } : {}) };
};
const findItem = (lib, id) => {
  for (const kind of Object.keys(KINDS)) { const i = lib[KINDS[kind].list].findIndex((x) => x.id === id); if (i >= 0) return { kind, i, item: lib[KINDS[kind].list][i] }; }
  return null;
};
const textOk = (v, min, max) => typeof v === "string" && v.trim().length >= min && v.trim().length <= max;
// A free name in its own list: "Momo", then "Momo (2)", "Momo (3)"… (custom-world FR-154).
const freeName = (list, name) => { let n = name, i = 2; while (list.some((x) => x.name.toLowerCase() === n.toLowerCase())) n = `${name.slice(0, 34)} (${i++})`; return n; };
const addItem = (lib, kind, entry) => {
  const list = lib[KINDS[kind].list];
  const w = { ...entry.world, name: freeName(list, entry.world.name) };
  const item = { id: randomUUID(), name: w.name, createdAt: Date.now(), description: entry.description, model: entry.model, costUsd: entry.costUsd, world: kind === "place" ? readable(w) : w };
  list.unshift(item);
  return item;
};

// One generation at a time per channel (custom-world FR-141). It runs as a job on the server: closing the dialog or
// leaving the page doesn't stop it, only Stop does (user decision 2026-10-16, worlds-v2 FR-209 note). A v2 companion
// takes Claude 2-4 minutes, so companions get 5 minutes and places keep 120 s. The last finished job is kept until a
// page picks it up, so the page that's open then can say it's ready.
let worldJob = null, worldLast = null;
const LIMIT_MS = { companion: 300_000, place: 120_000 };
const GEN = {
  companion: { schema: COMPANION_SCHEMA, prompt: COMPANION_PROMPT, to: toCompanion, check: checkCompanion, intro: "Companion", invalid: "Couldn't make a valid companion from that. Try again or describe it differently." },
  place: { schema: PLACE_SCHEMA, prompt: PLACE_PROMPT, to: toPlace, check: checkPlace, intro: "Place", invalid: "Couldn't make a valid place from that. Try again or describe it differently." },
};
// Redraw in new style (FR-220): a Change… whose change is fixed here, from the companion's own description.
const REDRAW_CHANGE = "Redraw this companion in the format described above: the same creature, colours, character and name, now with the 'o' outline, three-tone shading and all 11 frames.";
const worldPrompt = (b, g, problem) => [
  `${g.intro}: ${b.description.trim()}`,
  ...(b.base ? [`Start from this ${b.kind} and keep everything else the same:\n${JSON.stringify(b.base)}`, `Change: ${b.change.trim()}`] : []),
  ...(problem ? [`Your last answer was not valid: ${problem} Fix that and answer again.`] : []),
].join("\n\n");
// Runs one generation; resolves to [HTTP status, body] whether or not anyone is still waiting for it.
const runWorldJob = async (job, b, g, model) => {
  let costUsd = 0, problem = null;
  try {
    for (let attempt = 0; attempt < 2 && !job.abortController.signal.aborted; attempt++) { // one retry when the answer fails the check
      // maxTurns 4: delivering the structured output takes turns of its own, and the SDK re-asks when its schema check
      // fails. With no tools that is all a turn can be; the time limit still bounds it.
      job.q = query({ prompt: worldPrompt(b, g, problem), options: {
        cwd: HOME, settingSources: [], tools: [], maxTurns: 4, persistSession: false, abortController: job.abortController, model,
        systemPrompt: g.prompt, outputFormat: { type: "json_schema", schema: g.schema },
      } });
      let out = null, said = "", ok = false;
      try {
        for await (const m of job.q) if (m.type === "result") { costUsd += m.total_cost_usd || 0; out = m.structured_output; ok = m.subtype === "success"; said = ok ? m.result : ""; }
      } catch (e) { // the SDK throws on an error result (e.g. max turns): counts as no data, so it gets the retry
        if (!job.abortController.signal.aborted) console.warn("Generation attempt failed:", String(e?.message || e).slice(0, 300));
        out = null; ok = false;
      }
      if (job.abortController.signal.aborted) break;
      // A plain-text answer with no data is Claude declining: shown as text. An SDK error result is treated like
      // invalid data: retried once, then the plain message.
      if (out == null && ok && String(said).trim()) return [422, { error: `Claude couldn't make this ${b.kind}: ${String(said).trim().slice(0, 300)}`, costUsd }];
      const made = out == null ? null : g.to(out);
      problem = made ? g.check(made) : `There was no ${b.kind} data in the answer.`;
      if (problem && attempt === 0) console.warn(`Generated ${b.kind} failed the check:`, String(problem).slice(0, 300));
      // A retry only when it can still finish: past half the time limit it would just run out (and cost).
      if (problem && Date.now() - job.startedAt > job.limitMs / 2) break;
      if (!problem) return [200, { draft: { kind: b.kind, world: b.kind === "place" ? readable(made) : made, description: b.description.trim(), model }, costUsd, retried: attempt > 0 }];
    }
    if (job.timedOut) return [504, { error: "That took too long. Try again, maybe with a simpler description.", costUsd }];
    if (job.stopped) return [499, { error: "Stopped.", costUsd }];
    console.warn(`Generated ${b.kind} failed the check twice:`, String(problem).slice(0, 300));
    return [502, { error: g.invalid, costUsd }];
  } catch (e) {
    if (job.timedOut) return [504, { error: "That took too long. Try again, maybe with a simpler description.", costUsd }];
    if (!job.stopped) console.warn("Generation failed:", String(e?.message || e).slice(0, 300));
    return [job.stopped ? 499 : 502, { error: job.stopped ? "Stopped." : g.invalid, costUsd }]; // never the raw SDK text
  }
};
app.post("/api/worlds/generate", async (req, res) => {
  const b = { ...(req.body || {}) };
  if (b.redraw === true && b.kind === "companion") b.change = REDRAW_CHANGE;
  const g = GEN[b.kind];
  if (!g) return res.status(400).json({ error: "Say whether to create a companion or a place." });
  if (!textOk(b.description, 3, 300)) return res.status(400).json({ error: `Describe the ${b.kind} (3-300 characters).` });
  const model = b.model || "sonnet";
  if (!WORLD_MODELS.includes(model)) return res.status(400).json({ error: "Unknown model" });
  if (b.base != null && (g.check(b.base) || !textOk(b.change, 3, 200))) return res.status(400).json({ error: "Say what should change (3-200 characters)." });
  if (worldJob) return res.status(409).json({ error: "Something is already being created. Wait for it to finish, or stop it." });
  const job = { id: randomUUID(), kind: b.kind, description: b.description.trim(), model, redrawId: b.redraw === true && typeof b.redrawId === "string" ? b.redrawId : null,
    startedAt: Date.now(), limitMs: LIMIT_MS[b.kind], abortController: new AbortController(), q: null, timedOut: false, stopped: false };
  worldJob = job;
  worldLast = null;
  const timer = setTimeout(() => { job.timedOut = true; job.abortController.abort(); try { job.q?.close(); } catch {} }, job.limitMs);
  const [status, body] = await runWorldJob(job, b, g, model);
  clearTimeout(timer);
  try { job.q?.close(); } catch {}
  if (worldJob === job) worldJob = null;
  worldLast = { id: job.id, kind: job.kind, description: job.description, model, redrawId: job.redrawId, startedAt: job.startedAt, endedAt: Date.now(),
    state: status === 200 ? "done" : job.stopped ? "stopped" : "failed", ...body,
    // A redraw keeps the companion's library name, whatever name the new drawing carries (QA F-2).
    name: (job.redrawId && findItem(loadWorlds(), job.redrawId)?.item.name) || body.draft?.world?.name || null };
  if (!res.destroyed) res.status(status === 499 ? 409 : status).json({ ...body, jobId: job.id });
});
// The job now and the last one that finished (for the page that's open when it ends).
app.get("/api/worlds/job", (req, res) => res.json({
  running: worldJob && { id: worldJob.id, kind: worldJob.kind, description: worldJob.description, redrawId: worldJob.redrawId, startedAt: worldJob.startedAt, limitMs: worldJob.limitMs },
  last: worldLast,
}));
// Stop is the only way to end a job early.
app.post("/api/worlds/job/stop", (req, res) => {
  if (worldJob) { worldJob.stopped = true; worldJob.abortController.abort(); try { worldJob.q?.close(); } catch {} }
  res.json({ ok: true });
});
// A page took the result (or dismissed it).
app.delete("/api/worlds/job/:id", (req, res) => { if (worldLast?.id === req.params.id) worldLast = null; res.status(204).end(); });
app.get("/api/worlds", (req, res) => res.json(loadWorlds()));
// The one-time "your worlds were split" hint has been seen (design worlds-v2 §2).
app.put("/api/worlds/notice", (req, res) => { const lib = loadWorlds(); delete lib.splitNotice; saveWorlds(lib); res.json({ ok: true }); });
// Save a draft from the preview; the server checks it again, so a hand-made POST can't store bad data.
app.post("/api/worlds", (req, res) => {
  const d = req.body?.draft || {};
  const k = KINDS[d.kind];
  if (!k) return res.status(400).json({ error: "Unknown kind" });
  const world = d.world && typeof d.world === "object" ? { ...d.world, name: typeof d.world.name === "string" ? d.world.name.trim() : d.world.name } : d.world;
  const problem = k.check(world);
  if (problem) return res.status(400).json({ error: problem });
  if (!textOk(d.description, 3, 300)) return res.status(400).json({ error: "The description is missing." });
  const changes = Array.isArray(d.changes) ? d.changes.filter((c) => textOk(c, 3, 200)).slice(-20) : [];
  const lib = loadWorlds();
  if (lib[k.list].length >= MAX_WORLDS) return res.status(409).json({ error: `Library full (${MAX_WORLDS}). Delete a ${k.label} to make room.` });
  const item = addItem(lib, d.kind, { world, model: WORLD_MODELS.includes(d.model) ? d.model : "sonnet", costUsd: Number(d.costUsd) > 0 ? Number(d.costUsd) : 0,
    description: { [d.kind === "place" ? "environment" : "creature"]: d.description.trim(), changes } });
  if (req.body?.use) lib[k.active] = item.id;
  saveWorlds(lib);
  res.status(201).json({ id: item.id, name: item.name, kind: d.kind });
});
// Choose the companion or the place in use, independently (FR-206); null is Claude or the Meadow.
app.put("/api/worlds/active", (req, res) => {
  const k = KINDS[req.body?.kind];
  if (!k) return res.status(400).json({ error: "Unknown kind" });
  const id = req.body?.id ?? null;
  const lib = loadWorlds();
  if (id !== null && !(req.body.kind === "companion" && id === CLASSIC_ID) && !lib[k.list].some((x) => x.id === id)) return res.status(404).json({ error: "Not found" });
  lib[k.active] = id;
  saveWorlds(lib);
  res.json({ [k.active]: id });
});
// Keep a redraw (FR-220): the companion keeps its id, name and lines; only its creature becomes the v2 one.
app.put("/api/worlds/:id/creature", (req, res) => {
  const lib = loadWorlds();
  const f = findItem(lib, req.params.id);
  if (!f || f.kind !== "companion") return res.status(404).json({ error: "Not found" });
  const c = req.body?.creature;
  const next = { name: f.item.world.name, creature: c, lines: f.item.world.lines };
  const problem = c?.version !== 2 ? "The new drawing must be in the new style." : checkCompanion(next);
  if (problem) return res.status(400).json({ error: problem });
  f.item.world = next;
  f.item.costUsd = (Number(f.item.costUsd) || 0) + (Number(req.body?.costUsd) > 0 ? Number(req.body.costUsd) : 0);
  f.item.redrawnAt = Date.now();
  saveWorlds(lib);
  res.json({ id: f.item.id, name: f.item.name });
});
app.patch("/api/worlds/:id", (req, res) => {
  const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
  if (!/^[^\u0000-\u001f\u007f<>]{1,40}$/.test(name)) return res.status(400).json({ error: "Enter a name (1-40 characters)." });
  const lib = loadWorlds();
  const f = findItem(lib, req.params.id);
  if (!f) return res.status(404).json({ error: "Not found" });
  f.item.name = f.item.world.name = name;
  saveWorlds(lib);
  res.json({ name });
});
app.delete("/api/worlds/:id", (req, res) => {
  const lib = loadWorlds();
  const f = findItem(lib, req.params.id);
  if (!f) return res.status(404).json({ error: "Not found" });
  lib[KINDS[f.kind].list].splice(f.i, 1);
  if (lib[KINDS[f.kind].active] === req.params.id) lib[KINDS[f.kind].active] = null; // back to Claude or the Meadow
  saveWorlds(lib);
  res.status(204).end();
});
// Export one companion or place as a file (FR-210): only that, no ids, chats or paths.
app.get("/api/worlds/:id/export", (req, res) => {
  const f = findItem(loadWorlds(), req.params.id);
  if (!f) return res.status(404).json({ error: "Not found" });
  const k = KINDS[f.kind], item = f.item;
  const file = { format: k.format, version: 1, name: item.name, createdAt: new Date(item.createdAt).toISOString(), description: item.description, model: item.model, [f.kind]: item.world };
  const safe = item.name.replace(/[^\w -]+/g, "").trim() || f.kind;
  res.setHeader("Content-Disposition", `attachment; filename="${safe}.${k.ext}.json"`);
  res.type("application/json").send(JSON.stringify(file, null, 2));
});
// Import (FR-210): a companion, a place, or a v0.10 world (which adds one of each). The file is untrusted, so it gets
// the same checks and readability fix as generated data.
app.post("/api/worlds/import", (req, res) => {
  const f = req.body?.file;
  const kinds = !f || typeof f !== "object" || f.version !== 1 ? null
    : f.format === "claude-studio-world" ? ["companion", "place"] : f.format === KINDS.companion.format ? ["companion"] : f.format === KINDS.place.format ? ["place"] : null;
  if (!kinds) return res.status(400).json({ error: "That file isn't a Claude Studio companion, place or world." });
  if (JSON.stringify(f).length > 64 * 1024) return res.status(400).json({ error: "That file is too big (max 64 KB)." });
  const old = f.format === "claude-studio-world";
  const problem = old ? checkWorld(f.world) : KINDS[kinds[0]].check(f[kinds[0]]);
  if (problem) return res.status(400).json({ error: problem });
  const lib = loadWorlds();
  const full = kinds.find((kind) => lib[KINDS[kind].list].length >= MAX_WORLDS);
  if (full) return res.status(409).json({ error: `Library full (${MAX_WORLDS}). Delete a ${full} to make room.` });
  const desc = f.description || {};
  const model = WORLD_MODELS.includes(f.model) ? f.model : "sonnet";
  const added = kinds.map((kind) => {
    const src = old ? (kind === "companion" ? { name: f.world.name, creature: f.world.creature, lines: f.world.lines } : { name: f.world.name, scene: f.world.scene }) : f[kind];
    const key = kind === "place" ? "environment" : "creature";
    const item = addItem(lib, kind, { world: { ...src, name: src.name.trim() }, model, costUsd: 0,
      description: { [key]: textOk(desc[key], 1, 300) ? desc[key].trim() : "", changes: [], imported: true } });
    return { kind, id: item.id, name: item.name };
  });
  saveWorlds(lib);
  res.status(201).json({ added });
});

// Start a turn. The response is a stream of newline-delimited JSON events. Closing it does not stop the turn:
// the page can attach again with GET /api/chats/:id/live (spec reliable-chats FR-65 to FR-68).
app.post("/api/turn", async (req, res) => {
  const { text, chatId, project = "General", permissionMode = "default", model, role } = req.body || {};
  const bad = (error) => res.status(400).json({ error });
  if (updates.updating()) return res.status(409).json({ error: "Studio is updating. Try again in a minute." });
  if (typeof text !== "string" || !text.trim()) return bad("text is required");
  if (text.trim().length > MAX_TEXT) return bad(`text is longer than ${MAX_TEXT.toLocaleString("en-US")} characters`);
  if (!MODES.includes(permissionMode)) return bad("Unknown permission mode");
  if (model != null && model !== "" && !MODELS.includes(model)) return bad("Unknown model");
  if (project !== "General" && !listProjects().includes(project)) return bad("Unknown project");
  if (permissionMode === "workFreely" && project === "General") return bad("Work freely needs a project");

  // A role chip: a skill from the session's own list, or a saved custom chip. Instruction text never comes from the request.
  let prompt = text;
  if (role != null) {
    if (typeof role !== "object" || Array.isArray(role)) return bad("Invalid role");
    const keys = Object.keys(role).sort().join(",");
    if (keys === "kind,name" && role.kind === "skill") {
      const commands = await loadCommands();
      if (!commands.some((c) => c.name === role.name)) return bad("Unknown skill");
      prompt = `/${role.name} ${text}`;
    } else if (keys === "id" && typeof role.id === "string") {
      const c = loadRoles().custom.find((x) => x.id === role.id && (x.scope === "all" || x.scope === project));
      if (!c) return bad("Unknown role");
      prompt = c.kind === "skill"
        ? `/${c.skill} ${text}`
        : `<studio-role label="${c.label.replace(/["<>]/g, "")}">\n${c.text}\n</studio-role>\n\n${text}`;
    } else return bad("Invalid role");
  }

  let chat = null;
  if (chatId != null) {
    chat = loadChats().find((c) => c.id === chatId);
    if (!chat) return res.status(404).json({ error: "Chat not found" });
    if (chat.removed) return res.status(409).json({ error: "This chat is in the Recycle bin. Restore it first." });
    if (chatTurns.has(chat.id)) return res.status(409).json({ error: "This chat is already working on a reply. Wait for it or stop it first." });
  }
  const isNew = !chat;
  if (isNew) {
    chat = { id: randomUUID(), sessionId: randomUUID(), title: text.replace(/\s+/g, " ").slice(0, 60), project, created: Date.now() };
  }
  chat.project = project;
  chat.updated = Date.now();
  upsertChat(chat);
  setSessionProject(chat.sessionId, project);

  const abortController = new AbortController();
  const turn = { id: randomUUID(), chat, events: [], seq: 0, listeners: new Set(), pending: new Map(), abortController, afterUuid: null, stopped: false, cover: new Set(), startedAt: Date.now() };
  chatTurns.set(chat.id, turn); // claimed before the first await, so a second request gets 409
  turns.set(turn.id, turn);
  // History is cut at the last message before this turn (FR-69), and record entries are placed from here (FR-77).
  if (!isNew) turn.afterUuid = (await sessionMessages(chat.sessionId)).at(-1)?.uuid ?? null;
  record(chat.id, { type: "start", turnId: turn.id, at: Date.now(), model: model || null, permissionMode, ...(role ? { role } : {}), afterUuid: turn.afterUuid });

  // Every permission prompt and AskUserQuestion goes to every attached tab and waits up to 30 minutes for an answer.
  const canUseTool = (toolName, input, { signal, suggestions, decisionReason, blockedPath, toolUseID }) =>
    new Promise((resolve) => {
      const requestId = randomUUID();
      const at = Date.now();
      // Allowed without a card, with a visible line: a bookkeeping append (trust-levels FR-264), an ordinary command under
      // Work freely (FR-246), or the same kind of action as one allowed for this reply (FR-125). Never a risky one.
      let by = null, file = null;
      if (toolName !== "AskUserQuestion") {
        file = bookkeepingAppend(toolName, input);
        if (file) by = "bookkeeping";
        else if (!isRisky(toolName, input)) {
          if (workFreely && SHELLS.has(toolName)) by = "level";
          else if (turn.cover.has(replyKey(toolName, input))) by = "reply";
        }
      }
      if (by) {
        const detail = String(file || shellCommand(input) || input?.file_path || input?.url || toolName).slice(0, 300);
        emit(turn, { type: "auto-allow", toolName, toolUseId: toolUseID, detail, by, at });
        record(chat.id, { type: "permission", turnId: turn.id, requestId, toolUseId: toolUseID, toolName, input: capInput(input), auto: true, at });
        record(chat.id, { type: "settled", turnId: turn.id, requestId, outcome: "allow", by, ...(file ? { file } : {}), at });
        return resolve({ behavior: "allow", updatedInput: input });
      }
      const card = { resolve, input, suggestions, toolName, at, key: replyKey(toolName, input), ...ruleSuggestions(toolName, input, project, suggestions) };
      turn.pending.set(requestId, card);
      card.timer = setTimeout(() => settle(turn, requestId, { behavior: "deny", message: "No answer within 30 minutes." },
        { outcome: "deny", by: "timeout", message: "No answer within 30 minutes." }), CARD_TIMEOUT_MS);
      signal?.addEventListener("abort", () => settle(turn, requestId, { behavior: "deny", message: "Cancelled" }, { outcome: "deny", by: "cancelled" }));
      emit(turn, { type: "permission", requestId, toolUseId: toolUseID, toolName, input, decisionReason, blockedPath, canAlwaysAllow: toolName !== "AskUserQuestion",
        suggestedRule: card.suggestedRule, exactRule: card.exactRule, risky: card.risky, ...(card.noMatch ? { noMatch: true } : {}), at, expiresAt: at + CARD_TIMEOUT_MS });
      record(chat.id, { type: "permission", turnId: turn.id, requestId, toolUseId: toolUseID, toolName, input: capInput(input), decisionReason, at });
    });

  const project_note = project && project !== "General"
    ? `Claude Studio: the user picked project "${project}" (folder ${path.join(PROJECTS, project)}). Treat it as the active project.`
    : "Claude Studio: no project picked (General).";
  // Work freely (trust-levels FR-252): the SDK gets "default" and these rules. Not acceptEdits, which would also accept edits
  // elsewhere in Home (FR-248); Ask and Blocked rules still win over allowedTools (probe 2026-10-19).
  const workFreely = permissionMode === "workFreely";
  const replyRules = [...new Set([...(chat.allowRules || []), ...projectAllow(chat.project || project), ...(workFreely ? workFreelyRules(project) : [])])];
  const options = {
    cwd: HOME,
    settingSources: ["user", "project", "local"],
    systemPrompt: { type: "preset", preset: "claude_code", append: `${project_note} The user is chatting through Claude Studio, a local web UI that renders Markdown and shows AskUserQuestion as clickable options.` },
    permissionMode: workFreely ? "default" : permissionMode,
    canUseTool,
    // Rules saved for this chat only (FR-114). Claude Code forgets "session" rules between queries, so Studio
    // keeps them on the chat and passes them with every reply, plus the chat's project rules (spec project-rules FR-200).
    ...(replyRules.length ? { allowedTools: replyRules } : {}),
    includePartialMessages: true,
    abortController,
    ...(model ? { model } : {}),
    ...(isNew ? { sessionId: chat.sessionId } : { resume: chat.sessionId }),
  };

  // The message itself is the first event, so a tab that attaches later shows it too.
  emit(turn, { type: "prompt", text, ...(role ? { role } : {}), at: Date.now() });
  attachTurn(turn, res, chat, 0);

  let result = null, error = null;
  const produced = turnSummary();
  try {
    const q = query({ prompt, options });
    turn.q = q;
    for await (const msg of q) {
      if (msg.type === "result") result = msg;
      produced.see(msg);
      emit(turn, { type: "sdk", msg });
    }
  } catch (e) {
    error = String(e?.message || e);
    emit(turn, { type: "error", error });
  } finally {
    for (const id of [...turn.pending.keys()]) settle(turn, id, { behavior: "deny", message: "Cancelled" }, { outcome: "deny", by: "cancelled" });
    const failed = result && (result.is_error || result.subtype !== "success");
    const status = turn.stopped ? "stopped" : error ? "error" : failed ? "error" : result ? "done" : "error";
    const at = Date.now();
    const summary = {
      ...(result?.duration_ms != null ? { durationMs: result.duration_ms } : {}),
      ...(result?.total_cost_usd != null ? { costUsd: result.total_cost_usd } : {}),
      ...produced.result(),
    };
    record(chat.id, {
      type: "end", turnId: turn.id, at, status,
      ...(error ? { reason: error.slice(0, 300) } : failed ? { reason: result.subtype } : {}),
      ...summary,
    });
    chatTurns.delete(chat.id);
    turns.delete(turn.id);
    const lastEnd = { turnId: turn.id, status, at, ...summary };
    patchChat(chat.id, { updated: at, lastEnd });
    emit(turn, { type: "done", lastEnd }); // the result summary, for the banner (spec away-status FR-186)
    for (const r of turn.listeners) r.end();
    turn.listeners.clear();
  }
});

// What a turn produced (spec away-status FR-185): the files its Write/Edit tools touched, with "created" when the Write
// result says so, and the first line of Claude's last text. Files made by shell commands aren't seen (Q-1).
const FILE_TOOLS = new Set(["Write", "Edit", "MultiEdit", "NotebookEdit"]);
const homeRel = (p) => {
  const rel = path.relative(HOME, p);
  return rel && !rel.startsWith("..") && !path.isAbsolute(rel) ? rel.replace(/\\/g, "/") : p;
};
const plainLine = (text) => {
  const line = String(text).split(/\r?\n/).map((l) => l.trim()).find(Boolean) || "";
  const plain = line.replace(/^(#{1,6}\s+|>\s*|[-*+]\s+|\d+[.)]\s+)/, "").replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/[*_`~]+/g, "").trim();
  return plain.length > 140 ? plain.slice(0, 139) + "…" : plain;
};
const turnSummary = () => {
  const calls = new Map(), files = new Map();
  let lastText = "";
  return {
    see(msg) {
      const content = msg.message?.content;
      if (!Array.isArray(content)) return;
      if (msg.type === "assistant") {
        const text = content.filter((c) => c.type === "text").map((c) => c.text).join("\n").trim();
        if (text) lastText = text;
        for (const c of content) if (c.type === "tool_use" && FILE_TOOLS.has(c.name)) calls.set(c.id, { tool: c.name, file: c.input?.file_path || c.input?.notebook_path });
      } else if (msg.type === "user") {
        for (const c of content) {
          const call = c.type === "tool_result" && calls.get(c.tool_use_id);
          if (!call) continue;
          calls.delete(c.tool_use_id);
          if (c.is_error || typeof call.file !== "string" || !call.file) continue;
          const said = typeof c.content === "string" ? c.content : (c.content || []).map((x) => x.text || "").join(" ");
          const key = homeRel(call.file);
          if (!files.has(key) && files.size < 20) files.set(key, call.tool === "Write" && /\bcreated\b/i.test(said) ? "created" : "changed");
        }
      }
    },
    result() {
      const out = {};
      if (files.size) out.files = [...files].map(([p, kind]) => ({ path: p, kind }));
      const first = lastText && plainLine(lastText);
      if (first) out.firstLine = first;
      return out;
    },
  };
};

// The browser's answer to a permission prompt or question.
app.post("/api/turn/:turnId/permission/:requestId", async (req, res) => {
  const turn = turns.get(req.params.turnId);
  const p = turn?.pending.get(req.params.requestId);
  if (!p) return res.status(404).json({ error: "No such request" }); // already answered (another tab), timed out or stopped
  const { decision, answers, message, rule, where } = req.body || {};
  // Validate before resolving, so a bad answer leaves the request pending.
  if (answers != null) {
    const questions = new Set((p.input?.questions || []).map((q) => q.question));
    const entries = typeof answers === "object" && !Array.isArray(answers) ? Object.entries(answers) : null;
    if (!entries?.length || !entries.every(([k, v]) => questions.has(k) && typeof v === "string" && v.length <= 2000)) {
      return res.status(400).json({ error: "Invalid answers" });
    }
  } else if (!["allow", "always", "deny", "reply"].includes(decision)) return res.status(400).json({ error: "Invalid decision" });
  if (message != null && (typeof message !== "string" || message.length > 2000)) return res.status(400).json({ error: "Invalid message" });
  const id = req.params.requestId;
  // Always allow with a rule the user saw and may have edited (FR-111, FR-114): for this chat, or in Home's local settings.
  if (decision === "always" && rule != null) {
    const parsed = parseRule(rule);
    if (!parsed) { const problem = ruleProblem(rule); return res.status(400).json({ error: `${problem} ${RULE_HELP}`, problem, hint: RULE_HELP }); }
    if (!["chat", "project", "home"].includes(where)) return res.status(400).json({ error: "Invalid place to save the rule" });
    const text = ruleText(parsed);
    // This project (spec project-rules FR-201): into the chat's project file, and allowed for the rest of this reply.
    const project = turn.chat.project;
    if (where === "project") {
      if (!isListedProject(project)) return res.status(400).json({ error: "This chat isn't in a project." });
      try { await changeProjectRules(project, [text], []); }
      catch (e) { return res.status(500).json({ error: "Couldn't save the rule for " + project + ": " + String(e?.message || e).slice(0, 200) }); }
      if (!turns.has(turn.id) || !turn.pending.has(id)) return res.status(404).json({ error: "No such request" }); // answered meanwhile
    }
    if (where === "chat") {
      const rules = loadChats().find((c) => c.id === turn.chat.id)?.allowRules || [];
      if (!rules.includes(text)) patchChat(turn.chat.id, { allowRules: [...rules, text] });
      turn.chat.allowRules = [...new Set([...rules, text])];
    }
    settle(turn, id, { behavior: "allow", updatedInput: p.input, updatedPermissions: [{ type: "addRules", rules: [parsed], behavior: "allow", destination: where === "home" ? "localSettings" : "session" }] },
      { outcome: "always", by: "user", rule: text, where, ...(where === "project" ? { project } : {}) });
    return res.json({ ok: true });
  }
  if (decision === "reply") {
    if (p.toolName === "AskUserQuestion") return res.status(400).json({ error: "Invalid decision" });
    if (!p.risky) turn.cover.add(p.key);
    settle(turn, id, { behavior: "allow", updatedInput: p.input }, { outcome: "reply", by: "user" });
    return res.json({ ok: true });
  }
  if (decision === "deny") settle(turn, id, { behavior: "deny", message: message || "The user declined this." }, { outcome: "deny", by: "user", ...(message ? { message } : {}) });
  else if (answers) settle(turn, id, { behavior: "allow", updatedInput: { ...p.input, answers } }, { outcome: "answered", answers, by: "user" });
  else settle(turn, id, { behavior: "allow", updatedInput: p.input, ...(decision === "always" && p.suggestions ? { updatedPermissions: p.suggestions } : {}) }, { outcome: decision, by: "user" });
  res.json({ ok: true });
});

app.post("/api/turn/:turnId/interrupt", async (req, res) => {
  const turn = turns.get(req.params.turnId);
  if (!turn) return res.status(404).end();
  turn.stopped = true;
  // Stop works from any tab (FR-72); cards still waiting are cancelled for everyone.
  for (const id of [...turn.pending.keys()]) settle(turn, id, { behavior: "deny", message: "Cancelled" }, { outcome: "deny", by: "cancelled" });
  try { await turn.q.interrupt(); } catch { turn.abortController.abort(); }
  res.json({ ok: true });
});

// Bad request bodies (malformed JSON, too large) get a short JSON error, never a stack trace with file paths.
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const status = err.status || err.statusCode || 500;
  res.status(status).json({ error: status === 413 ? "Request too large" : status < 500 ? "Invalid request" : "Server error" });
});

app.listen(PORT, "127.0.0.1", () => {
  console.log(`Claude Studio (${CHANNEL}, ${VERSION}) on http://localhost:${PORT}`);
  console.log(`Home: ${HOME}  Data: ${DATA}`);
});
