// Renders the public website from site/index.html and the site folder's latest.json (design updates §2,
// design release-downloads §2). Used by publish.mjs for a full publish and for the release-only run.
import fs from "node:fs";
import path from "node:path";

export const REPO = "inventi-arkin/claude-studio";
// The counted download link (spec release-downloads FR-287): a GitHub Release asset, same file as on the website.
export const releaseUrl = (version, zipName) => `https://github.com/${REPO}/releases/download/v${version}/${zipName}`;
export const short = (v) => String(v).replace(/\.0$/, "");
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);

const LOGO = ["......oooooooooooo......", ".....obbbbbbbbbbbbo.....", "....oblllllllbbbbbbo....", "...oblbbbbbbbbbbbbbbo...", "...oblbbwebbbbwebbsso...", "...oblbbeebbbbeebbsso...",
  ".oooblbbeebbbbeebbssooo.", "obbbblbbbbbbbbbbbbssbbbo", "obbbbbbbbbbbbbbbbbssbbbo", "osssbbbbbbbbbbbbbbssssso", ".ooobbbbbbbbbbbbbbssooo.", "...obbbbbbbbbbbbbbsso...",
  "...obssssssssssssssso...", "....osssssssssssssso....", ".....oboobooooboobo.....", ".....oboobo..oboobo.....", ".....oboobo..oboobo.....", ".....osooso..osooso.....", "......o..o....o..o......"];
const PAL = { o: "#4a1f12", s: "#b5583c", b: "#d97757", l: "#f2a07f", e: "#1f1410", w: "#fff4ec" };
const rects = LOGO.flatMap((r, y) => [...r].map((c, x) => (PAL[c] ? `<rect x="${x}" y="${y}" width="1" height="1" fill="${PAL[c]}"/>` : ""))).join("");
const svg = (size, aria) => `<svg width="${size}" height="${Math.round(size * 19 / 24)}" viewBox="0 0 24 19" shape-rendering="crispEdges"${aria ? "" : ' aria-hidden="true"'}>${rects}</svg>`;
const longDate = (d) => new Date(d + "T12:00:00Z").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

// Writes index.html, site.css, screenshot.png and .nojekyll into siteDir. `counted` = the Download button points at
// the GitHub Release; otherwise at the website's own copy, and the page says so (FR-288, FR-292).
export const renderSite = ({ siteSrc, siteDir, latest, counted }) => {
  const { version, date, history, zip } = latest;
  const notesHtml = history.map((h, i) => `<details class="rel"${i === 0 ? " open" : ""}><summary><b>v${esc(short(h.version))}</b><span>${esc(h.title)} · ${esc(longDate(h.date))}</span>${i === 0 ? '<span class="tag">Latest</span>' : ""}</summary>
      <ul>${h.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></details>`).join("\n    ");
  const html = fs.readFileSync(path.join(siteSrc, "index.html"), "utf8")
    .replaceAll("{{LOGO_SVG}}", svg(32)).replaceAll("{{LOGO_ICON}}", encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 19" shape-rendering="crispEdges">${rects}</svg>`))
    .replaceAll("{{DOWNLOAD_URL}}", counted ? releaseUrl(version, zip.name) : `releases/${zip.name}`)
    .replaceAll("{{DOWNLOAD_NOTE}}", counted ? " · Downloads from GitHub" : "")
    .replaceAll("{{DOWNLOAD_FROM}}", counted
      ? "The Download button fetches the zip from GitHub, which counts downloads and, like any download site, may log your IP address."
      : "The Download button fetches the zip from this site.")
    .replaceAll("{{ZIP_NAME}}", zip.name).replaceAll("{{ZIP_SIZE}}", `${(zip.size / 1048576).toFixed(1)} MB`)
    .replaceAll("{{VERSION_SHORT}}", esc(short(version))).replaceAll("{{DATE_LONG}}", esc(longDate(date))).replaceAll("{{NOTES_HTML}}", notesHtml);
  fs.writeFileSync(path.join(siteDir, "index.html"), html);
  for (const f of ["site.css", "screenshot.png"]) fs.copyFileSync(path.join(siteSrc, f), path.join(siteDir, f));
  fs.writeFileSync(path.join(siteDir, ".nojekyll"), "");
  return html;
};
