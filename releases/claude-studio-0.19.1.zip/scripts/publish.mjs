// Publishes a release of Claude Studio to the public website (spec updates FR-222 to FR-226, design updates §2, D-4)
// and as a GitHub Release whose zip downloads GitHub counts (spec release-downloads FR-284 to FR-294).
// Usage: npm run publish-release                     asks for the version, title and notes
//        npm run publish-release -- --version 0.17.0 --title "Website and updates" --notes "line one|line two"
//        npm run publish-release -- --dry-run          builds everything into the site folder, pushes nothing
//        npm run publish-release -- --push             only pushes the site folder again (after a failed push)
//        npm run publish-release -- --release [--version 0.17.0]   only creates the GitHub Release for a version
//                                                     already in the site folder (also for older versions)
// What it does: checks that LIVE runs this clean, committed HEAD; writes release.json and the package version; commits
// "Release v<version>" and deploys it; zips a snapshot of the app files (no history, specs, designs, tests or site);
// writes latest.json, signs it, renders the website and pushes it to the public repository's main branch (GitHub Pages);
// then creates the GitHub Release with the same zip through the GitHub CLI (gh), which keeps its own sign-in.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import readline from "node:readline/promises";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { PRIVATE_KEY, KEY_DIR } from "./release-key.mjs";
import { REPO, renderSite, short } from "./site-render.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SITE_SRC = path.join(ROOT, "site");
const REMOTE = `https://github.com/${REPO}.git`;
const SITE_URL = "https://inventi-arkin.github.io/claude-studio/";
const KEEP_ZIPS = 5;
const EXCLUDE = ["specs", "design", "tests", "site"]; // never published (FR-223, FR-224)
const PUBLISHER = ["-c", "user.name=Claude Studio releases", "-c", "user.email=inventi-arkin@users.noreply.github.com"];

const args = process.argv.slice(2);
const flag = (n) => args.includes(`--${n}`);
const opt = (n) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : undefined; };
const SITE_DIR = path.resolve(opt("site-dir") || path.join(KEY_DIR, "site"));
const fail = (msg) => { console.error(`\n✗ ${msg}`); process.exit(1); };
const git = (cwd, ...a) => execFileSync("git", a, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
const run = (cmd, a, cwd = ROOT) => execFileSync(cmd, a, { cwd, stdio: "inherit", shell: process.platform === "win32" && cmd === "npm" });
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return d; } };
const cmpVersion = (a, b) => { const p = (v) => String(v).split(".").map((n) => Number(n) || 0); const x = p(a), y = p(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const sha256Of = (buf) => crypto.createHash("sha256").update(buf).digest("hex");

const pushSite = () => {
  console.log(`Pushing the website to ${REPO}…`);
  try { execFileSync("git", ["push", "-u", "origin", "main"], { cwd: SITE_DIR, stdio: "inherit" }); }
  catch {
    fail(`The push didn't go through. The release is built in ${SITE_DIR}.\n  1. Make sure the public repository exists: https://github.com/new → owner inventi-arkin, name claude-studio, Public, empty (no README).\n  2. Run: npm run publish-release -- --push   (Git asks you to sign in to GitHub the first time.)`);
  }
  console.log("✓ Website pushed.");
};
// One commit per change in the public repository, by the neutral publisher (FR-224, FR-293). False if nothing changed.
const commitSite = (message) => {
  if (!fs.existsSync(path.join(SITE_DIR, ".git"))) { git(SITE_DIR, "init", "-b", "main"); git(SITE_DIR, "remote", "add", "origin", REMOTE); }
  git(SITE_DIR, "add", "-A");
  if (!git(SITE_DIR, "status", "--porcelain")) return false;
  git(SITE_DIR, ...PUBLISHER, "commit", "-m", message);
  return true;
};
if (flag("push")) { pushSite(); console.log(`\n✓ Published. The site updates in a minute or two: ${SITE_URL}`); process.exit(0); }

// ---- GitHub Releases through the GitHub CLI (FR-284, FR-285, FR-288) ----
// Studio never reads or stores a GitHub token: gh signs in with its own login and keeps it in its own store (D-5).
const gh = (...a) => execFileSync("gh", a, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], windowsHide: true }).trim();
const ghState = () => {
  try { gh("--version"); } catch { return "missing"; }
  try { gh("auth", "status", "--hostname", "github.com"); return "ok"; } catch { return "signed-out"; }
};
const ghError = (e) => (String(e.stderr || e.message || e).split(/\r?\n/).map((l) => l.trim()).find(Boolean) || "unknown error").slice(0, 200);
const NO_RELEASE = { missing: "the GitHub CLI (gh) isn't installed.", "signed-out": "gh isn't signed in to GitHub." };
const releaseHelp = (state, website = true) => {
  if (website) console.log("  The website and updates are published. Until the release exists, the Download button uses\n  the website's copy, so downloads aren't counted. To add the release:");
  else console.log("  To create the release:");
  const steps = [...(state === "missing" ? ["winget install GitHub.cli"] : []), ...(state !== "ok" ? ["gh auth login        (GitHub.com → HTTPS → Login with a web browser)"] : []), "npm run publish-release -- --release"];
  steps.forEach((s, i) => console.log(`    ${i + 1}. ${s}`));
};
// Creates the release (or attaches the zip again if it exists) and checks the uploaded asset matches the local zip.
const createRelease = ({ version, title, notes, zipPath, latest }) => {
  const tag = `v${version}`, zipName = path.basename(zipPath), size = fs.statSync(zipPath).size;
  let exists = true;
  try { gh("release", "view", tag, "--repo", REPO, "--json", "tagName"); } catch { exists = false; }
  if (exists) gh("release", "upload", tag, zipPath, "--clobber", "--repo", REPO);
  else gh("release", "create", tag, zipPath, "--repo", REPO, "--target", "main", "--title", `Claude Studio v${short(version)}: ${title}`,
    "--notes", notes.map((n) => `- ${n}`).join("\n"), latest ? "--latest" : "--latest=false");
  const asset = JSON.parse(gh("release", "view", tag, "--repo", REPO, "--json", "assets")).assets.find((a) => a.name === zipName);
  if (!asset || asset.size !== size) throw Object.assign(new Error(`the uploaded ${zipName} doesn't match the local file`), { mismatch: true });
  return { exists };
};

// ---- release only: npm run publish-release -- --release [--version <v>] (FR-289, FR-290) ----
if (flag("release")) {
  const latest = readJson(path.join(SITE_DIR, "latest.json"), null);
  if (!latest) fail(`There's no built release in ${SITE_DIR} (latest.json is missing). Publish one first: npm run publish-release`);
  const version = opt("version") || latest.version;
  const zipName = `claude-studio-${version}.zip`, zipPath = path.join(SITE_DIR, "releases", zipName);
  if (!fs.existsSync(zipPath)) fail(`v${version} isn't in the site folder (releases/${zipName} not found). Nothing changed.`);
  const entry = latest.history.find((h) => h.version === version);
  if (!entry) fail(`v${version} isn't in latest.json's history, so its title and notes are unknown. Nothing changed.`);
  // The zip must be the one that was published: its SHA-256 as recorded in that version's latest.json (FR-290).
  const isLatest = version === latest.version;
  let published = isLatest ? latest.zip.sha256 : null;
  if (!published) {
    for (const c of git(SITE_DIR, "log", "--format=%H", "--", "latest.json").split("\n").filter(Boolean)) {
      try { const j = JSON.parse(git(SITE_DIR, "show", `${c}:latest.json`)); if (j.version === version) { published = j.zip.sha256; break; } } catch {}
    }
  }
  if (published && sha256Of(fs.readFileSync(zipPath)) !== published) fail(`${zipName} doesn't match the published one (sha256 differs). Nothing changed.`);
  const notesFrom = isLatest ? "" : ` Notes from latest.json history (${entry.notes.length} line${entry.notes.length === 1 ? "" : "s"}).`;
  console.log(`Release only for v${short(version)} (already built in ${SITE_DIR}).${notesFrom}`);
  const state = ghState();
  if (state !== "ok") { console.log(`! No GitHub Release: ${NO_RELEASE[state]}`); releaseHelp(state, false); process.exit(1); }
  console.log(`Creating GitHub Release v${short(version)}${isLatest ? "" : " (older version, not marked Latest)"}…`);
  let made;
  try { made = createRelease({ version, title: entry.title, notes: entry.notes, zipPath, latest: isLatest }); }
  catch (e) { fail(`No GitHub Release: ${e.mismatch ? e.message : `gh said "${ghError(e)}"`}.`); }
  const check = published ? `sha256 matches ${isLatest ? "latest.json" : "the published one"}` : "size matches the local zip";
  console.log(made.exists ? `✓ Release v${short(version)} already exists; the zip was attached again.` : `✓ Release v${short(version)} created with ${zipName} (${check}).`);
  if (!isLatest) { console.log(`  The Download button stays on v${short(latest.version)}.`); process.exit(0); }
  renderSite({ siteSrc: SITE_SRC, siteDir: SITE_DIR, latest, counted: true });
  if (!commitSite(`Download link: GitHub Release v${short(version)}`)) { console.log("✓ The Download button already points at the release; the website wasn't pushed."); process.exit(0); }
  console.log("Switching the Download button to the release…");
  pushSite();
  console.log("  Download button → GitHub Release.");
  process.exit(0);
}

// ---- 1. checks (FR-223, AC-134) ----
if (git(ROOT, "status", "--porcelain")) fail("The working tree has uncommitted changes. Commit them first: only committed, deployed code can be published.");
const head = git(ROOT, "rev-parse", "--short", "HEAD");
const live = readJson(path.join(ROOT, ".deploy", "current.json"), null);
if (live?.sha !== head) fail(`LIVE runs ${live?.version || "nothing"}, not HEAD (${head}). Deploy and test HEAD first (npm run deploy), then publish.`);
if (!fs.existsSync(PRIVATE_KEY)) fail(`No release key at ${PRIVATE_KEY}. Make one once with: node scripts/release-key.mjs`);
const current = readJson(path.join(ROOT, "release.json"), { version: "0" });

// ---- 2. version, title and notes ----
// Without a console to answer in (for example Claude Code's "!" shell), everything must come as options.
if (!process.stdin.isTTY && !(opt("version") && opt("title") && (opt("notes") || opt("notes-file"))))
  fail('Nothing can answer questions here. Run it in a terminal, or pass everything:\n  npm run publish-release -- --version 0.17.0 --title "Website and updates" --notes "first line|second line"');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = async (q, d) => (opt(q.key) ?? ((await rl.question(`${q.text}${d ? ` [${d}]` : ""}: `)).trim() || d));
const next = (() => { const [a, b] = String(current.version).split(".").map(Number); return `${a || 0}.${(b || 0) + 1}.0`; })();
const version = await ask({ key: "version", text: `Version (now ${current.version})` }, next);
if (!/^\d+\.\d+\.\d+$/.test(version)) fail("The version must look like 0.17.0.");
if (cmpVersion(version, current.version) <= 0) fail(`v${version} isn't newer than the current v${current.version}.`);
const title = await ask({ key: "title", text: "Title (a few words)" });
if (!title || title.length > 60) fail("Give a title of 1-60 characters.");
let notes = opt("notes") ? opt("notes").split("|") : opt("notes-file") ? fs.readFileSync(opt("notes-file"), "utf8").split(/\r?\n/) : null;
if (!notes) {
  notes = [];
  console.log("Release notes, one line each (up to 10); an empty line ends:");
  for (let i = 0; i < 10; i++) { const l = (await rl.question("  • ")).trim(); if (!l) break; notes.push(l); }
}
rl.close();
notes = notes.map((n) => n.trim()).filter(Boolean).slice(0, 10);
if (!notes.length) fail("Give at least one line of release notes.");
const date = new Date().toISOString().slice(0, 10);
// The counted link is rendered only when gh can create the release (design D-2), so the button is never a dead link.
const state = flag("dry-run") ? "dry-run" : ghState();

// ---- 3. release commit, deployed so this PC runs what it publishes ----
fs.writeFileSync(path.join(ROOT, "release.json"), JSON.stringify({ version, title, date, notes }, null, 2) + "\n");
run("npm", ["version", version, "--no-git-tag-version", "--allow-same-version"]);
git(ROOT, "add", "release.json", "package.json", "package-lock.json");
git(ROOT, "commit", "-m", `Release v${short(version)}: ${title}`);
try { git(ROOT, "tag", `v${version}`); } catch {}
run(process.execPath, [path.join(ROOT, "scripts", "deploy.mjs")]);

// ---- 4. the snapshot zip ----
const out = path.join(SITE_DIR, "releases");
fs.mkdirSync(out, { recursive: true });
const zipName = `claude-studio-${version}.zip`, zipPath = path.join(out, zipName);
git(ROOT, "archive", "--format=zip", `--output=${zipPath}`, "HEAD", "--", ".", ...EXCLUDE.map((e) => `:(exclude)${e}`));
const zip = fs.readFileSync(zipPath);
const sha256 = sha256Of(zip);

// ---- 5. latest.json, signed (the updater keeps using the website's copy: FR-287) ----
const prev = readJson(path.join(SITE_DIR, "latest.json"), null);
const history = [{ version, title, date, notes }, ...(prev?.history || []).filter((h) => h.version !== version)].slice(0, 20);
const latest = { format: "claude-studio-release", version, title, date, notes, zip: { name: zipName, url: `releases/${zipName}`, size: zip.length, sha256 }, history };
const latestText = JSON.stringify(latest, null, 2) + "\n";
const key = crypto.createPrivateKey(fs.readFileSync(PRIVATE_KEY));
fs.writeFileSync(path.join(SITE_DIR, "latest.json"), latestText);
fs.writeFileSync(path.join(SITE_DIR, "latest.json.sig"), crypto.sign(null, Buffer.from(latestText), key).toString("base64") + "\n");

// ---- 6. the website ----
renderSite({ siteSrc: SITE_SRC, siteDir: SITE_DIR, latest, counted: state === "ok" });
// The last few zips stay (installed PCs may still be downloading an older one); older ones go. Release assets stay (FR-294).
const zips = fs.readdirSync(out).filter((f) => /^claude-studio-[\d.]+\.zip$/.test(f)).sort((a, b) => cmpVersion(b.slice(14, -4), a.slice(14, -4)));
for (const old of zips.slice(KEEP_ZIPS)) fs.rmSync(path.join(out, old));

// ---- 7. the public repository: one commit per release, by a neutral author (FR-224) ----
commitSite(`Claude Studio v${short(version)}: ${title}`);
console.log(`\nBuilt v${short(version)} in ${SITE_DIR}: ${zipName} (${(zip.length / 1048576).toFixed(1)} MB, sha256 ${sha256.slice(0, 12)}…), latest.json signed, website rendered.`);
if (flag("dry-run")) { console.log("Dry run: nothing pushed. Push later with: npm run publish-release -- --push"); process.exit(0); }
pushSite();

// ---- 8. the GitHub Release (FR-284 to FR-288): after the push, because the tag needs the commit ----
console.log(`Creating GitHub Release v${short(version)}…`);
let counted = false;
if (state !== "ok") console.log(`! No GitHub Release: ${NO_RELEASE[state]}`);
else {
  try {
    createRelease({ version, title, notes, zipPath, latest: true });
    counted = true;
    console.log(`✓ Release v${short(version)} created with ${zipName} (sha256 matches latest.json).\n  https://github.com/${REPO}/releases/tag/v${version}`);
  } catch (e) {
    console.log(`! No GitHub Release: ${e.mismatch ? e.message : `gh said "${ghError(e)}"`}.`);
    // The pushed page already points at the release: switch it back to the website's copy so it never dead-ends.
    renderSite({ siteSrc: SITE_SRC, siteDir: SITE_DIR, latest, counted: false });
    if (commitSite(`Download link: website copy of v${short(version)}`)) pushSite();
  }
}
if (!counted) releaseHelp(state);
console.log(`\n✓ Published${counted ? "" : " (website only)"}. The site updates in a minute or two: ${SITE_URL}`);
if (counted) console.log("  Download button → GitHub Release (downloads are counted). See the counts: npm run release-stats");
