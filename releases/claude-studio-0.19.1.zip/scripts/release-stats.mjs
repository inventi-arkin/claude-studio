// Prints how often each published version was downloaded, as counted by GitHub (spec release-downloads FR-291,
// design release-downloads §3.5). Reads the public GitHub API without signing in; nothing is stored.
// Usage: npm run release-stats
import { REPO } from "./site-render.mjs";

const fail = (msg) => { console.error(`✗ ${msg}`); process.exit(1); };
let res;
try {
  res = await fetch(`https://api.github.com/repos/${REPO}/releases?per_page=100`, {
    headers: { Accept: "application/vnd.github+json", "User-Agent": "claude-studio-release-stats", "X-GitHub-Api-Version": "2022-11-28" },
    signal: AbortSignal.timeout(15000),
  });
} catch (e) {
  fail(`Couldn't reach api.github.com (${e.cause?.code || e.name || "network error"}). Check the internet connection and try again.`);
}
if ((res.status === 403 || res.status === 429) && res.headers.get("x-ratelimit-remaining") === "0") {
  const reset = new Date(Number(res.headers.get("x-ratelimit-reset")) * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  fail(`GitHub's limit for requests without sign-in was reached (60 an hour). Try again after ${reset}.`);
}
if (res.status === 404) fail(`GitHub doesn't know the repository ${REPO} (404).`);
if (!res.ok) fail(`GitHub answered ${res.status} ${res.statusText}. Try again later.`);

const releases = (await res.json()).filter((r) => !r.draft);
if (!releases.length) {
  console.log("No GitHub Releases yet. Publish one, or add the published versions:\n  npm run publish-release -- --release --version 0.19.0");
  process.exit(0);
}
// Newest first; the zip asset's count (a release without one shows "(no zip)" and 0).
const rows = releases
  .sort((a, b) => new Date(b.published_at || b.created_at) - new Date(a.published_at || a.created_at))
  .map((r) => {
    const zip = r.assets.find((a) => /^claude-studio-[\d.]+\.zip$/.test(a.name));
    return { version: r.tag_name, date: (r.published_at || r.created_at || "").slice(0, 10), file: zip?.name || "(no zip)", count: zip?.download_count || 0 };
  });
const total = rows.reduce((n, r) => n + r.count, 0);
const w = { version: Math.max(7, ...rows.map((r) => r.version.length)), file: Math.max(4, ...rows.map((r) => r.file.length)), count: Math.max(9, String(total).length) };
const line = (v, d, f, c) => `  ${v.padEnd(w.version)}   ${d.padEnd(10)}   ${f.padEnd(w.file)}   ${String(c).padStart(w.count)}`;
console.log(`Claude Studio downloads, counted by GitHub (github.com/${REPO})\n`);
console.log(line("Version", "Released", "File", "Downloads"));
for (const r of rows) console.log(line(r.version, r.date, r.file, r.count));
console.log("  " + "─".repeat(w.version + 10 + w.file + w.count + 9));
console.log(line("Total", "", "", total));
console.log("\nCounts include repeat downloads and bots. Updates installed from inside Studio aren't counted.");
