// Live supervisor: runs the release named in .deploy/current.json on port 4300,
// restarts it when a deploy or rollback changes current.json, and after a crash.
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import net from "node:net";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const DEPLOY = path.join(ROOT, ".deploy");
const CURRENT = path.join(DEPLOY, "current.json");
const PORT = process.env.LIVE_PORT || "4300";

let child = null;
let running = null;
let stopping = false;
let switching = false;

const start = () => {
  let cur;
  try { cur = JSON.parse(fs.readFileSync(CURRENT, "utf8")); }
  catch { console.error("Nothing deployed yet. Run: npm run deploy"); process.exit(1); }
  const dir = path.join(DEPLOY, "releases", cur.sha);
  running = cur.sha;
  console.log(`[live] starting ${cur.version}`);
  child = spawn(process.execPath, ["server.js"], {
    cwd: dir,
    stdio: "inherit",
    env: { ...process.env, PORT, STUDIO_CHANNEL: "live", STUDIO_VERSION: cur.version, STUDIO_DATA: path.join(DEPLOY, "data") },
  });
  child.on("exit", (code) => {
    child = null;
    if (stopping) return;
    if (switching) { switching = false; return start(); }
    console.error(`[live] exited with ${code}; restarting in 2s`);
    setTimeout(start, 2000);
  });
};

const restartIfChanged = () => {
  try {
    const cur = JSON.parse(fs.readFileSync(CURRENT, "utf8"));
    if (cur.sha !== running && child) { console.log(`[live] switching to ${cur.version}`); switching = true; child.kill(); }
  } catch {}
};

fs.watchFile(CURRENT, { interval: 1000 }, restartIfChanged);
for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => { stopping = true; child?.kill(); process.exit(0); });
// --if-free (the Windows sign-in launcher, spec autostart FR-240): if something already answers on the port, a copy of
// Studio is running; leave it alone instead of starting a second one that would fail and restart in a loop.
if (process.argv.includes("--if-free")) {
  const s = net.connect({ port: Number(PORT), host: "127.0.0.1" });
  s.on("connect", () => { s.destroy(); console.log(`[live] port ${PORT} is already in use; not starting`); process.exit(0); });
  s.on("error", () => { s.destroy(); start(); });
} else start();
