// Shared by the Home and chat pages: helpers, look settings (style, theme, accent, size, font, width)
// and the Claude Home setting (spec look-and-feel A and G).
const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const api = (url, opts = {}) => fetch(url, { ...opts, headers: { "Content-Type": "application/json", "X-Studio": "1", ...(opts.headers || {}) } });
const store = {
  get(k, d) { try { const v = localStorage.getItem("studio." + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("studio." + k, JSON.stringify(v)); } catch {} },
};
const greetingWord = (d = new Date()) => {
  const h = d.getHours();
  return h >= 5 && h < 12 ? "Good morning" : h >= 12 && h < 18 ? "Good afternoon" : "Good evening";
};
// Studio's own slash commands, shared by the chat page's / menu and the Ctrl K palette (spec chat-v041 FR-60).
const STUDIO_COMMANDS = [
  { name: "btw", argumentHint: "<question>", description: "Quick side question about this chat. Not saved, uses no tools, works while Claude is busy." },
  { name: "new", aliases: ["clear", "reset"], argumentHint: "", description: "Start a new chat." },
  { name: "model", argumentHint: "<opus|sonnet|haiku|fable|default>", description: "Choose the model for the next messages." },
  { name: "rename", aliases: ["name"], argumentHint: "<title>", description: "Rename this chat." },
  { name: "help", argumentHint: "", description: "Show all commands." },
];
// Matching shared by the chat page's / menu and the Ctrl K palette (spec chat-v041 FR-58, look-and-feel FR-44).
// Items have a key (the text matched, without a leading /), optional aliases, desc and group. Best matches first:
// keys or aliases starting with the query, then keys containing it, then descriptions containing it (3+ characters).
// Within each tier: group order, then the closest key (shorter first: /usage before /usage-credits), then A–Z.
// An empty query keeps the given order within each group.
const rankMatches = (items, query, groupOrder) => {
  const q = query.trim().toLowerCase().replace(/^\//, "");
  const g = (x) => groupOrder.indexOf(x.group);
  if (!q) return [...items].sort((a, b) => g(a) - g(b));
  const key = (x) => x.key.toLowerCase();
  const order = (a, b) => g(a) - g(b) || key(a).length - key(b).length || key(a).localeCompare(key(b));
  const starts = items.filter((x) => key(x).startsWith(q) || x.aliases?.some((a) => a.toLowerCase().startsWith(q)));
  const has = items.filter((x) => !starts.includes(x) && (key(x).includes(q) || (q.length >= 3 && (x.desc || "").toLowerCase().includes(q))));
  return [...starts.sort(order), ...has.sort(order)];
};
// One result row in either list: name (with an argument hint), description, and a group tag when given.
const resultRow = ({ id, name, hint, desc, tag, onPick }) => {
  const o = el("div", "cmd-item");
  o.id = id;
  o.setAttribute("role", "option");
  const n = el("span", "cmd-name", name);
  if (hint) n.append(el("span", "cmd-arg", " " + hint));
  o.append(n, el("span", "cmd-desc", desc || ""));
  if (tag) o.append(el("span", "cmd-tag", tag));
  o.onmousedown = (e) => { e.preventDefault(); onPick(); };
  return o;
};
// Command output is plain text that only looks like Markdown: a backslash before punctuation is part of a Windows
// path (C:\Users\me\.claude), not a Markdown escape, so it is doubled outside code before rendering.
const keepBackslashes = (text) => text.split(/(```[\s\S]*?```|`[^`\n]*`)/)
  .map((part, i) => (i % 2 ? part : part.replace(/\\(?=[!-/:-@[-`{-~])/g, "\\\\"))).join("");
// Shared by the chat page's command blocks and the command console (spec chat-v041 FR-62, FR-64).
// Usage lines ("Current week (all models): 32% used · resets …") get the terminal's bar: █ blocks with
// eighth-blocks for the last part, on a dim track, then the percent and the reset time.
const BAR = 40, EIGHTHS = ["", "▏", "▎", "▍", "▌", "▋", "▊", "▉"];
const usageBar = (pct) => {
  const eighths = Math.round(Math.max(0, Math.min(100, pct)) / 100 * BAR * 8);
  return "█".repeat(Math.floor(eighths / 8)) + EIGHTHS[eighths % 8];
};
const terminalText = (text) => {
  const pre = el("pre");
  for (const line of text.split("\n")) {
    const u = /^(\s*)(.+?):\s+(\d{1,3})% used(?:\s*·\s*(.+))?$/.exec(line);
    if (!u) { pre.append(document.createTextNode(line + "\n")); continue; }
    const pct = Number(u[3]);
    const row = el("span", "usage-row");
    row.append(el("span", "usage-label", u[2]));
    const bar = el("span", "usage-bar");
    bar.setAttribute("role", "img");
    bar.setAttribute("aria-label", `${pct}% used`);
    bar.append(el("span", "usage-fill" + (pct >= 90 ? " high" : pct >= 70 ? " mid" : ""), usageBar(pct)));
    row.append(bar, el("span", "usage-pct", `${pct}% used`));
    if (u[4]) row.append(el("span", "usage-reset", u[4].charAt(0).toUpperCase() + u[4].slice(1)));
    pre.append(row);
  }
  return pre;
};
const ago = (ms) => {
  const s = Math.round((Date.now() - ms) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  if (s < 2 * 86400) return "yesterday";
  return `${Math.round(s / 86400)} days ago`;
};

const FONTS = { system: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif', serif: 'Georgia, "Iowan Old Style", serif', mono: 'ui-monospace, "Cascadia Code", Consolas, monospace' };
const WIDTHS = { narrow: "660px", normal: "780px", wide: "1000px" };
const DEFAULTS = { style: "minimal", theme: "system", accent: null, size: 15, font: "style", width: "normal" };
const luminance = (hex) => {
  const c = hex.replace("#", "").match(/../g).map((x) => parseInt(x, 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
};
const contrast = (a, b) => { const [x, y] = [luminance(a), luminance(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
// Time-based themes: day is 06:00 to 18:00. "time" is light by day and dark at night; "time-reverse" is the opposite.
const isDay = (d = new Date()) => { const h = d.getHours(); return h >= 6 && h < 18; };
const themeFor = (t) => (t === "time" ? (isDay() ? "light" : "dark") : t === "time-reverse" ? (isDay() ? "dark" : "light") : t);
const lookSettings = () => ({ ...DEFAULTS, ...store.get("settings", {}) });
const applyLook = () => {
  const s = lookSettings();
  const root = document.documentElement;
  if (s.style === "minimal") root.removeAttribute("data-style"); else root.dataset.style = s.style;
  const theme = themeFor(s.theme);
  if (theme === "system") root.removeAttribute("data-theme"); else root.dataset.theme = theme;
  for (const p of ["--accent", "--link", "--on-accent", "--focus", "--font"]) root.style.removeProperty(p);
  if (s.accent) {
    // Custom accent: links follow it, and button text is whichever of white or near-black reads better (FR-5).
    root.style.setProperty("--accent", s.accent);
    root.style.setProperty("--focus", s.accent);
    root.style.setProperty("--link", "color-mix(in srgb, var(--accent) 75%, var(--text))");
    root.style.setProperty("--on-accent", contrast(s.accent, "#ffffff") >= contrast(s.accent, "#18181b") ? "#ffffff" : "#18181b");
  }
  if (s.font !== "style") root.style.setProperty("--font", FONTS[s.font] || FONTS.system);
  root.style.setProperty("--font-size", s.size + "px");
  root.style.setProperty("--chat-width", WIDTHS[s.width] || WIDTHS.normal);
  return s;
};
applyLook();
// A time-based theme switches by itself at 06:00 and 18:00 (checked every minute).
setInterval(() => {
  const t = lookSettings().theme;
  if (t.startsWith("time") && document.documentElement.dataset.theme !== themeFor(t)) { applyLook(); dispatchEvent(new Event("studio-theme")); }
}, 60 * 1000);

// ---------- running and waiting chats (spec reliable-chats FR-79 to FR-81) ----------
// One poller per page: every 5 s while the page is visible and a chat is running or waiting (or this page has a
// turn going), and always while notifications are on. Pages listen for "studio-chats" (detail: the chat list).
const activity = { chats: [], running: false, localBusy: false, loaded: false };
const studioView = { chatId: null }; // the chat this page shows (chat page only)
let activityTimer = null;
const notifyOn = () => store.get("notify", false) && "Notification" in window && Notification.permission === "granted";
const pollChats = async () => {
  try { const r = await api("/api/chats"); if (!r.ok) return; activity.chats = await r.json(); } catch { return; }
  activity.running = activity.chats.some((c) => c.running);
  activity.loaded = true;
  dispatchEvent(new CustomEvent("studio-chats", { detail: activity.chats }));
  heartbeat();
  checkNotifications(activity.chats);
};
const schedulePoll = () => {
  clearTimeout(activityTimer);
  const active = activity.localBusy || activity.chats.some((c) => c.running || c.waiting);
  if ((document.visibilityState === "visible" && active) || notifyOn()) activityTimer = setTimeout(kickPoll, 5000);
};
const kickPoll = () => pollChats().then(schedulePoll);
document.addEventListener("visibilitychange", () => { heartbeat(); if (document.visibilityState === "visible") kickPoll(); else schedulePoll(); });

// ---------- browser notifications (spec reliable-chats W) ----------
// Each Studio tab notes which chat it shows and whether it is visible, so a chat on screen never notifies.
const TAB_ID = Math.random().toString(36).slice(2);
const heartbeat = () => {
  const views = Object.fromEntries(Object.entries(store.get("views", {})).filter(([, v]) => Date.now() - v.at < 30000));
  views[TAB_ID] = { chat: studioView.chatId, visible: document.visibilityState === "visible", at: Date.now() };
  store.set("views", views);
};
addEventListener("pagehide", () => { const v = store.get("views", {}); delete v[TAB_ID]; store.set("views", v); });
const onScreen = (chatId) => Object.values(store.get("views", {})).some((v) => v.chat === chatId && v.visible && Date.now() - v.at < 30000);
const END_TEXT = { done: "Done", stopped: "Stopped", error: "Something went wrong", interrupted: "Stopped" };
let lastStates = null, channel = null;
const checkNotifications = (chats) => {
  const now = new Map(chats.map((c) => [c.id, c]));
  if (lastStates && notifyOn()) {
    for (const c of chats) {
      const p = lastStates.get(c.id);
      if (!p) continue;
      if (c.waiting && c.waitingId !== p.waitingId) notify(c, "Needs you", `${c.turnId}:wait:${c.waitingId}`);
      if (c.lastEnd && c.lastEnd.turnId !== p.lastEnd?.turnId) notify(c, [END_TEXT[c.lastEnd.status] || "Done", ...endCounts(c.lastEnd)].join(" · "), `${c.lastEnd.turnId}:end`);
    }
  }
  lastStates = now;
};
// "2 files created", "1 created, 2 changed", then the time taken: counts only, never names (spec away-status FR-191).
const endCounts = (e) => {
  const files = e.files || [], made = files.filter((f) => f.kind === "created").length, changed = files.length - made;
  const out = [];
  if (made && changed) out.push(`${made} created, ${changed} changed`);
  else if (made) out.push(`${made} file${made === 1 ? "" : "s"} created`);
  else if (changed) out.push(`${changed} file${changed === 1 ? "" : "s"} changed`);
  if (e.durationMs != null) { const t = Math.round(e.durationMs / 1000); out.push(t < 60 ? `${t}s` : `${Math.floor(t / 60)}m ${String(t % 60).padStart(2, "0")}s`); }
  return out;
};
// Only the chat title, the kind of event and counts: Windows keeps notifications, so no commands, paths or reply text (FR-92).
const notify = async (c, what, tag) => {
  if (onScreen(c.id)) return;
  const sent = store.get("notified", {});
  if (sent[tag]) return; // another tab got there first
  sent[tag] = Date.now();
  store.set("notified", Object.fromEntries(Object.entries(sent).filter(([, t]) => Date.now() - t < 86400000)));
  if (!channel) { try { channel = (await (await api("/api/info")).json()).channel; } catch { channel = "live"; } }
  const title = c.title.length > 60 ? c.title.slice(0, 59) + "…" : c.title;
  const n = new Notification((channel === "dev" ? "[DEV] " : "") + "Claude Studio", { body: `${title}\n${what}`, tag, icon: "/claude.ico" });
  n.onclick = () => { window.focus(); n.close(); if (location.pathname === "/chat") location.hash = c.id; else location.href = "/chat#" + c.id; };
};

// Settings → Look → Chat: follow the reply (FR-98) and notifications (FR-90). Used on Home and the chat page.
const mountChatSettings = (box) => {
  box.innerHTML = "";
  const row = (label, hint) => {
    const l = el("label", "check");
    const input = el("input"); input.type = "checkbox";
    l.append(input, el("span", null, label), el("p", "hint", hint));
    box.append(l);
    return { l, input };
  };
  const follow = row("Follow Claude's reply", "Keeps the newest line in view while Claude answers. Scroll up to pause.");
  follow.input.checked = store.get("followReply", true);
  follow.input.onchange = () => store.set("followReply", follow.input.checked);
  const note = row("Notify me when a chat finishes or needs me", "Works while a Studio tab is open, even in the background.");
  const extra = el("p", "hint");
  note.l.append(extra);
  const show = () => {
    const supported = "Notification" in window;
    note.input.disabled = !supported;
    note.input.checked = notifyOn();
    extra.className = "hint";
    extra.textContent = "";
    if (!supported) extra.textContent = "Notifications aren't supported in this browser.";
    else if (Notification.permission === "denied") { extra.className = "hint warn"; extra.textContent = "⚠ Notifications are blocked for this site. Allow them in the browser's site settings (🔒 in the address bar)."; }
  };
  note.input.onchange = async () => {
    if (!note.input.checked) { store.set("notify", false); return show(); }
    // Asked only from this click, never on page load (FR-90).
    if (Notification.permission === "default") await Notification.requestPermission();
    store.set("notify", Notification.permission === "granted");
    show();
    kickPoll();
  };
  show();
};

// Settings → Claude Home: shows the folder in use and saves a new one for the next start (FR-34, FR-35).
const mountHomeSetting = async (box) => {
  box.innerHTML = "";
  const info = await (await api("/api/info")).json();
  box.append(el("p", "hint", `Studio is using ${info.home}` + (info.homeSource === "config" ? " (saved setting)." : info.homeSource === "env" ? " (set by STUDIO_HOME)." : " (found automatically).")));
  const label = el("label", "field");
  label.append(el("span", null, "Claude Home folder"));
  const input = el("input");
  input.value = info.savedHome || info.home;
  input.spellcheck = false;
  // Browse… opens the folder browser (spec home-picker FR-130); its choice is saved there and shown here.
  const fieldRow = el("div", "home-field-row");
  const browse = el("button", "btn", "Browse…");
  browse.type = "button";
  fieldRow.append(input, browse);
  label.append(fieldRow);
  const row = el("div", "add-actions");
  const save = el("button", "btn primary", "Save");
  save.type = "button";
  const msg = el("span", "hint");
  msg.setAttribute("role", "status");
  row.append(save, msg);
  const showSaved = (body) => {
    msg.className = "hint";
    msg.textContent = body.restartNeeded ? "Saved. Restart Studio to use the new Home." : "Saved. Studio already uses this Home.";
    row.querySelector(".rs-link")?.remove();
    if (body.restartNeeded && body.canRestart) { const r = el("button", "link-btn rs-link", "Restart now"); r.type = "button"; r.onclick = restartStudio; row.append(r); }
  };
  save.onclick = async () => {
    msg.className = "hint";
    msg.textContent = "Checking…";
    const res = await api("/api/config/home", { method: "PUT", body: JSON.stringify({ path: input.value.trim() }) });
    const body = await res.json().catch(() => ({}));
    // Beside an error, Restart now would read as if the bad path were used (QA v0.9 F-3); Studio keeps any earlier
    // saved folder, which Home's top bar still shows with its own Restart now.
    if (!res.ok) { msg.className = "error-text"; msg.textContent = body.error || "Could not save."; row.querySelector(".rs-link")?.remove(); return; }
    showSaved(body);
    dispatchEvent(new Event("studio-home-saved"));
  };
  browse.onclick = () => openHomePicker({ back: browse, onSaved: (body) => { input.value = body.saved; showSaved(body); } });
  box.append(label, row);
  if (info.savedHome && info.canRestart) showSaved({ restartNeeded: true, canRestart: true });
  if (info.homeSource === "env") box.append(el("p", "hint", "STUDIO_HOME is set, so it wins over a saved folder until it is removed."));
};

// ---------- Choose Claude Home (spec home-picker FR-128 to FR-134, design 3) ----------
// Studio's own folder browser: the server lists folder names (a browser's folder picker never gives the real path).
// onSaved(body) gets the save answer ({ saved, restartNeeded, canRestart }); the dialog shows Restart now itself.
const openHomePicker = async ({ back = document.activeElement, onSaved } = {}) => {
  const info = await (await api("/api/info")).json();
  const dlg = el("dialog", "fp");
  dlg.setAttribute("aria-labelledby", "fpTitle");
  dlg.innerHTML = `<form class="settings" method="dialog">
    <div class="fp-head"><h2 id="fpTitle">Choose Claude Home</h2><button type="button" class="icon-btn fp-x" aria-label="Close" title="Close">✕</button></div>
    <p class="hint">Saved for ${info.channel.toUpperCase()} · used after a restart</p>
    <div class="fp-bar"><button type="button" class="icon-btn fp-up" aria-label="Up one folder" title="Up one folder">↑</button>
      <input class="fp-path" aria-label="Folder path" spellcheck="false" autocomplete="off"><button type="button" class="btn fp-go">Go</button></div>
    <p class="error-text fp-err" role="alert" hidden></p>
    <p class="error-text fp-cant" role="alert" hidden></p>
    <div class="fp-list" role="listbox" tabindex="0"></div>
    <label class="fp-hidden"><input type="checkbox"> Show hidden folders</label>
    <div class="fp-sel"></div>
    <p class="error-text fp-save-err" role="alert" hidden></p>
    <div class="dialog-actions fp-actions"><button type="button" class="btn ghost fp-cancel">Cancel</button><button type="button" class="btn primary fp-use">Use this folder</button></div>
  </form>`;
  document.body.append(dlg);
  const q = (s) => dlg.querySelector(s);
  const field = q(".fp-path"), list = q(".fp-list"), hiddenBox = q(".fp-hidden input");
  const st = { path: null, parent: null, items: [], index: -1 };
  hiddenBox.checked = store.get("showHiddenFolders", false);
  const marks = (f) => [f.claudeHome && "Claude Home", f.inUse && "in use"].filter(Boolean);
  const showSel = () => {
    const f = st.items[st.index];
    const sel = q(".fp-sel");
    sel.innerHTML = "";
    sel.append("Selected: ", el("code", null, field.value || "—"));
    if (f?.claudeHome) { sel.append(" ", el("span", "ok", "✓ Claude Home")); if (f.inUse) sel.append(" · In use"); }
    else if (f || st.path) sel.append(" · Not a Claude Home");
  };
  const select = (i, scroll = true) => {
    st.index = i;
    list.querySelectorAll(".fp-row").forEach((r, k) => r.setAttribute("aria-selected", String(k === i)));
    const row = list.querySelector(`#fp-${i}`);
    if (row) { list.setAttribute("aria-activedescendant", row.id); if (scroll) row.scrollIntoView({ block: "nearest" }); }
    field.value = i >= 0 ? st.items[i].path : st.path || "";
    showSel();
  };
  const render = (data) => {
    list.innerHTML = "";
    q(".fp-up").disabled = data.path == null;
    list.setAttribute("aria-label", data.path ? `Folders in ${data.path}` : "Drives");
    if (data.path == null) list.append(el("div", "fp-cap", "This PC"));
    if (!data.folders.length) list.append(el("div", "fp-empty", "No folders here."));
    data.folders.forEach((f, i) => {
      const r = el("div", "fp-row" + (f.hidden ? " hidden" : ""));
      r.id = "fp-" + i;
      r.setAttribute("role", "option");
      r.setAttribute("aria-label", [f.name, ...marks(f)].join(", "));
      const icon = el("span", null, data.path == null ? "💽" : "📁"); icon.setAttribute("aria-hidden", "true");
      r.append(icon, el("span", "nm", f.name));
      if (f.claudeHome) { const t = el("span", "tag ok"); t.append(el("span", "long", "✓ Claude Home"), el("span", "short", "✓ Home")); r.append(t); }
      if (f.inUse) r.append(el("span", "tag use", "In use"));
      r.onclick = () => { select(i, false); list.focus(); };
      r.ondblclick = () => open(f.path);
      list.append(r);
    });
    if (data.truncated) list.append(el("div", "fp-more", "Showing the first 2,000 folders. Type the path to go further."));
  };
  // Opens a folder (null = the drives); on an error the list keeps the previous folder.
  const open = async (p, selectPath = null) => {
    q(".fp-err").hidden = q(".fp-cant").hidden = true;
    if (!st.items.length) { list.innerHTML = ""; list.append(el("div", "fp-empty", "Loading…")); }
    const r = await api("/api/folders?" + new URLSearchParams({ ...(p ? { path: p } : {}), ...(hiddenBox.checked ? { hidden: "1" } : {}) })).catch(() => null);
    const j = await r?.json().catch(() => ({}));
    if (!r?.ok) {
      if (r?.status === 403) { const c = q(".fp-cant"); c.textContent = `Can't open ${p.split(/[\\/]/).filter(Boolean).pop() || p}.`; c.hidden = false; }
      else { const e = q(".fp-err"); e.textContent = j?.error || "Couldn't reach Studio."; e.hidden = false; }
      return false;
    }
    Object.assign(st, { path: j.path, parent: j.parent, items: j.folders });
    render(j);
    select(selectPath ? j.folders.findIndex((f) => f.path.toLowerCase() === selectPath.toLowerCase()) : -1);
    return true;
  };
  const up = () => { if (st.path != null) open(st.parent, st.path); };
  q(".fp-up").onclick = up;
  q(".fp-go").onclick = () => open(field.value.trim() || null);
  field.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); q(".fp-go").click(); } };
  hiddenBox.onchange = () => { store.set("showHiddenFolders", hiddenBox.checked); open(st.path, field.value); };
  list.onkeydown = (e) => {
    const n = st.items.length;
    if (!n && e.key !== "Backspace") return;
    if (e.key === "ArrowDown") { e.preventDefault(); select(Math.min(n - 1, st.index + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); select(Math.max(0, st.index - 1)); }
    else if (e.key === "Home") { e.preventDefault(); select(0); }
    else if (e.key === "End") { e.preventDefault(); select(n - 1); }
    else if (e.key === "Enter" && st.index >= 0) { e.preventDefault(); open(st.items[st.index].path); }
    else if (e.key === "Backspace") { e.preventDefault(); up(); }
  };
  const close = () => dlg.close();
  q(".fp-x").onclick = q(".fp-cancel").onclick = close;
  dlg.addEventListener("close", () => { dlg.remove(); if (back && document.contains(back)) back.focus(); });
  // Use this folder: the same check and save as Settings (FR-129).
  q(".fp-use").onclick = async () => {
    const use = q(".fp-use"), err = q(".fp-save-err");
    err.hidden = true;
    use.disabled = true; use.textContent = "Saving…";
    const r = await api("/api/config/home", { method: "PUT", body: JSON.stringify({ path: field.value.trim() }) }).catch(() => null);
    const body = await r?.json().catch(() => ({}));
    use.disabled = false; use.textContent = "Use this folder";
    if (!r?.ok) { err.textContent = body?.error || "Couldn't reach Studio."; err.hidden = false; return; }
    onSaved?.(body);
    dispatchEvent(new Event("studio-home-saved"));
    if (!body.restartNeeded) { close(); return; }
    const actions = q(".fp-actions");
    actions.innerHTML = "";
    const saved = el("div", "fp-saved");
    const tick = el("span", "tick", "✓"); tick.setAttribute("aria-hidden", "true");
    const text = el("span");
    if (body.canRestart) {
      text.append("Saved. Restart Studio to use ", el("code", null, body.saved), ".");
      const later = el("button", "btn ghost", "Later"); later.type = "button"; later.onclick = close;
      const now = el("button", "btn primary", "Restart now"); now.type = "button"; now.onclick = () => restartStudio();
      actions.append(later, now);
      now.focus();
    } else {
      text.append("Saved. Restart Studio yourself to use ", el("code", null, body.saved), ": close it and run Start Claude Studio (LIVE) or npm run dev (DEV).");
      const ok = el("button", "btn primary", "Close"); ok.type = "button"; ok.onclick = close;
      actions.append(ok);
      ok.focus();
    }
    saved.setAttribute("role", "status");
    saved.append(tick, text);
    actions.before(saved);
  };
  dlg.showModal();
  // Opens in the parent of the Home in use, with that Home selected (Q-2).
  const first = await api("/api/folders?" + new URLSearchParams({ path: info.home })).then((r) => r.json()).catch(() => null);
  await open(first?.parent ?? null, info.home);
  list.focus();
};

// ---------- Restart now (spec home-picker FR-135 to FR-138, design 4) ----------
const rsBanner = (fail = false) => {
  document.querySelector(".rs-banner")?.remove();
  const b = el("div", "rs-banner" + (fail ? " fail" : ""));
  b.setAttribute("role", "status");
  if (fail) {
    const t = el("span"); t.append(el("b", null, "Studio didn't come back."), " Start it again with Start Claude Studio (LIVE) or npm run dev (DEV).");
    const again = el("button", "btn sm", "Try again"); again.type = "button"; again.onclick = () => waitForRestart(rsBanner.startedAt);
    const warn = el("span", null, "⚠"); warn.setAttribute("aria-hidden", "true");
    b.append(warn, t, again);
  } else {
    const dot = el("span", "pulse"); dot.setAttribute("aria-hidden", "true");
    b.append(dot, "Restarting Studio… The page reloads when it's back.");
  }
  // Inside an open modal dialog the banner must sit in the top layer to be seen.
  (document.querySelector("dialog[open]") || document.body).append(b);
};
// Polls /api/info every second; a new startedAt means the server is back (FR-138).
const waitForRestart = async (before) => {
  rsBanner.startedAt = before;
  rsBanner();
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    const info = await fetch("/api/info").then((r) => (r.ok ? r.json() : null)).catch(() => null);
    if (info && info.startedAt !== before) { location.reload(); return; }
  }
  rsBanner(true);
};
const confirmRestart = (n) => new Promise((resolve) => {
  const dlg = el("dialog", "rs-confirm");
  dlg.setAttribute("aria-labelledby", "rsTitle");
  const form = el("form", "settings np-form"); form.method = "dialog";
  const h = el("h2", null, "Restart Studio?"); h.id = "rsTitle";
  const actions = el("div", "dialog-actions");
  const cancel = el("button", "btn", "Cancel"); cancel.value = "cancel";
  const go = el("button", "btn danger", "Restart anyway"); go.value = "ok";
  actions.append(cancel, go);
  form.append(h, el("p", "hint", `${n} chat${n === 1 ? " is" : "s are"} still working. Restarting stops ${n === 1 ? "it" : "them"}; they'll show as stopped when Studio closed.`), actions);
  dlg.append(form);
  document.body.append(dlg);
  dlg.addEventListener("close", () => { dlg.remove(); resolve(dlg.returnValue === "ok"); });
  dlg.showModal();
  cancel.focus();
});
// Asks first when chats (or a console command) are still working (FR-136), then restarts this channel (FR-137).
const restartStudio = async () => {
  const [chats, cons, info] = await Promise.all([
    api("/api/chats").then((r) => r.json()).catch(() => []),
    api("/api/console").then((r) => r.json()).catch(() => ({})),
    api("/api/info").then((r) => r.json()).catch(() => ({})),
  ]);
  const working = chats.filter((c) => c.running || c.waiting).length + (cons.running ? 1 : 0);
  if (working && !await confirmRestart(working)) return;
  const r = await api("/api/restart", { method: "POST" }).catch(() => null);
  if (r?.status !== 202) { alert((await r?.json().catch(() => ({})))?.error || "Couldn't restart Studio."); return; }
  waitForRestart(info.startedAt);
};

// Settings → Permissions (spec permissions FR-116 to FR-119, design 5): Home's local rules, editable, and the
// read-only user and shared rules. Used by the chat page's tab and Home's Permissions dialog.
const PERM_LISTS = [["allow", "Allowed"], ["ask", "Ask first"], ["deny", "Blocked"]];
const SAFE_READ_ONLY = ["Bash(ls *)", "Bash(pwd)", "Bash(git status *)", "Bash(git log *)", "Bash(git diff *)", "Bash(git show *)", "Bash(git branch *)",
  "Bash(grep *)", "Bash(rg *)", "Bash(wc *)", "Bash(head *)", "Bash(tail *)", "Bash(node --check *)", "PowerShell(Get-ChildItem *)", "PowerShell(Get-Content *)"];
// Why a rule can't be saved, in words (spec trust-levels FR-260); the server says the same. "" when the rule is fine.
const RULE_HELP = "Use Tool or Tool(…), one line, up to 1000 characters.";
const ruleProblem = (rule) => {
  if (!rule) return "The rule is empty.";
  if (rule.length > 1000) return `More than 1000 characters (${rule.length.toLocaleString("en-US")}).`;
  if (/[\r\n]/.test(rule)) return "More than one line.";
  if (!/^[A-Za-z][\w-]*(\(.*\))?$/.test(rule)) return "Doesn't look like Tool or Tool(…).";
  return "";
};
// An error line with the cause first and the general hint under it, announced as an alert (FR-260).
const setRuleError = (box, problem, hint = RULE_HELP) => {
  box.textContent = "";
  if (!problem) { box.removeAttribute("role"); return; }
  box.setAttribute("role", "alert");
  box.append(problem, el("span", "second", hint));
};
// A character counter under a rule field (FR-261): shown from 800 characters, "over by N" and a hint past 1000.
const ruleCounter = (input) => {
  const wrap = el("div"), count = el("div", "field-count"), hint = el("p", "hint", "Rules are for a kind of command, like ");
  hint.append(el("code", null, "Bash(npm test *)"), ". Replace the long command with its first words and ", el("code", null, " *"), ".");
  const update = () => {
    const n = input.value.trim().length, over = n > 1000;
    count.hidden = n < 800;
    count.classList.toggle("over", over);
    count.textContent = over ? `${n.toLocaleString("en-US")} / 1000 · over by ${(n - 1000).toLocaleString("en-US")}` : `${n} / 1000`;
    hint.hidden = !over;
  };
  input.addEventListener("input", update);
  update();
  wrap.append(count, hint);
  return wrap;
};
const permApi = async (body) => {
  const r = await api("/api/permissions", body ? { method: "POST", body: JSON.stringify(body) } : {});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `Request failed (${r.status})`);
  return j;
};
// A confirmation list (Clean up, safe preset): every item ticked unless disabled; the button counts the ticks.
// An item may carry a label, a path to show instead of the rule, a tag and a note (the bookkeeping list, trust-levels FR-263);
// unit: null counts without a noun ("Add 2") and offers Close when nothing is left to add.
const confirmRules = ({ title, text, items, verb, two = false, unit = "rule" }) => new Promise((resolve) => {
  const dlg = el("dialog", "perm-dialog");
  dlg.setAttribute("aria-labelledby", "permDlgTitle");
  const form = el("form", "settings");
  form.method = "dialog";
  const h = el("h2", null, title); h.id = "permDlgTitle";
  const list = el("ul", "perm-checks" + (two ? " two" : ""));
  const boxes = items.map((it) => {
    const li = el("li"), l = el("label"), c = el("input");
    c.type = "checkbox"; c.checked = true; c.disabled = !!it.disabled;
    const code = el("code", null, it.shown || it.rule); code.title = it.shown || it.rule;
    l.append(c);
    if (it.label) { l.classList.add("labelled"); l.append(el("span", "item-label", it.label), code); } else l.append(code);
    if (it.tag) l.append(el("span", "tag", it.tag));
    if (it.note) l.append(el("span", it.disabled ? "tag ok" : "already", it.note));
    li.append(l); list.append(li);
    return { c, it };
  });
  const actions = el("div", "dlg-actions");
  const cancel = el("button", "btn ghost", "Cancel"); cancel.type = "button";
  const go = el("button", "btn primary"); go.type = "submit";
  const count = () => {
    const n = boxes.filter((b) => b.c.checked && !b.c.disabled).length;
    go.textContent = unit == null ? (n ? `${verb} ${n}` : "Close") : `${verb} ${n} ${unit}${n === 1 ? "" : "s"}`;
    go.disabled = unit == null ? false : !n;
  };
  boxes.forEach((b) => (b.c.onchange = count));
  count();
  actions.append(cancel, go);
  form.append(h, el("p", "hint", text), list, actions);
  dlg.append(form);
  document.body.append(dlg);
  let picked = null;
  cancel.onclick = () => dlg.close();
  form.onsubmit = () => { picked = boxes.filter((b) => b.c.checked && !b.c.disabled).map((b) => b.it.rule); };
  dlg.addEventListener("close", () => { dlg.remove(); resolve(picked); });
  dlg.showModal();
  list.querySelector("input:not(:disabled)")?.focus();
});
// Which rules the tab shows (spec project-rules FR-202): Home, or one project. Remembered for the browser session;
// otherwise the chat page's project, or Home.
const permScope = () => {
  try { const s = sessionStorage.getItem("studio.permScope"); if (s != null) return s || null; } catch {}
  const p = typeof state !== "undefined" ? state.chat?.project || $("project")?.value : null;
  return p && p !== "General" ? p : null;
};
const mountPermissions = async (box, scope = permScope()) => {
  box.innerHTML = "";
  box.append(el("p", "hint", "Loading rules…"));
  let data, undo = null, undoTimer = null, counts = {}, homeData = null;
  const q = scope ? "?project=" + encodeURIComponent(scope) : "";
  const load = async (body) => {
    const r = await api("/api/permissions" + q, body ? { method: "POST", body: JSON.stringify(scope ? { ...body, project: scope } : body) } : {});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || `Request failed (${r.status})`);
    return j;
  };
  try {
    [data, counts] = await Promise.all([load(), api("/api/permissions/projects").then((r) => r.json()).catch(() => ({}))]);
    if (scope) homeData = await permApi().catch(() => null);
  } catch (e) {
    box.innerHTML = "";
    const retry = el("button", "btn", "Retry"); retry.type = "button";
    retry.onclick = () => mountPermissions(box, scope);
    box.append(el("p", "field-error", e.message), retry);
    return;
  }
  const status = el("p", "field-error");
  status.setAttribute("role", "status");
  const apply = async (body, after) => {
    status.textContent = "";
    try {
      const out = await load(body);
      data = { ...data, ...out };
      after?.(); render();
      if (scope) {
        counts[scope] = data.local.allow.length;
        dispatchEvent(new Event("studio-rules"));
        if (out.gitExcluded) status.textContent = "Saved. Kept out of git (added to .git\\info\\exclude).";
      }
      return true;
    }
    catch (e) { status.textContent = e.message; return false; }
  };
  // The "Rules for" choice: Home first, then each project with its rule count.
  const scopeRow = () => {
    const f = el("label", "field perm-scope");
    const s = el("select");
    s.setAttribute("aria-label", "Rules for");
    s.append(new Option("Home (all chats)", ""));
    for (const [name, n] of Object.entries(counts)) s.append(new Option(n ? `${name} · ${n} rule${n === 1 ? "" : "s"}` : n === null ? `${name} · can't read` : name, name));
    s.value = scope || "";
    s.onchange = () => {
      try { sessionStorage.setItem("studio.permScope", s.value); } catch {}
      mountPermissions(box, s.value || null).then(() => box.querySelector(".perm-scope select")?.focus());
    };
    f.append(el("span", null, "Rules for"), s);
    return f;
  };
  const row = (list, rule) => {
    const li = el("li", "perm-row");
    const code = el("code", null, rule); code.title = rule;
    li.append(code);
    if (list === "allow" && data.oneOff.includes(rule)) li.append(el("span", "tag", "one-off"));
    else if (list === "allow" && data.covered?.[rule]) { const t = el("span", "tag", "covered"); t.title = "Also allowed by " + data.covered[rule]; li.append(t); }
    const rm = el("button", "btn ghost sm", "Remove"); rm.type = "button";
    rm.setAttribute("aria-label", "Remove rule " + rule);
    rm.onclick = () => { const index = data.local[list].indexOf(rule); apply({ remove: [{ list, rule }] }, () => {
      clearTimeout(undoTimer);
      undo = { list, rule, index };
      undoTimer = setTimeout(() => { undo = null; render(); }, 8000);
    }); };
    li.append(rm);
    return li;
  };
  const render = () => {
    const focusUndo = !!undo;
    box.innerHTML = "";
    box.append(scopeRow());
    if (scope) return renderProject(focusUndo);
    const note = el("p", "hint");
    note.append("Rules in ", el("code", null, data.path), ". They also apply to the Claude Code terminal in Home, and to both DEV and LIVE.");
    const actions = el("div", "perm-actions");
    const preset = el("button", "btn", "Allow safe read-only commands"); preset.type = "button";
    preset.onclick = async () => {
      const picked = await confirmRules({ title: "Allow safe read-only commands", text: "These only read files or show state. Untick any you want to keep asking about.", verb: "Add", two: true,
        items: SAFE_READ_ONLY.map((rule) => ({ rule, disabled: data.local.allow.includes(rule), note: data.local.allow.includes(rule) ? "already allowed" : "" })) });
      if (picked?.length) apply({ add: picked.map((rule) => ({ list: "allow", rule })) });
    };
    // One-off rules, then exact rules a broader rule already covers (QA v0.8 F-1).
    const tidy = [...data.oneOff.map((rule) => ({ rule })), ...Object.entries(data.covered || {}).filter(([rule]) => !data.oneOff.includes(rule))
      .map(([rule, by]) => ({ rule, note: "covered by " + by }))];
    const n = tidy.length;
    const clean = el("button", "btn", n ? `Clean up… (${n})` : "Nothing to clean up"); clean.type = "button";
    clean.disabled = !n;
    clean.onclick = async () => {
      const picked = await confirmRules({ title: "Clean up one-off rules", verb: "Remove",
        text: `These ${n} rules never apply again: each matches one exact command, or a broader rule already allows it. A backup is kept before removing.`, items: tidy });
      if (picked?.length) apply({ remove: picked.map((rule) => ({ list: "allow", rule })) });
    };
    // Bookkeeping files (spec trust-levels FR-262, FR-263): logs and memory updates without a card, at every trust level.
    const bk = el("button", "btn", "Allow bookkeeping files"); bk.type = "button";
    const bkItems = async () => { const r = await api("/api/permissions/bookkeeping"); return r.ok ? (await r.json()).items : null; };
    const bkAllowed = (i) => i.allowed && !i.asked;
    bkItems().then((items) => { if (items?.every(bkAllowed)) bk.textContent = "Bookkeeping files allowed ✓"; }).catch(() => {});
    bk.onclick = async () => {
      status.className = "field-error";
      const items = await bkItems().catch(() => null);
      if (!items) { status.textContent = "Couldn't read the bookkeeping list."; return; }
      const picked = await confirmRules({ title: "Allow bookkeeping files", text: "Claude can change these without asking. Untick any you want to keep asking about.", verb: "Add", unit: null,
        items: items.map((i) => ({ rule: i.id, label: i.label, shown: i.shown, tag: "Edit + Write",
          disabled: bkAllowed(i), note: bkAllowed(i) ? "already allowed" : i.asked ? "replaces an Ask first rule" : "" })) });
      if (!picked?.length) return;
      const r = await api("/api/permissions/bookkeeping", { method: "POST", body: JSON.stringify({ ids: picked }) }).catch(() => null);
      const j = await r?.json().catch(() => ({}));
      if (!r?.ok) { status.textContent = j?.error || "Couldn't save the rules."; return; }
      if (await apply({ add: [], remove: [] })) { status.className = "hint"; status.textContent = `${picked.length} rule${picked.length === 1 ? "" : "s"} added`; }
    };
    actions.append(preset, bk, clean);
    box.append(note, el("p", "hint", "Logs and memory updates run without asking, at every trust level."), actions, status);
    for (const [key, label] of PERM_LISTS) {
      const wrap = el("div");
      wrap.append(el("div", "perm-head", `${label} · ${data.local[key].length}`));
      const ul = el("ul", "perm-list");
      ul.setAttribute("aria-label", label);
      data.local[key].forEach((rule) => ul.append(row(key, rule)));
      if (undo?.list === key) {
        const li = el("li", "perm-row removed");
        li.setAttribute("role", "status");
        const u = el("button", "link", "Undo"); u.type = "button";
        u.onclick = () => { const back = undo; clearTimeout(undoTimer); undo = null; apply({ add: [{ list: back.list, rule: back.rule }] }); };
        li.append("Removed · ", u);
        ul.insertBefore(li, ul.children[undo.index] || null);
      }
      if (!ul.children.length) ul.append(el("li", "perm-row none", "None"));
      wrap.append(ul);
      box.append(wrap);
    }
    // Add a rule
    const add = el("div");
    add.append(el("div", "perm-head", "Add a rule"));
    const form = el("div", "perm-add");
    const ruleField = el("label", "field"); const ruleInput = el("input"); ruleInput.spellcheck = false; ruleInput.placeholder = "Bash(npm test *)";
    ruleField.append(el("span", null, "Rule"), ruleInput);
    const listField = el("label", "field"); const sel = el("select");
    for (const [key, label] of PERM_LISTS) sel.append(new Option(label, key));
    listField.append(el("span", null, "List"), sel);
    const addBtn = el("button", "btn primary", "Add"); addBtn.type = "button";
    const addErr = el("div", "field-error");
    addBtn.onclick = () => {
      const rule = ruleInput.value.trim();
      setRuleError(addErr, "");
      ruleInput.removeAttribute("aria-invalid");
      const problem = ruleProblem(rule);
      if (problem) { setRuleError(addErr, problem); ruleInput.setAttribute("aria-invalid", "true"); return ruleInput.focus(); }
      if (data.local[sel.value].includes(rule)) { addErr.textContent = `Already in ${sel.selectedOptions[0].text}.`; return ruleInput.focus(); }
      apply({ add: [{ list: sel.value, rule }] });
    };
    ruleInput.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); addBtn.click(); } };
    form.append(ruleField, listField, addBtn);
    add.append(form, ruleCounter(ruleInput), addErr);
    box.append(add);
    // Read-only rules from the other settings files.
    const ro = el("div");
    ro.append(el("div", "perm-head", "Also applies (read-only here)"));
    const ul = el("ul", "perm-list");
    for (const f of data.readOnly) {
      const rules = PERM_LISTS.flatMap(([key, label]) => f[key].map((r) => [label, r]));
      if (!rules.length || f.error) { const li = el("li", "perm-row none"); li.append(`${f.label} · `, el("code", null, f.file), ` · ${f.error || "No rules"}`); ul.append(li); continue; }
      for (const [label, r] of rules) { const li = el("li", "perm-row"); const c = el("code", null, r); c.title = `${r} (${f.label}, ${label})`; li.append(c, el("span", "tag", `${f.label} · ${label}`)); ul.append(li); }
    }
    ro.append(ul);
    box.append(ro);
    if (focusUndo) box.querySelector(".perm-row.removed .link")?.focus();
  };
  // A project's own rules (spec project-rules FR-202): an Allowed list only, used in that project's chats.
  const renderProject = (focusUndo) => {
    const note = el("p", "hint");
    note.append("Rules in ", el("code", null, data.path), `. Used only in ${scope} chats, on DEV and LIVE, and in a Claude Code terminal opened in that folder.`);
    box.append(note);
    if (data.error) { // never overwritten while it can't be read (AC-123)
      const retry = el("button", "btn", "Retry"); retry.type = "button";
      retry.onclick = () => mountPermissions(box, scope);
      box.append(el("p", "field-error", data.error + " Studio won't change it until it's valid JSON."), retry);
      return;
    }
    const actions = el("div", "perm-actions");
    const preset = el("button", "btn", "Allow safe read-only commands"); preset.type = "button";
    preset.onclick = async () => {
      const picked = await confirmRules({ title: `Allow safe read-only commands in ${scope}`, text: "These only read files or show state. Untick any you want to keep asking about.", verb: "Add", two: true,
        items: SAFE_READ_ONLY.map((rule) => ({ rule, disabled: data.local.allow.includes(rule), note: data.local.allow.includes(rule) ? "already allowed" : "" })) });
      if (picked?.length) apply({ add: picked.map((rule) => ({ list: "allow", rule })) });
    };
    const tidy = [...data.oneOff.map((rule) => ({ rule })), ...Object.entries(data.covered || {}).filter(([rule]) => !data.oneOff.includes(rule)).map(([rule, by]) => ({ rule, note: "covered by " + by }))];
    const clean = el("button", "btn", tidy.length ? `Clean up… (${tidy.length})` : "Nothing to clean up"); clean.type = "button";
    clean.disabled = !tidy.length;
    clean.onclick = async () => {
      const picked = await confirmRules({ title: "Clean up one-off rules", verb: "Remove", text: `These ${tidy.length} rules never apply again. A backup is kept before removing.`, items: tidy });
      if (picked?.length) apply({ remove: picked.map((rule) => ({ list: "allow", rule })) });
    };
    actions.append(preset, clean);
    box.append(actions, status);
    const wrap = el("div");
    wrap.append(el("div", "perm-head", `Allowed in ${scope} · ${data.local.allow.length}`));
    const ul = el("ul", "perm-list");
    ul.setAttribute("aria-label", `Allowed in ${scope}`);
    data.local.allow.forEach((rule) => ul.append(row("allow", rule)));
    if (undo) {
      const li = el("li", "perm-row removed");
      li.setAttribute("role", "status");
      const u = el("button", "link", "Undo"); u.type = "button";
      u.onclick = () => { const back = undo; clearTimeout(undoTimer); undo = null; apply({ add: [{ list: "allow", rule: back.rule }] }); };
      li.append("Removed · ", u);
      ul.insertBefore(li, ul.children[undo.index] || null);
    }
    if (!ul.children.length) ul.append(el("li", "perm-row none", `No rules for ${scope} yet. Add one, or press Always allow… on a card in a ${scope} chat and pick This project.`));
    wrap.append(ul);
    box.append(wrap);
    const add = el("div");
    add.append(el("div", "perm-head", "Add a rule"));
    const form = el("div", "perm-add");
    const ruleField = el("label", "field"); const ruleInput = el("input"); ruleInput.spellcheck = false; ruleInput.placeholder = "Bash(npm test *)";
    ruleField.append(el("span", null, "Rule"), ruleInput);
    const addBtn = el("button", "btn primary", "Add"); addBtn.type = "button";
    const addErr = el("div", "field-error");
    addBtn.onclick = () => {
      const rule = ruleInput.value.trim();
      setRuleError(addErr, "");
      ruleInput.removeAttribute("aria-invalid");
      const problem = ruleProblem(rule);
      if (problem) { setRuleError(addErr, problem); ruleInput.setAttribute("aria-invalid", "true"); return ruleInput.focus(); }
      if (data.local.allow.includes(rule)) { addErr.textContent = `Already allowed in ${scope}.`; return ruleInput.focus(); }
      apply({ add: [{ list: "allow", rule }] });
    };
    ruleInput.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); addBtn.click(); } };
    form.append(ruleField, addBtn);
    add.append(form, ruleCounter(ruleInput), addErr);
    box.append(add);
    const also = el("p", "hint perm-also");
    const h = homeData?.local;
    also.append(h ? `Also applies: Home's rules (${h.allow.length} allowed, ${h.ask.length} ask first, ${h.deny.length} blocked). Home's Blocked rules win. ` : "Also applies: Home's rules. ");
    const show = el("button", "link-btn", "Show Home"); show.type = "button";
    show.onclick = () => { try { sessionStorage.setItem("studio.permScope", ""); } catch {} mountPermissions(box, null).then(() => box.querySelector(".perm-scope select")?.focus()); };
    also.append(show);
    box.append(also);
    if (focusUndo) box.querySelector(".perm-row.removed .link")?.focus();
  };
  render();
};

// ---------- Companions and places (spec custom-world FR-139 to FR-154, worlds-v2 FR-206 to FR-210) ----------
// The drawing (worldThumb, mountWorldStage) lives in world.js, loaded on both pages; names and lines are always text.
const cwConfirm = ({ title, lines, keep, go }) => new Promise((resolve) => {
  const dlg = el("dialog", "rs-confirm");
  dlg.setAttribute("aria-labelledby", "cwcTitle");
  const form = el("form", "settings np-form"); form.method = "dialog";
  const h = el("h2", null, title); h.id = "cwcTitle";
  const actions = el("div", "dialog-actions");
  const no = el("button", "btn", keep); no.value = "cancel";
  const yes = el("button", "btn danger", go); yes.value = "ok";
  actions.append(no, yes);
  form.append(h, ...lines.map((t) => el("p", "hint", t)), actions);
  dlg.append(form);
  document.body.append(dlg);
  dlg.addEventListener("close", () => { dlg.remove(); resolve(dlg.returnValue === "ok"); });
  dlg.showModal();
  no.focus();
});
const cwDate = (t) => new Date(t).toLocaleDateString(undefined, { day: "numeric", month: "short" });
const cwCost = (usd) => `≈ $${usd < 0.01 ? usd.toFixed(3) : usd.toFixed(2)}`;
const cwDescribe = (d) => [d?.creature, d?.environment].filter(Boolean).join(" · ");
// A small menu (Rename, Export, Delete) in the top layer so no list or dialog clips it; keys like the chat menu.
const cwMenu = (button, items) => {
  document.querySelector(".cw-pop")?.remove();
  const host = button.closest("dialog[open]") || document.body;
  const ul = el("ul", "cw-pop chat-menu");
  ul.setAttribute("role", "menu");
  const close = (focus = true) => { ul.remove(); removeEventListener("pointerdown", outside, true); if (focus) button.focus(); };
  const outside = (e) => { if (!ul.contains(e.target) && e.target !== button) close(false); };
  items.forEach(([label, fn, cls, disabled]) => {
    const li = el("li", cls || null, label);
    li.setAttribute("role", "menuitem"); li.tabIndex = -1;
    if (disabled) { li.setAttribute("aria-disabled", "true"); li.title = disabled; }
    li.onclick = () => { if (disabled) return; close(false); fn(); };
    li.onkeydown = (e) => {
      const all = [...ul.children], i = all.indexOf(li);
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); all[(i + (e.key === "ArrowDown" ? 1 : all.length - 1)) % all.length].focus(); }
      else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); li.click(); }
      else if (e.key === "Escape" || e.key === "Tab") { e.preventDefault(); e.stopPropagation(); close(); }
    };
    ul.append(li);
  });
  host.append(ul);
  const r = button.getBoundingClientRect(); // position: fixed, in window coordinates
  ul.style.left = `${Math.max(8, r.right - ul.offsetWidth)}px`;
  ul.style.top = `${Math.min(innerHeight - ul.offsetHeight - 8, r.bottom + 4)}px`;
  addEventListener("pointerdown", outside, true);
  ul.firstChild.focus();
};

// The 🐾 dialog's companion and place sections (spec worlds-v2 FR-206 to FR-210, design worlds-v2 §2): a live preview of
// the pair in use, then one library per kind. Each kind is used, renamed, exported and deleted on its own.
const CW_KINDS = {
  companion: { list: "companions", active: "activeCompanion", title: "Companion", one: "companion", many: "companions", builtin: "Claude", builtinMeta: "built-in" },
  place: { list: "places", active: "activePlace", title: "Place", one: "place", many: "places", builtin: "Meadow", builtinMeta: "built-in" },
};
const cwActive = (lib, kind) => lib[CW_KINDS[kind].list].find((x) => x.id === lib[CW_KINDS[kind].active]) || null;
const cwPair = (lib) => ({ companion: lib.activeCompanion === CLASSIC_ID ? CLASSIC_COMPANION : cwActive(lib, "companion")?.world || null, place: cwActive(lib, "place")?.world || null });
// The built-in Claude (classic) row (worlds-v2 FR-219): usable, nothing else.
// (world.js loads after this file, so CLASSIC_ID is read when the dialog is built.)
const classicRow = () => ({ id: CLASSIC_ID, name: "Claude (classic)", builtin: true });
let cwPairStop = null;
const mountWorlds = async (box) => {
  let lib;
  try { lib = await (await api("/api/worlds")).json(); }
  catch {
    box.innerHTML = "";
    const p = el("p", "hint", "Couldn't load your companions and places. ");
    const again = el("button", "link-btn", "Retry"); again.type = "button"; again.onclick = () => mountWorlds(box);
    p.append(again); box.append(p);
    return;
  }
  cwPairStop?.(); cwPairStop = null;
  box.innerHTML = "";
  const pair = cwPair(lib);
  dispatchEvent(new CustomEvent("studio-world", { detail: pair })); // the page shows what the library says
  const status = el("p", "hint cw-status"); status.setAttribute("role", "status");
  const err = el("p", "error-text"); err.setAttribute("role", "alert"); err.hidden = true;
  // One timer per panel, so a newer message is never cleared by an older one's timer (QA F-1).
  const note = (t) => { const s = box.querySelector(".cw-status"); if (s) s.textContent = t; clearTimeout(box.cwNoteT); box.cwNoteT = setTimeout(() => { const n = box.querySelector(".cw-status"); if (n) n.textContent = ""; }, 3000); };
  const fail = (t) => { err.textContent = t; err.hidden = false; };
  const refresh = (msg, fresh) => mountWorlds(box).then(() => { if (msg) note(msg);
    if (fresh) for (const id of [].concat(fresh)) box.querySelector(`[data-id="${id}"]`)?.classList.add("fresh"); });

  // The pair in use, drawn live (FR-207).
  const stage = el("div", "cw-stage wv-pair");
  const cName = lib.activeCompanion === CLASSIC_ID ? "Claude (classic)" : pair.companion?.name || "Claude", pName = cwActive(lib, "place")?.name || "Meadow";
  stage.setAttribute("role", "img");
  stage.setAttribute("aria-label", `In use: ${cName} in ${pName}`);
  const caption = el("span", "wv-caption", `${cName} × ${pName}`);
  stage.append(caption);
  box.append(stage);
  requestAnimationFrame(() => { if (stage.isConnected) cwPairStop = mountWorldStage(stage, pairOf(pair.companion, pair.place), effectiveTheme()); });
  // One-time hint after the split (FR-208).
  if (lib.splitNotice) {
    const hint = el("p", "hint wv-split", "Your worlds were split into companions and places, so you can now mix them. ");
    const ok = el("button", "link-btn", "Dismiss"); ok.type = "button";
    ok.onclick = async () => { await api("/api/worlds/notice", { method: "PUT", body: "{}" }).catch(() => null); store.set("splitSeen", 1); hint.remove(); };
    hint.append(ok);
    box.append(hint);
  }
  box.append(err, status);
  // A generation still going in the background: say so here, with Stop (user decision 2026-10-16).
  api("/api/worlds/job").then((r) => r.json()).then((j) => {
    if (!j.running || !box.isConnected) return;
    const mins = Math.max(1, Math.round((Date.now() - j.running.startedAt) / 60000));
    const p = el("p", "hint wv-job", `Creating ${j.running.redrawId ? "a new drawing of a companion" : `a ${j.running.kind}`} in the background (${mins} min so far). Studio lets you know when it's ready. `);
    const stop = el("button", "link-btn", "Stop"); stop.type = "button";
    stop.onclick = async () => { await api("/api/worlds/job/stop", { method: "POST", body: "{}" }).catch(() => {}); p.remove(); };
    p.append(stop); status.before(p);
  }).catch(() => {});

  const importFile = async (f) => {
    err.hidden = true;
    if (f.size > 64 * 1024) return fail("That file is too big (max 64 KB).");
    note("Importing…");
    let json;
    try { json = JSON.parse(await f.text()); } catch { status.textContent = ""; return fail("That file isn't a Claude Studio companion, place or world."); }
    const r = await api("/api/worlds/import", { method: "POST", body: JSON.stringify({ file: json }) }).catch(() => null);
    const j = await r?.json().catch(() => ({}));
    if (!r?.ok) { status.textContent = ""; return fail(j?.error || "Couldn't reach Studio."); }
    const added = j.added || [];
    refresh(added.length > 1 ? `Added ${added.map((a) => `${a.name} to ${CW_KINDS[a.kind].many}`).join(" and ")}.` : `Imported ${added[0]?.name}.`, added.map((a) => a.id));
  };

  const section = (kind) => {
    const K = CW_KINDS[kind], items = lib[K.list], activeId = lib[K.active], full = items.length >= 12;
    const head = el("h4", "wv-head", K.title);
    const actions = el("div", "cw-actions");
    const create = el("button", "btn", `✦ Create ${K.one}…`); create.type = "button"; create.disabled = full;
    create.onclick = () => openCreateWorld({ kind, other: kind === "companion" ? pair.place : pair.companion, back: create,
      onSaved: (id, name, used) => refresh(used ? `Now using ${name}.` : `Saved ${name} to ${K.many}.`, id) });
    const imp = el("button", "btn", "Import…"); imp.type = "button"; imp.disabled = full;
    const file = el("input"); file.type = "file"; file.accept = ".json,application/json"; file.hidden = true;
    imp.onclick = () => file.click();
    file.onchange = () => { const f = file.files[0]; file.value = ""; if (f) importFile(f); };
    actions.append(create, imp, file);
    const use = async (w) => {
      const r = await api("/api/worlds/active", { method: "PUT", body: JSON.stringify({ kind, id: w?.id ?? null }) }).catch(() => null);
      if (!r?.ok) return fail(`Couldn't switch ${K.many}.`);
      refresh(`Now using ${w ? w.name : K.builtin}.`);
    };
    const list = el("ul", "cw-list");
    list.setAttribute("aria-label", K.title === "Companion" ? "Companions" : "Places");
    const row = (w) => {
      const li = el("li", "cw-row");
      if (w) li.dataset.id = w.id;
      // Companions: a 48 px tile, so a 24 px sprite shows at 2× (design creatures-v2 §5).
      li.append(kind === "companion" ? worldThumb(w?.builtin ? { classic: true } : { creature: w?.world.creature || null }, 48, { tile: true }) : worldThumb({ scene: w?.world.scene || null }, 40));
      const nm = el("div", "nm");
      const name = el("b", null, w ? w.name : K.builtin);
      const v1 = kind === "companion" && w && !w.builtin && w.world.creature.version !== 2;
      nm.append(name);
      if (v1) nm.append(el("span", "tag old", "classic style"));
      nm.append(el("span", "meta", w?.builtin ? "built-in · the v0.15 look" : w ? `${cwDate(w.createdAt)} · ${w.description?.imported ? "imported" : cwCost(w.costUsd || 0)}` : K.builtinMeta));
      li.append(nm);
      if (w ? activeId === w.id : !activeId) li.append(el("span", "tag use", "In use"));
      else { const b = el("button", "btn sm", "Use"); b.type = "button"; b.setAttribute("aria-label", `Use ${w ? w.name : K.builtin}`); b.onclick = () => use(w); li.append(b); }
      if (!w || w.builtin) { li.append(el("span", "cw-menu-space")); return li; }
      const more = el("button", "icon-btn", "⋯"); more.type = "button";
      more.setAttribute("aria-label", `More for ${w.name}`); more.setAttribute("aria-haspopup", "menu");
      const rename = () => {
        const input = el("input", "cw-rename"); input.value = w.name; input.maxLength = 40; input.setAttribute("aria-label", "Name");
        name.replaceWith(input); input.select(); input.focus();
        let done = false;
        const finish = async (save) => {
          if (done) return; done = true;
          const v = input.value.trim();
          if (!save || v === w.name) return refresh();
          if (!v) { done = false; fail("Enter a name."); input.focus(); return; }
          const r = await api(`/api/worlds/${w.id}`, { method: "PATCH", body: JSON.stringify({ name: v }) }).catch(() => null);
          const j = await r?.json().catch(() => ({}));
          if (!r?.ok) { fail(j?.error || "Couldn't rename."); done = false; return; }
          refresh(`Renamed to ${v}.`);
        };
        input.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); finish(true); } else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(false); } };
        input.onblur = () => finish(true);
      };
      const exportIt = () => { const a = el("a"); a.href = `/api/worlds/${w.id}/export`; a.download = ""; document.body.append(a); a.click(); a.remove(); };
      const del = async () => {
        const ok = await cwConfirm({ title: `Delete ${w.name}?`, keep: "Cancel", go: "Delete",
          lines: ["This can't be undone. Export it first if you may want it back.", ...(activeId === w.id ? [`Studio switches back to ${K.builtin}.`] : [])] });
        if (!ok) return more.focus();
        const r = await api(`/api/worlds/${w.id}`, { method: "DELETE" }).catch(() => null);
        if (!r?.ok) return fail("Couldn't delete.");
        refresh(`Deleted ${w.name}.`);
      };
      const redraw = () => openRedraw({ item: w, place: pair.place, inUse: activeId === w.id, back: more, onDone: (msg) => refresh(msg, w.id) });
      more.onclick = () => cwMenu(more, [...(v1 ? [["Redraw in new style…", redraw, null, w.description?.creature?.trim().length >= 3 ? null : "No description to redraw from."]] : []),
        ["Rename", rename], ["Export", exportIt], ["Delete", del, "danger"]]);
      li.append(more);
      return li;
    };
    list.append(row(null), ...(kind === "companion" ? [row(classicRow())] : []), ...items.map(row));
    box.append(head, actions);
    if (full) box.append(el("p", "hint", `Library full (12). Delete a ${K.one} to make room.`));
    box.append(list, el("p", "cw-head", `Library · ${items.length} of 12`));
  };
  section("companion");
  section("place");
};

// A generation still working in the background (user decision 2026-10-16): while one runs, every Studio page asks the
// server every 5 s; when it ends, the page shows a notice (and a Windows notification when Studio isn't in front and
// notifications are on). Each finished job is announced once per browser.
let cwJobT = null;
const cwJobWatch = async () => {
  clearTimeout(cwJobT);
  let j;
  try { j = await (await api("/api/worlds/job")).json(); } catch { return; }
  if (j.running) { cwJobT = setTimeout(cwJobWatch, 5000); return; }
  const last = j.last;
  if (!last || last.state === "stopped") return;
  const told = store.get("jobTold", []);
  if (told.includes(last.id) || document.querySelector("dialog.cw-dialog")) return;
  store.set("jobTold", [last.id, ...told].slice(0, 20));
  cwJobNotice(last);
};
const cwJobNotice = (job) => {
  const host = document.querySelector(".aw-notices");
  if (!host) return;
  const done = job.state === "done", what = job.redrawId ? "redrawn in the new style" : `ready (new ${job.kind})`;
  const title = done ? `${job.redrawId ? job.name || "Your companion" : job.name} is ${what}` : `Couldn't ${job.redrawId ? "redraw your companion" : `create your ${job.kind}`}`;
  const n = el("div", "aw-notice " + (done ? "" : "err"));
  const top = el("div", "top"), body = el("div");
  body.append(el("b", null, title));
  if (!done && job.error) body.append(el("div", "sub", job.error));
  const x = el("button", "icon-btn", "✕"); x.type = "button"; x.setAttribute("aria-label", "Dismiss"); x.onclick = () => n.remove();
  top.append(el("span", "ico", done ? "✦" : "!"), body, x);
  n.append(top);
  if (done) {
    const act = el("div", "act"), open = el("button", "btn sm primary", "Open"); open.type = "button";
    open.onclick = async () => { n.remove(); cwOpenJob(job); };
    act.append(open); n.append(act);
  }
  host.append(n);
  const live = document.querySelector("[aria-live=polite].sr");
  if (live) live.textContent = title + ".";
  if (notifyOn() && document.visibilityState !== "visible") {
    const w = new Notification((location.port === "4310" ? "[DEV] " : "") + "Claude Studio", { body: title, tag: "job:" + job.id, icon: "/claude.ico" });
    w.onclick = () => { window.focus(); w.close(); };
  }
};
// Open a finished job's result where it belongs: the Create preview, or the Redraw comparison.
const cwOpenJob = async (job) => {
  let lib;
  try { lib = await (await api("/api/worlds")).json(); } catch { return; }
  const pair = cwPair(lib);
  const refresh = () => { if ($("sceneDialog")?.open) mountWorlds($("scenePanel")); };
  if (job.redrawId) {
    const item = lib.companions.find((x) => x.id === job.redrawId);
    if (item) openRedraw({ item, place: pair.place, inUse: lib.activeCompanion === item.id, resume: job, onDone: refresh });
    return;
  }
  openCreateWorld({ kind: job.kind, other: job.kind === "companion" ? pair.place : pair.companion, resume: job, onSaved: refresh });
};
cwJobWatch(); // a job started on another page, or before this page loaded

// Redraw in new style (worlds-v2 FR-220, design creatures-v2 §7): a v1 companion is redrawn from its own description as
// a v2 sprite. Ask → Redrawing… → compare → Use new style (same id, name and lines) or Keep the old one.
const openRedraw = ({ item, place = null, inUse = false, back = document.activeElement, onDone, resume = null } = {}) => {
  const dlg = el("dialog", "cw-dialog");
  dlg.setAttribute("aria-labelledby", "rdTitle");
  const form = el("form", "settings"); form.method = "dialog";
  form.onsubmit = (e) => e.preventDefault();
  const head = el("div", "cw-dhead");
  const h = el("h2", null, `Redraw ${item.name} in the new style?`); h.id = "rdTitle";
  const x = el("button", "icon-btn", "✕"); x.type = "button"; x.setAttribute("aria-label", "Close"); x.title = "Close";
  head.append(h, x);
  const body = el("div", "cw-body");
  form.append(head, body);
  dlg.append(form);
  document.body.append(dlg);
  const model = ["sonnet", "opus", "haiku"].includes(item.model) ? item.model : "sonnet";
  const st = { draft: null, total: 0, busy: null, stops: [], error: "", kept: false };
  const stopStages = () => { st.stops.forEach((f) => f()); st.stops = []; };
  const close = () => { st.busy?.abort(); stopStages(); dlg.close(); };
  const tryClose = async () => {
    if (st.busy) { st.background = true; st.busy.abort(); close(); cwJobWatch(); return; } // keeps going; the notice says when
    if (st.draft && !st.kept && !await cwConfirm({ title: "Keep the old one?", lines: [`The new drawing of ${item.name} isn't saved.`], keep: "Back", go: "Keep the old one" })) return;
    close();
  };
  x.onclick = tryClose;
  dlg.addEventListener("keydown", (e) => { if (e.key === "Escape" && !e.defaultPrevented) { e.preventDefault(); tryClose(); } });
  dlg.addEventListener("cancel", (e) => { e.preventDefault(); tryClose(); });
  dlg.addEventListener("close", () => { stopStages(); dlg.remove(); back?.focus?.(); });
  const errBox = () => { if (!st.error) return []; const b = el("div", "cw-err", st.error); b.setAttribute("role", "alert"); return [b]; };
  const actions = (...buttons) => { const a = el("div", "dialog-actions cw-preview-actions"); a.append(...buttons); return a; };
  const button = (label, cls, fn) => { const b = el("button", cls, label); b.type = "button"; b.onclick = fn; return b; };

  const ask = () => {
    stopStages(); body.innerHTML = "";
    const go = button("Redraw", "btn primary", redraw);
    body.append(el("p", "hint", `Claude redraws it from its description (“${item.description.creature.trim()}”), with an outline, shading and the new frames. The name and lines stay. It costs about as much as one Change….`),
      ...errBox(), actions(button("Cancel", "btn ghost", tryClose), go));
    go.focus();
  };
  const redraw = async () => {
    st.error = ""; stopStages(); body.innerHTML = "";
    const ac = new AbortController(); st.busy = ac;
    const p = el("div", "cw-progress"); p.setAttribute("role", "status");
    const dot = el("span", "pulse"); dot.setAttribute("aria-hidden", "true");
    const txt = el("div", null, `Redrawing ${item.name}…`); const secs = el("div", "t", "0 s");
    txt.append(secs); p.append(dot, txt);
    const stop = button("Stop", "btn", () => { ac.abort(); api("/api/worlds/job/stop", { method: "POST", body: "{}" }).catch(() => {}); });
    body.append(p, el("p", "hint", "This takes about 2–4 minutes. You can close this and keep working. Studio lets you know when it's ready."), actions(stop)); stop.focus();
    const t0 = Date.now(), timer = setInterval(() => (secs.textContent = `${Math.round((Date.now() - t0) / 1000)} s`), 1000);
    let r = null, j = {};
    try { r = await api("/api/worlds/generate", { method: "POST", signal: ac.signal, body: JSON.stringify({ kind: "companion", description: item.description.creature, model, base: item.world, redraw: true, redrawId: item.id }) }); j = await r.json().catch(() => ({})); }
    catch { r = null; }
    clearInterval(timer); st.busy = null;
    if (st.background) return;
    if (j.jobId) api(`/api/worlds/job/${j.jobId}`, { method: "DELETE" }).catch(() => {});
    if (j.costUsd) st.total += j.costUsd;
    if (ac.signal.aborted) return st.draft ? compare() : ask();
    if (!r?.ok) { st.error = j.error || "Couldn't reach Studio."; return st.draft ? compare() : ask(); }
    st.draft = j.draft; st.cost = j.costUsd || 0;
    compare(`${item.name} is redrawn.`);
  };
  const compare = (announce) => {
    stopStages(); body.innerHTML = "";
    const theme = effectiveTheme(), grid = el("div", "rd-compare");
    for (const [creature, label, aria] of [[item.world.creature, "Now (classic style)", `${item.name} now, classic style`], [st.draft.world.creature, "New style", `${item.name} in the new style`]]) {
      const fig = el("figure"), stage = el("div", "cw-stage rd-stage");
      stage.setAttribute("role", "img"); stage.setAttribute("aria-label", aria);
      fig.append(stage, el("figcaption", null, label));
      grid.append(fig);
      requestAnimationFrame(() => { if (stage.isConnected) st.stops.push(mountWorldStage(stage, pairOf({ ...item.world, creature }, place), theme)); });
    }
    const status = el("p", "hint cw-status", announce || ""); status.setAttribute("role", "status");
    const use = button("Use new style", "btn primary", keep);
    body.append(grid, el("p", "hint", `${cwCost(st.cost)} (estimated; on a Claude plan this counts toward your usage limits instead)`), ...errBox(), status,
      actions(el("span", "left"), button("Try again", "btn ghost", redraw), button("Keep the old one", "btn", close), use));
    st.error = "";
    use.focus();
  };
  const keep = async () => {
    const r = await api(`/api/worlds/${item.id}/creature`, { method: "PUT", body: JSON.stringify({ creature: st.draft.world.creature, costUsd: st.total }) }).catch(() => null);
    const j = await r?.json().catch(() => ({}));
    if (!r?.ok) { st.error = j?.error || "Couldn't reach Studio."; return compare(); }
    st.kept = true;
    const world = { ...item.world, creature: st.draft.world.creature };
    if (inUse) dispatchEvent(new CustomEvent("studio-world", { detail: { companion: world, place } }));
    close();
    onDone?.(`${item.name} redrawn in the new style.`);
  };
  dlg.showModal();
  if (resume?.draft) {
    st.draft = resume.draft; st.cost = st.total = resume.costUsd || 0;
    api(`/api/worlds/job/${resume.id}`, { method: "DELETE" }).catch(() => {});
    compare(`${item.name} is redrawn.`);
  } else ask();
};

// Create a companion or a place (FR-209; flow as custom-world FR-140 to FR-145): Describe → Creating… → Preview, with
// Change…, in one dialog. The preview pairs the draft with the other half in use (other: a companion or place world).
const CW_IDEAS = {
  companion: [["a sleepy blue axolotl with pink gills who speaks softly", "Axolotl"], ["a curious red fox with a fluffy tail, cheeky and quick", "Fox"], ["a small round robot with one antenna that beeps when happy", "Robot"]],
  place: [["a moonlit coral reef with swaying sea plants", "Coral reef"], ["autumn woods with orange oaks and fallen leaves", "Autumn woods"], ["a snowy pine forest with soft snow on the ground", "Snowy pines"]],
};
const CW_TEXT = {
  companion: { title: "Create a companion", label: "Describe your companion: what it looks like and how it talks.", intro: "Claude draws your companion as pixel art, with lines in its own voice.", use: "Use this companion" },
  place: { title: "Create a place", label: "Describe the place: landscape, ground, plants, and how it looks by day and by night.", intro: "Claude paints the place as pixel art, by day and by night.", use: "Use this place" },
};
// resume: a finished background job (GET /api/worlds/job) to open straight in the preview.
const openCreateWorld = ({ kind = "companion", other = null, back = document.activeElement, onSaved, resume = null } = {}) => {
  const T = CW_TEXT[kind];
  const dlg = el("dialog", "cw-dialog");
  dlg.setAttribute("aria-labelledby", "cwTitle");
  const form = el("form", "settings"); form.method = "dialog";
  form.onsubmit = (e) => e.preventDefault();
  const head = el("div", "cw-dhead");
  const h = el("h2", null, T.title); h.id = "cwTitle";
  const x = el("button", "icon-btn", "✕"); x.type = "button"; x.setAttribute("aria-label", "Close"); x.title = "Close";
  head.append(h, x);
  const body = el("div", "cw-body");
  form.append(head, body);
  dlg.append(form);
  document.body.append(dlg);
  const st = { description: "", model: "sonnet", draft: null, cost: 0, total: 0, changes: [], saved: false, busy: null, stop: null, theme: effectiveTheme(), error: "" };
  const close = () => { st.busy?.abort(); st.stop?.(); dlg.close(); };
  const tryClose = async () => {
    // Still working: the dialog closes, the generation goes on, and Studio says when it's ready (cwJobWatch).
    if (st.busy) { st.background = true; st.busy.abort(); close(); cwJobWatch(); return; }
    if (st.draft && !st.saved && !await cwConfirm({ title: `Discard ${st.draft.world.name}?`, lines: ["It isn't saved. You can save it to the library first."], keep: "Keep editing", go: "Discard" })) return;
    close();
  };
  x.onclick = tryClose;
  // Esc is handled on keydown: Chrome lets a page cancel the dialog's own Esc only once per user input, so a second
  // Esc would close it without the discard question (QA F-1). "cancel" stays for other ways of closing.
  const onEsc = () => { if (body.querySelector(".cw-change") && !st.busy) return preview(); tryClose(); };
  dlg.addEventListener("keydown", (e) => { if (e.key === "Escape" && !e.defaultPrevented) { e.preventDefault(); onEsc(); } });
  dlg.addEventListener("cancel", (e) => { e.preventDefault(); onEsc(); });
  dlg.addEventListener("close", () => { st.stop?.(); dlg.remove(); back?.focus?.(); });
  const errBox = () => { if (!st.error) return []; const b = el("div", "cw-err", st.error); b.setAttribute("role", "alert"); return [b]; };
  const stopIt = () => { st.busy?.abort(); api("/api/worlds/job/stop", { method: "POST", body: "{}" }).catch(() => {}); };

  // ---- Describe ----
  const describe = () => {
    st.stop?.(); st.stop = null;
    body.innerHTML = "";
    const l = el("label", "field");
    const s = el("span", "cw-label"); const count = el("span", "count");
    s.append(T.label, count);
    const t = el("textarea"); t.rows = 3; t.maxLength = 300; t.value = st.description;
    const check = () => { go.disabled = t.value.trim().length < 3; };
    const upd = () => { count.textContent = `${t.value.length}/300`; count.classList.toggle("warn", t.value.length >= 280); st.description = t.value; check(); };
    t.oninput = upd;
    t.onkeydown = (e) => { if (e.key === "Enter" && e.ctrlKey && !go.disabled) { e.preventDefault(); generate(); } };
    l.append(s, t);
    const ideas = el("div", "cw-ideas"); ideas.append("Ideas: ");
    for (const [d, label] of CW_IDEAS[kind]) {
      const b = el("button", "tag", label); b.type = "button";
      b.onclick = async () => {
        if (t.value.trim() && !await cwConfirm({ title: "Replace your description?", lines: ["The idea replaces what you typed."], keep: "Keep mine", go: "Replace" })) return;
        t.value = d; upd(); go.focus();
      };
      ideas.append(b);
    }
    const ml = el("label", "field"); ml.append(el("span", null, "Model"));
    const sel = el("select");
    for (const [v, n] of [["sonnet", "Sonnet: balanced (default)"], ["opus", "Opus: draws best, costs more"], ["haiku", "Haiku: fastest, cheapest"]]) { const o = el("option", null, n); o.value = v; sel.append(o); }
    sel.value = st.model; sel.onchange = () => (st.model = sel.value);
    ml.append(sel);
    const actions = el("div", "dialog-actions");
    const cancel = el("button", "btn ghost", "Cancel"); cancel.type = "button"; cancel.onclick = tryClose;
    const go = el("button", "btn primary", "Create"); go.type = "button"; go.onclick = () => generate();
    actions.append(cancel, go);
    body.append(el("p", "hint", T.intro), l, ideas, ml, el("p", "hint", `Takes about ${kind === "companion" ? "2–4 minutes" : "20–60 s"}. Uses your signed-in Claude account.`), ...errBox(), actions);
    upd();
    (st.error ? go : t).focus();
  };

  // ---- Creating… (also used by Change…, over the dimmed preview) ----
  const working = (host, label) => {
    const p = el("div", "cw-progress"); p.setAttribute("role", "status");
    const dot = el("span", "pulse"); dot.setAttribute("aria-hidden", "true");
    const txt = el("div", null, label); const secs = el("div", "t", "0 s");
    txt.append(secs); p.append(dot, txt);
    host.append(p);
    const t0 = Date.now(); const t = setInterval(() => (secs.textContent = `${Math.round((Date.now() - t0) / 1000)} s`), 1000);
    return () => clearInterval(t);
  };
  const generate = async (change) => {
    st.error = "";
    const ac = new AbortController(); st.busy = ac;
    let stopTimer;
    if (change) {
      body.querySelector(".cw-stage").classList.add("dim");
      const over = el("div", "cw-over"); body.querySelector(".cw-stage").append(over);
      stopTimer = working(over, `Changing your ${kind}…`);
      const actions = body.querySelector(".cw-change .dialog-actions");
      actions.innerHTML = ""; const s = el("button", "btn", "Stop"); s.type = "button"; s.onclick = stopIt; actions.append(s); s.focus();
      body.querySelector(".cw-change input").disabled = true;
    } else {
      st.stop?.(); st.stop = null;
      body.innerHTML = "";
      const sum = el("dl", "cw-summary");
      sum.append(el("dt", null, kind === "companion" ? "Companion" : "Place"), el("dd", null, st.description.trim()));
      const wrap = el("div");
      stopTimer = working(wrap, `Creating your ${kind}… this takes about ${kind === "companion" ? "2–4 minutes" : "20–60 seconds"}`);
      const actions = el("div", "dialog-actions"); const s = el("button", "btn", "Stop"); s.type = "button"; s.onclick = stopIt; actions.append(s);
      body.append(sum, wrap, el("p", "hint", "You can close this and keep working. Studio lets you know when it's ready."), actions); s.focus();
    }
    const payload = { kind, description: st.description, model: st.model, ...(change ? { base: st.draft.world, change } : {}) };
    let r = null, j = {};
    try { r = await api("/api/worlds/generate", { method: "POST", body: JSON.stringify(payload), signal: ac.signal }); j = await r.json().catch(() => ({})); }
    catch { r = null; }
    stopTimer(); st.busy = null;
    if (st.background) return; // closed while working: the notice takes it from here
    if (j.jobId) api(`/api/worlds/job/${j.jobId}`, { method: "DELETE" }).catch(() => {}); // taken here, so no notice
    if (ac.signal.aborted) { st.error = ""; if (change) { preview(); note("Stopped."); } else { describe(); } return; }
    if (j.costUsd) st.total += j.costUsd;
    if (!r?.ok) { st.error = j.error || "Couldn't reach Studio."; return change ? preview() : describe(); }
    st.draft = j.draft; st.cost = j.costUsd || 0; st.saved = false;
    if (change) st.changes.push(change);
    preview(`${j.draft.world.name} is ready.`);
  };
  const note = (t) => { const s = body.querySelector(".cw-status"); if (s) s.textContent = t; };

  // ---- Preview: the draft with the other half in use ----
  const preview = (announce) => {
    st.stop?.(); st.stop = null;
    body.innerHTML = "";
    const w = st.draft.world;
    const shown = kind === "companion" ? pairOf(w, other) : pairOf(other, w);
    const stage = el("div", "cw-stage");
    stage.setAttribute("role", "img");
    stage.setAttribute("aria-label", `Preview: ${w.name}, ${st.description.trim()}`);
    const tg = el("div", "cw-toggle"); tg.setAttribute("role", "group"); tg.setAttribute("aria-label", "Preview theme");
    const tb = ["light", "dark"].map((t) => { const b = el("button", "btn sm", t === "light" ? "Light" : "Dark"); b.type = "button"; b.setAttribute("aria-pressed", String(st.theme === t));
      b.onclick = () => { st.theme = t; tb.forEach((x, i) => x.setAttribute("aria-pressed", String(["light", "dark"][i] === t))); st.stop?.(); st.stop = mountWorldStage(stage, shown, t); };
      b.onkeydown = (e) => { if (e.key === "ArrowLeft" || e.key === "ArrowRight") { e.preventDefault(); tb[t === "light" ? 1 : 0].focus(); } };
      return b; });
    tg.append(...tb); stage.append(tg);
    const lines = el("div", "cw-lines");
    if (w.lines) for (const t of [w.lines.hello[0], w.lines.thinking[0]]) lines.append(el("span", "cw-line", `“${t}”`));
    const status = el("p", "hint cw-status", announce || ""); status.setAttribute("role", "status");
    body.append(stage, el("p", "cw-name", w.name), el("p", "hint cw-desc", st.description.trim()), lines,
      el("p", "hint", `${cwCost(st.cost)} (estimated; on a Claude plan this counts toward your usage limits instead)`), ...errBox(), status);
    const actions = el("div", "dialog-actions cw-preview-actions");
    const left = el("span", "left");
    const again = el("button", "btn ghost", "Try again"); again.type = "button"; again.onclick = () => generate();
    const chg = el("button", "btn ghost", "Change…"); chg.type = "button"; chg.onclick = changeField;
    left.append(again, chg);
    const save = el("button", "btn", st.saved ? "✓ Saved" : "Save to library"); save.type = "button"; save.disabled = st.saved;
    const useIt = el("button", "btn primary", T.use); useIt.type = "button";
    const keep = async (use) => {
      const r = await api("/api/worlds", { method: "POST", body: JSON.stringify({ use, draft: { ...st.draft, costUsd: st.total, changes: st.changes } }) }).catch(() => null);
      const j = await r?.json().catch(() => ({}));
      if (!r?.ok) { st.error = j?.error || "Couldn't reach Studio."; preview(); return null; }
      return j;
    };
    save.onclick = async () => { const j = await keep(false); if (!j) return; st.saved = true; save.textContent = "✓ Saved"; save.disabled = true; note(`Saved ${j.name} to the library.`); onSaved?.(j.id, j.name, false); };
    useIt.onclick = async () => {
      const j = await keep(true); if (!j) return;
      st.saved = true;
      const mine = { ...w, name: j.name };
      dispatchEvent(new CustomEvent("studio-world", { detail: kind === "companion" ? { companion: mine, place: other } : { companion: other, place: mine } }));
      close();
      onSaved?.(j.id, j.name, true);
    };
    actions.append(left, save, useIt);
    body.append(actions);
    st.error = "";
    st.stop = mountWorldStage(stage, shown, st.theme);
    useIt.focus();
  };
  // ---- Change… ----
  const changeField = () => {
    const actions = body.querySelector(".cw-preview-actions");
    const box = el("div", "cw-change");
    const l = el("label", "field"); l.append(el("span", null, "What should change?"));
    const input = el("input"); input.maxLength = 200; input.placeholder = kind === "companion" ? "e.g. make it orange and give it a hat" : "e.g. more trees and a pinker sunset";
    l.append(input);
    const row = el("div", "dialog-actions");
    const cancel = el("button", "btn ghost", "Cancel"); cancel.type = "button"; cancel.onclick = () => preview();
    const apply = el("button", "btn primary", "Apply"); apply.type = "button"; apply.disabled = true;
    input.oninput = () => (apply.disabled = input.value.trim().length < 3);
    input.onkeydown = (e) => { if (e.key === "Enter" && !apply.disabled) { e.preventDefault(); apply.click(); } };
    apply.onclick = () => generate(input.value.trim());
    row.append(cancel, apply);
    box.append(l, row);
    actions.replaceWith(box);
    input.focus();
  };

  dlg.showModal();
  if (resume?.draft) {
    st.description = resume.description; st.model = resume.model; st.cost = st.total = resume.costUsd || 0;
    st.draft = { kind, world: resume.draft.world, description: resume.description, model: resume.model };
    api(`/api/worlds/job/${resume.id}`, { method: "DELETE" }).catch(() => {});
    preview(`${resume.draft.world.name} is ready.`);
  } else describe();
};


// ---------- Updates (spec updates FR-228 to FR-234, design updates §3, §4) ----------
// Settings → Updates (a tab on the chat page, a section on Home) and the notices. The server does the work (updater.js).
const vShort = (v) => "v" + String(v || "?").replace(/\.0$/, "");
const upAgo = (t) => { if (!t) return "never"; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? "just now" : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : new Date(t).toLocaleString(undefined, { weekday: "short", hour: "2-digit", minute: "2-digit" }); };
const upDate = (d) => (d ? new Date(d + "T12:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "");
const upNotes = (notes) => { const ul = el("ul", "up-notes"); for (const n of notes || []) ul.append(el("li", null, n)); return ul; };
const upBox = (kind, title, ...rest) => {
  const b = el("div", `up-state ${kind}`);
  b.setAttribute("role", ["warn", "err"].includes(kind) ? "alert" : "status");
  b.append(el("div", "t", title), ...rest.filter(Boolean));
  return b;
};
const openUpdates = () => {
  if ($("tabUpdates")) { $("tabUpdates").click(); if (!$("settings").open) $("settings").showModal(); return; }
  $("openSettings")?.click();
  setTimeout(() => $("updatesHead")?.scrollIntoView({ block: "start" }), 100);
};
let upTimer = null, upRefused = null;
// Startup (spec autostart, design autostart): start LIVE hidden when I sign in to Windows. The state is read from the
// launcher file each time the tab opens (FR-238); a change applies at once with no Save button.
const mountStartup = async (box, refocus) => { // refocus: the section was rebuilt by a keyboard action, so keep the user's place (QA F-1)
  box.querySelector(".up-startup")?.remove();
  const sec = el("section", "up-startup"); sec.append(el("h3", "settings-sub", "Startup")); box.append(sec);
  let a;
  try { a = await (await api("/api/autostart")).json(); } catch { a = { live: true, error: "Couldn't read the Startup folder." }; }
  if (!a.live) { // FR-242
    const n = el("div", "up-state muted"), l = el("a", "link-btn", "Open LIVE"); l.href = "http://localhost:4300"; l.rel = "noopener";
    n.append("Switch this on from the LIVE channel. DEV, the working copy, never starts with Windows. ", l); sec.append(n); return;
  }
  const state = el("p", "hint"); state.setAttribute("role", "status");
  const say = (t, ms = 4000) => { state.textContent = t; if (t && ms) setTimeout(() => { if (state.textContent === t) state.textContent = ""; }, ms); };
  const post = (url, body = {}) => api(url, { method: "POST", body: JSON.stringify(body) }).then(async (r) => ({ ok: r.ok, ...(await r.json().catch(() => ({}))) })).catch(() => ({ ok: false, error: "Couldn't reach Studio." }));
  const sw = el("label", "check up-auto"), cb = el("input"); cb.type = "checkbox"; cb.checked = !!a.on; cb.disabled = !!a.error; cb.setAttribute("aria-describedby", "upStartHelp");
  const help = el("small", null, "Starts Studio (LIVE) hidden when you sign in. No window and no browser tab open; visit http://localhost:4300 when you want it. Turning this off doesn't stop a running Studio. To stop one, end \"node.exe\" in Task Manager."); help.id = "upStartHelp";
  sw.append(cb, el("span", null, "Start Studio when I sign in to Windows"), help);
  cb.onchange = async () => {
    const want = cb.checked; cb.disabled = true; sw.setAttribute("aria-busy", "true"); say(want ? "Turning on…" : "Turning off…", 0);
    const r = await post("/api/autostart", { on: want });
    if (r.ok) { await mountStartup(box, true); const h = box.querySelector(".up-startup .hint"); if (h) { h.textContent = want ? "On. Studio will start when you sign in." : "Off. Studio starts only when you start it."; setTimeout(() => { if (h.isConnected) h.textContent = ""; }, 4000); } return; }
    cb.checked = !want; cb.disabled = false; cb.focus(); sw.removeAttribute("aria-busy"); err.textContent = r.error || "Couldn't change the Startup folder."; say("");
  };
  const err = el("p", "error-text"); err.setAttribute("role", "alert");
  sec.append(sw, state, err);
  if (refocus) cb.focus();
  if (a.error) { const t = el("button", "link-btn", "Try again"); t.type = "button"; t.onclick = () => mountStartup(box); err.textContent = a.error; sec.append(t); return; }
  if (a.on && a.stale) { // FR-239
    const why = a.stale === "missing" ? `It was made for ${a.folder || "a folder"}, which isn't there now.` : a.stale === "node" ? "It uses a copy of Node that isn't there now." : `It starts the Studio in ${a.folder}, not this one.`;
    const b = upBox("warn", (a.stale === "missing" ? "⚠ The startup launcher points to a missing folder." : "⚠ The startup launcher is out of date."), el("p", null, why));
    const fix = el("button", "btn primary", "Fix"), off = el("button", "link-btn", "Turn off"); fix.type = off.type = "button";
    fix.onclick = async () => { fix.disabled = true; const r = await post("/api/autostart/fix"); await mountStartup(box, true); const h = box.querySelector(".up-startup .hint"); const e = box.querySelector(".up-startup .error-text"); if (r.ok) { if (h) h.textContent = "Fixed. Studio will start from this folder."; } else if (e) e.textContent = r.error || "Couldn't change the Startup folder."; };
    off.onclick = () => { cb.checked = false; cb.onchange(); };
    const row = el("div", "up-acts"); row.append(fix, off); b.append(row); sec.append(b);
  }
};
const mountUpdates = async (box) => {
  clearTimeout(upTimer);
  if (!box?.isConnected) return;
  let u;
  try { u = await (await api("/api/updates")).json(); }
  catch { // the server is restarting during an update: keep the progress on screen and look again
    // (it can't say which step it's on while it's down, so show the restart and count)
    if (box.querySelector(".up-progress")) {
      box.upDownSince = box.upDownSince || Date.now();
      const t = box.querySelector(".up-state.update .t"), secs = Math.round((Date.now() - box.upDownSince) / 1000);
      if (t) { t.textContent = ""; t.append(el("span", "spin"), `Restarting Studio… ${secs} s`); }
      box.querySelectorAll(".up-progress li").forEach((li, i) => { li.className = i < 3 ? "done" : "now"; });
      upTimer = setTimeout(() => mountUpdates(box), 2000);
    }
    return;
  }
  delete box.upDownSince;
  const again = (ms) => { upTimer = setTimeout(() => mountUpdates(box), ms); };
  const btn = (label, cls, fn) => { const b = el("button", cls, label); b.type = "button"; b.onclick = fn; return b; };
  const post = async (url, body = {}) => { const r = await api(url, { method: "POST", body: JSON.stringify(body) }).catch(() => null); return [r, await r?.json().catch(() => ({}))]; };
  const acts = (...b) => { const a = el("div", "up-acts"); a.append(...b.filter(Boolean)); return a; }; // a missing button is left out, not written as "null" (QA F-2)
  box.innerHTML = "";
  const head = el("div", "up-head");
  head.append(el("b", null, `Claude Studio ${vShort(u.installed.version)}`), el("span", null, [u.installed.title, u.live ? (u.installed.date ? `released ${upDate(u.installed.date)}` : "") : "working copy (DEV)"].filter(Boolean).join(" · ")));
  box.append(head);
  if (!u.live) { // FR-228: DEV never checks or updates
    box.append(upBox("muted", "Updates apply to LIVE", el("p", null, "This is DEV, the working copy. It doesn't check or update; LIVE at localhost:4300 does.")));
    mountStartup(box);
    return;
  }
  const p = u.progress, r = u.result, a = u.available;
  if (p) { // FR-232: Downloading → Checking → Installing → Restarting
    const steps = ["downloading", "checking", "installing", "restarting"], now = steps.indexOf(p.step);
    const label = { downloading: "Downloading", checking: "Checking", installing: "Installing", restarting: "Restarting" };
    box.upSince = box.upSince || Date.now();
    const since = p.restartAt || box.upSince;
    const ol = el("ol", "up-progress"); ol.setAttribute("aria-label", "Update progress");
    steps.forEach((s, i) => { const li = el("li", i < now ? "done" : i === now ? "now" : "", label[s]); if (i === now) li.setAttribute("aria-current", "step"); ol.append(li); });
    const mb = (n) => (n / 1048576).toFixed(1);
    const line = p.rollback ? "Going back to the previous version…" : p.step === "downloading" && p.total ? `Updating to ${vShort(p.version)}… Downloading (${mb(p.done)} of ${mb(p.total)} MB)` : p.step === "restarting" ? "Restarting Studio… " : `Updating to ${vShort(p.version)}… ${label[p.step]}`;
    const t = el("div", "t"); t.append(el("span", "spin"), line); if (p.step === "restarting") t.append(el("span", "up-secs", `${Math.round((Date.now() - since) / 1000)} s`));
    const b = el("div", "up-state update"); b.setAttribute("role", "status");
    b.append(t, el("p", null, p.step === "installing" ? "Installing the new version and its packages takes about a minute. Keep Studio open; new chats wait until it's done." : p.step === "restarting" ? `The page reloads by itself when the new version is up. If it doesn't come back within 90 s, Studio goes back to ${vShort(p.from)}.` : "Keep Studio open. This takes about a minute; new chats wait until it's done."), ol);
    if (["downloading", "checking"].includes(p.step)) b.append(acts(btn("Cancel", "btn", async () => { await post("/api/updates/cancel"); mountUpdates(box); })));
    box.append(b);
    again(p.step === "restarting" ? 2000 : 700);
    return;
  }
  // An update this page watched has finished: reload, so the page itself is the new version (and says so in a notice).
  if (box.upSince && r && ["updated", "wentBack", "rolledBack"].includes(r.kind)) { location.reload(); return; }
  delete box.upSince;
  if (r && r.kind === "updated" && Date.now() - r.at < 7 * 86400000) {
    const back = el("p", null, "Your chats, companions and settings are as they were. ");
    back.append(btn(`Go back to ${vShort(r.from)}`, "link-btn", async () => {
      if (!await cwConfirm({ title: `Go back to ${vShort(r.from)}?`, lines: ["Studio restarts on the previous version. Your data stays as it is."], keep: "Cancel", go: "Go back" })) return;
      await post("/api/updates/rollback"); mountUpdates(box);
    }));
    box.append(upBox("ok", `✓ Updated to ${vShort(r.to)}`, upNotes(u.installed.notes), back));
  } else if (r && r.kind === "wentBack" && Date.now() - r.at < 86400000) {
    box.append(upBox("ok", `✓ Back on ${vShort(u.installed.version)}`, el("p", null, "Studio went back to the previous version, as you asked.")));
  } else if (r && r.kind === "rolledBack" && !(a && a.version !== r.to)) {
    const d = el("details", "mini"); d.append(el("summary", null, "Details"), el("pre", null, r.reason || ""));
    box.append(upBox("err", `The update didn't start, so Studio went back to ${vShort(r.from)}`, el("p", null, "Nothing else changed. You can try again later, or tell the publisher."), d, a ? acts(btn("Try again", "btn", () => update())) : null));
  } else if (r && r.kind === "failed" && !(a && a.version !== r.to)) {
    box.append(upBox("err", `Couldn't update: ${r.reason}`, el("p", null, `Nothing was installed; you're still on ${vShort(u.installed.version)}.`), a ? acts(btn("Try again", "btn", () => update())) : null));
  }
  const update = async () => {
    upRefused = null;
    const [res, j] = await post("/api/updates/apply");
    if (!res?.ok) upRefused = { version: a?.version, code: j?.code, error: j?.error || "Couldn't reach Studio." };
    mountUpdates(box);
    box.querySelector(".up-state")?.focus?.();
  };
  if (a && !(r && ["rolledBack", "failed"].includes(r.kind) && r.to === a.version)) { // FR-230
    const b = upBox("update", `⬆ Claude Studio ${vShort(a.version)} is available`, el("p", null, [a.title, upDate(a.date), `${(a.zip.size / 1048576).toFixed(1)} MB`].filter(Boolean).join(" · ")), upNotes(a.notes));
    const refused = upRefused?.version === a.version ? upRefused : null;
    if (refused) b.append(upBox("warn", refused.code === "busy" ? "A chat is still working" : refused.code === "dirty" ? "The Studio folder has changes that aren't committed" : "Couldn't start the update", el("p", null, refused.error)));
    const go = btn(`Update to ${vShort(a.version)}`, "btn primary", update);
    b.append(acts(u.dismissed === a.version ? null : btn("Not now", "btn ghost", async () => { await post("/api/updates/dismiss"); document.querySelector(".aw-notice.update")?.remove(); mountUpdates(box); }), go));
    box.append(b);
  } else if (u.checking) {
    const t = el("div", "t"); t.append(el("span", "spin"), "Checking for updates…");
    const b = el("div", "up-state muted"); b.setAttribute("role", "status"); b.append(t); box.append(b);
    again(1000);
  } else if (u.lastCheck?.unverified) {
    box.append(upBox("warn", "The update information couldn't be verified", el("p", null, "Its signature doesn't match Claude Studio's release key, so nothing will be installed. If this keeps happening, tell the publisher.")));
  } else if (u.lastCheck && !u.lastCheck.ok) {
    box.append(upBox("muted", "Couldn't check for updates", el("p", null, `${u.lastCheck.error} Studio tries again later.`)));
  } else if (u.lastCheck?.ok && !r) {
    box.append(upBox("ok", "✓ Claude Studio is up to date", el("p", null, `${vShort(u.installed.version)} is the latest release.`)));
  }
  // Check now, when it last checked, the switch, and what's in this version
  const row = el("div", "up-row");
  const check = btn("Check for updates", "btn", async () => { check.disabled = true; check.textContent = "Checking…"; await post("/api/updates/check"); upRefused = null; mountUpdates(box); });
  row.append(check, el("span", null, u.lastCheck ? `Last checked ${upAgo(u.lastCheck.at)}` : "Not checked yet"));
  const sw = el("label", "check up-auto"), cb = el("input"); cb.type = "checkbox"; cb.checked = u.auto;
  cb.onchange = () => post("/api/updates/auto", { on: cb.checked });
  sw.append(cb, el("span", null, "Check for updates automatically"), el("small", null, `When Studio starts and every 6 hours. Studio only reads two small files from ${new URL(u.site).host}; nothing about you is sent.`));
  const what = el("details", "mini"); what.append(el("summary", null, `What's in ${vShort(u.installed.version)}`), upNotes(u.installed.notes));
  box.append(row, sw, what);
  mountStartup(box);
  $("tabUpdates")?.classList.toggle("has-update", !!a && u.dismissed !== a.version);
};
// Notices on page load (design §4): an update is available, or one just finished. Once per version / result.
const upNotices = async () => {
  let u;
  try { u = await (await api("/api/updates")).json(); } catch { return; }
  const host = document.querySelector(".aw-notices");
  if (!u.live || !host) return;
  const notice = (cls, icon, title, sub, buttons) => {
    const n = el("div", "aw-notice " + cls); n.setAttribute("role", cls === "err" ? "alert" : "status");
    const top = el("div", "top"), body = el("div");
    body.append(el("b", null, title)); if (sub) body.append(el("div", "sub", sub));
    const x = el("button", "icon-btn", "✕"); x.type = "button"; x.setAttribute("aria-label", "Dismiss"); x.onclick = () => n.remove();
    top.append(el("span", "ico", icon), body, x);
    const act = el("div", "act");
    for (const [label, cls2, fn] of buttons) { const b = el("button", cls2, label); b.type = "button"; b.onclick = () => { n.remove(); fn(); }; act.append(b); }
    n.append(top, act); host.append(n);
  };
  const r = u.result;
  if (r && !r.seen && ["updated", "rolledBack"].includes(r.kind)) {
    api("/api/updates/seen", { method: "POST", body: "{}" }).catch(() => {});
    if (r.kind === "updated") notice("", "✓", `Updated to ${vShort(r.to)}`, u.installed.title, [["What's new", "btn sm", openUpdates]]);
    else notice("err", "!", `The update to ${vShort(r.to)} didn't start`, `Studio went back to ${vShort(r.from)}. Nothing else changed.`, [["Details", "btn sm", openUpdates]]);
  }
  const a = u.available;
  $("tabUpdates")?.classList.toggle("has-update", !!a && u.dismissed !== a?.version);
  const failedThis = r && ["rolledBack", "failed"].includes(r.kind) && r.to === a?.version; // just tried and failed: no "available" too
  if (a && !failedThis && u.dismissed !== a.version && store.get("updTold", "") !== a.version && !u.progress) {
    store.set("updTold", a.version);
    notice("update", "⬆", `Claude Studio ${vShort(a.version)} is available`, a.title, [
      ["Not now", "btn sm ghost", () => api("/api/updates/dismiss", { method: "POST", body: "{}" }).catch(() => {})],
      ["See what's new", "btn sm primary", openUpdates]]);
  }
};
setTimeout(upNotices, 1500); // after away.js has made the notice area

// First look at running chats (and the start of the notification baseline); pages listen for studio-chats.
kickPoll();

// ---------- Companion, world & weather (spec scene-menu FR-178 to FR-184, design scene-menu §3) ----------
// One dialog for both pages, built at load so weather.js finds its select; the library is mounted on every open.
const sceneDialog = (() => {
  const d = el("dialog");
  d.id = "sceneDialog";
  d.setAttribute("aria-labelledby", "sceneTitle");
  d.innerHTML = `<form method="dialog" class="settings">
      <h2 id="sceneTitle">Companion, world &amp; weather</h2>
      <h3 class="settings-sub">Weather</h3>
      <div class="field"><select id="setWeather" aria-label="Weather" aria-describedby="wxHint wxRm"></select></div>
      <p class="hint" id="wxHint">Changes by itself every 5–20 minutes.</p>
      <p class="hint" id="wxRm" hidden>Reduce motion is on, so weather is shown still.</p>
      <h3 class="settings-sub" id="sceneWorldHead">Companion &amp; place</h3>
      <div id="scenePanel"></div>
      <div class="settings-actions"><button class="btn primary">Done</button></div>
    </form>`;
  document.body.append(d);
  d.addEventListener("close", () => { cwPairStop?.(); cwPairStop = null; $("openScene")?.focus(); }); // Done, Esc or the Settings pointer: back to 🐾
  return d;
})();
const openScene = ({ section } = {}) => {
  if ($("settings")?.open) $("settings").close();
  mountWorlds($("scenePanel"));
  if (!sceneDialog.open) sceneDialog.showModal();
  if (section === "world") $("sceneWorldHead").scrollIntoView({ block: "start" });
  else $("setWeather").focus();
};
$("openScene")?.addEventListener("click", () => openScene());
// The pointer line left in Settings (FR-180).
document.addEventListener("click", (e) => { if (e.target.closest("[data-open-scene]")) openScene(); });
