// Claude Studio front end: chat list, streaming turns in a messaging layout, permission and question quick replies,
// role chips, outputs and look settings. Spec: specs/look-and-feel.md (v0.3), specs/hardening.md, specs/baseline.md.
// Helpers ($, el, api, store) and the look settings come from look.js, loaded first.
const clock = () => new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

// Links open in a new tab so a running turn keeps streaming; only web, mail and output links stay clickable.
const SAFE_LINK = /^(https?:|mailto:|\/output\/)/i;
DOMPurify.addHook("afterSanitizeAttributes", (node) => {
  if (node.tagName !== "A") return;
  if (!SAFE_LINK.test(node.getAttribute("href") || "")) {
    node.removeAttribute("href");
    node.setAttribute("title", "Link blocked: this kind of address isn't allowed");
    return;
  }
  node.setAttribute("target", "_blank");
  node.setAttribute("rel", "noopener noreferrer");
  node.setAttribute("title", "Opens in a new tab");
});
const md = (text) => DOMPurify.sanitize(marked.parse(text || "", { gfm: true, breaks: false }), { ADD_ATTR: ["target"] });

const API_ERRORS = {
  authentication_failed: 'Claude isn\'t signed in on this PC. Open a terminal, run "claude", and sign in.',
  oauth_org_not_allowed: 'Claude isn\'t signed in on this PC. Open a terminal, run "claude", and sign in.',
  verification_required: 'Claude isn\'t signed in on this PC. Open a terminal, run "claude", and sign in.',
  billing_error: "There's a problem with the Claude account or billing. Check claude.ai.",
  account_on_hold: "There's a problem with the Claude account or billing. Check claude.ai.",
  rate_limit: "Usage limit reached. Try again later.",
  overloaded: "Claude is busy or had a server error. Try again in a moment.",
  server_error: "Claude is busy or had a server error. Try again in a moment.",
  model_not_found: "That model isn't available. Pick another model.",
  max_output_tokens: "The reply hit its length limit and was cut off.",
};
const RESULT_REASONS = {
  error_max_turns: "Reached the turn limit",
  error_max_budget_usd: "Reached the budget limit",
  error_during_execution: "Error while running",
};

const state = {
  chat: null, turnId: null, busy: false, tools: new Map(), currentText: null, streamed: new Set(),
  run: null, userMeta: null, seen: false, typing: null,
  roles: { chips: [], custom: [], commands: [] }, role: null,
  // v0.6 (spec reliable-chats): the stream this tab follows, its last event, the cards it shows, and scrolling.
  stream: null, lastSeq: 0, turnDone: false, sentHere: false, cards: new Map(),
  follow: true, newCount: 0, needsYou: false, listLocked: false, binMode: false, title: "Claude Studio",
};

// ---------- look settings (spec A; applyLook is in look.js) ----------
const applySettings = () => {
  const s = applyLook();
  $("setStyle").value = s.style; $("setTheme").value = s.theme; $("setSize").value = s.size; $("setFont").value = s.font; $("setWidth").value = s.width;
  $("setAccent").value = s.accent || getComputedStyle(document.documentElement).getPropertyValue("--accent").trim().slice(0, 7) || "#2563eb";
};
const saveSetting = (k, v) => { store.set("settings", { ...store.get("settings", {}), [k]: v }); applySettings(); };
$("setStyle").onchange = (e) => { const s = store.get("settings", {}); delete s.accent; store.set("settings", { ...s, style: e.target.value }); applySettings(); };
$("setTheme").onchange = (e) => saveSetting("theme", e.target.value);
$("setAccent").oninput = (e) => saveSetting("accent", e.target.value);
$("setSize").oninput = (e) => saveSetting("size", Number(e.target.value));
$("setFont").onchange = (e) => saveSetting("font", e.target.value);
$("setWidth").onchange = (e) => saveSetting("width", e.target.value);
// Weather lives in the scene menu now, so Reset look keeps it (spec scene-menu FR-182).
$("resetSettings").onclick = () => { const { weather } = store.get("settings", {}); store.set("settings", weather ? { weather } : {}); applySettings(); };
applySettings();

// Settings dialog tabs (ARIA tabs with arrow keys).
const TABS = [["tabLook", "panelLook"], ["tabRoles", "panelRoles"], ["tabPerms", "panelPerms"], ["tabHome", "panelHome"], ["tabUpdates", "panelUpdates"]];
const selectTab = (id) => {
  for (const [t, p] of TABS) {
    const on = t === id;
    $(t).setAttribute("aria-selected", String(on));
    $(t).tabIndex = on ? 0 : -1;
    $(p).hidden = !on;
  }
  if (id === "tabRoles") renderRoleSettings();
  if (id === "tabHome") mountHomeSetting($("panelHome"));
  if (id === "tabPerms") mountPermissions($("panelPerms"));
  if (id === "tabLook") mountChatSettings($("chatSettings"));
  if (id === "tabUpdates") mountUpdates($("panelUpdates"));
};
for (const [t] of TABS) {
  $(t).onclick = () => selectTab(t);
  $(t).onkeydown = (e) => {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    const i = TABS.findIndex(([x]) => x === t), next = TABS[(i + (e.key === "ArrowRight" ? 1 : TABS.length - 1)) % TABS.length][0];
    selectTab(next); $(next).focus();
  };
}
$("openSettings").onclick = () => { selectTab("tabLook"); $("settings").showModal(); };
if (location.hash === "#settings-home") { history.replaceState(null, "", location.pathname); selectTab("tabHome"); $("settings").showModal(); }

// ---------- info, projects, chats ----------
const loadInfo = async () => {
  const info = await (await api("/api/info")).json();
  $("channel").textContent = info.channel.toUpperCase();
  $("channel").className = "channel " + info.channel;
  $("version").textContent = info.version;
  state.title = (info.channel === "dev" ? "[DEV] " : "") + "Claude Studio";
  showTitle();
};
// The chat's title in the top bar and the browser tab (FR-89); ✎ only when there is a chat to rename.
const showTitle = () => {
  $("chatTitle").textContent = state.chat ? state.chat.title : "New chat";
  $("renameChat").hidden = !state.chat || !!state.chat.removed;
  document.title = state.chat ? `${state.chat.title} · ${state.title}` : state.title;
};

const loadProjects = async () => {
  const projects = await (await api("/api/projects")).json();
  const sel = $("project");
  sel.innerHTML = "";
  state.projects = projects;
  for (const p of projects) sel.append(new Option(p, p));
  sel.value = projects.includes(store.get("project")) ? store.get("project") : "General";
  syncModeMenu(sel.value);
  updatePill();
};
// Rule counts per project, for the pill tooltip (spec project-rules FR-203).
let projectRuleCounts = {};
// The pill names the project and, when it isn't Ask before changes, the mode (spec permissions FR-123).
const updatePill = () => {
  const p = $("project").value, pill = $("projectPill");
  pill.textContent = "";
  if (p !== "General") pill.append(el("b", null, p));
  const modeText = $("mode").value === "workFreely" ? "Work freely" : $("mode").selectedOptions[0].text; // the long menu text is shortened here (trust-levels FR-251)
  if ($("mode").value !== "default") pill.append((p !== "General" ? " · " : "") + modeText);
  // The tooltip adds the project's own rule count (spec project-rules FR-203); the visible text stays as it is.
  const n = projectRuleCounts[p];
  const tip = [p, modeText, n ? `${n} project rule${n === 1 ? "" : "s"}` : ""].filter(Boolean).join(" · ") +
    ($("mode").value === "workFreely" ? ". Shell commands aren't limited to the project folder." : "");
  pill.title = tip;
  pill.setAttribute("aria-label", tip);
};
const loadRuleCounts = async () => {
  try { const r = await api("/api/permissions/projects"); if (r.ok) { projectRuleCounts = await r.json(); updatePill(); } } catch {}
};
loadRuleCounts();
addEventListener("studio-rules", loadRuleCounts); // the Permissions tab changed a project's rules
// Permission mode per project (FR-122); the old single setting becomes General's on first use.
const modeFor = (project) => store.get("modeByProject", { General: store.get("mode", "default") })[project] || "default";
// The mode menu follows the project, with the trust level rules (spec trust-levels FR-249, FR-255): Work freely needs a project,
// and Auto mode is greyed out once the server says the account can't use it. The saved choice is never overwritten by a fallback.
const MODE_HELP = { workFreely: "Edits files in this project, reads anywhere, and runs ordinary commands. Deleting, publishing and chained commands still ask." };
const autoMode = { available: null, at: 0 }; // null: not asked yet
const showModeHelp = (note) => {
  const text = note || MODE_HELP[$("mode").value] || "";
  $("modeHelp").textContent = text;
  $("modeHelp").hidden = !text;
};
const syncModeMenu = (project) => {
  const general = project === "General", noAuto = autoMode.available === false;
  const work = $("mode").querySelector('option[value="workFreely"]'), auto = $("mode").querySelector('option[value="auto"]');
  work.disabled = general;
  work.textContent = general ? "Work freely in this project (pick a project first)" : "Work freely in this project";
  auto.disabled = noAuto;
  auto.textContent = noAuto ? "Auto mode (not available on this account)" : "Auto mode";
  let value = modeFor(project), note = "";
  if (value === "workFreely" && general) { value = "default"; note = "Work freely needs a project. General is Home itself."; }
  if (value === "auto" && noAuto) { value = "default"; note = "Auto mode isn't available on this account."; }
  $("mode").value = value;
  showModeHelp(note);
};
// Asks the server once whether Auto mode works here (FR-255); a failed check never blocks the user.
const autoModeAvailable = async () => {
  if (autoMode.available === false && Date.now() - autoMode.at > 5 * 60 * 1000) autoMode.available = null;
  if (autoMode.available != null) return autoMode.available;
  $("status").textContent = "Checking Auto mode…";
  try { autoMode.available = !!(await (await api("/api/auto-mode")).json()).available; autoMode.at = Date.now(); }
  catch { return true; }
  finally { if ($("status").textContent === "Checking Auto mode…") $("status").textContent = ""; }
  syncModeMenu($("project").value);
  return autoMode.available;
};
$("project").onchange = () => {
  store.set("project", $("project").value); syncModeMenu($("project").value); updatePill(); state.role = null; loadRoles(); loadChats();
  if (!$("outputs").hidden) loadOutputs();
  // On a phone the sidebar overlay stays open, so a chat in the new project can be picked next (QA v0.5 F-4).
};

// ---------- project rail (spec look-and-feel FR-38, FR-39) ----------
// Initials: "G" for General, else the first letters of the first two words (Claude-Studio → CS); one word gives
// two letters (Weaver → WE). A clash takes the next letter of the last word.
const initialsFor = (name, taken) => {
  if (name === "General") return "G";
  const words = name.split(/[-_\s]+|(?=[A-Z][a-z])/).filter(Boolean);
  let s = (words.length > 1 ? words[0][0] + words[1][0] : name.slice(0, 2)).toUpperCase();
  const last = words.at(-1) || name;
  for (let i = 1; taken.has(s) && i < last.length; i++) s = s.slice(0, 2) + last[i].toUpperCase();
  taken.add(s);
  return s;
};
// General first, then projects by their newest chat, then by name. The highlighted avatar is the active project.
const renderRail = () => {
  const rail = $("rail");
  const names = state.projects || [...$("project").options].map((o) => o.value);
  const last = {};
  for (const c of state.allChats || []) { const p = c.project || "General"; last[p] = Math.max(last[p] || 0, c.updated || c.created || 0); }
  const order = ["General", ...names.filter((n) => n !== "General").sort((a, b) => (last[b] || 0) - (last[a] || 0) || a.localeCompare(b))];
  const active = $("project").value;
  const focused = rail.contains(document.activeElement) ? document.activeElement.dataset.project : null;
  const taken = new Set();
  rail.innerHTML = "";
  // A dot on the avatar when one of its chats is working or needs you (design reliable-chats 2).
  const known = new Set(names);
  const projOf = (c) => (c.project && known.has(c.project) ? c.project : "General");
  const busy = {};
  for (const c of state.allChats || []) {
    const p = projOf(c);
    if (c.waiting) busy[p] = "wait"; else if (c.running && busy[p] !== "wait") busy[p] = "work";
  }
  for (const name of order) {
    const o = el("div", "rail-item" + (busy[name] ? " rail-" + busy[name] : ""), initialsFor(name, taken));
    o.setAttribute("role", "option");
    o.dataset.project = name;
    const label = name + (busy[name] === "wait" ? ", needs you" : busy[name] === "work" ? ", working" : "");
    o.title = label;
    o.setAttribute("aria-label", label);
    o.setAttribute("aria-selected", String(name === active));
    o.tabIndex = (focused ? name === focused : name === active) ? 0 : -1;
    o.onclick = () => chooseProject(name);
    rail.append(o);
  }
  if (focused) [...rail.children].find((o) => o.dataset.project === focused)?.focus();
};
const chooseProject = (name) => {
  if (![...$("project").options].some((o) => o.value === name)) return;
  if ($("project").value === name) return;
  $("project").value = name;
  $("project").onchange();
};
// The rail is one Tab stop: arrows, Home and End move focus; Enter or Space chooses.
$("rail").onkeydown = (e) => {
  const items = [...$("rail").querySelectorAll(".rail-item")];
  const i = items.indexOf(document.activeElement);
  if (i < 0) return;
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); chooseProject(items[i].dataset.project); return; }
  const j = { ArrowDown: i + 1, ArrowUp: i - 1, Home: 0, End: items.length - 1 }[e.key];
  if (j == null) return;
  e.preventDefault();
  const k = (j + items.length) % items.length;
  items.forEach((x, n) => { x.tabIndex = n === k ? 0 : -1; });
  items[k].focus();
};
// ＋ New project: the v0.4 project API and name rules (FR-27); the new project becomes active.
$("newProject").onclick = () => { $("npName").value = ""; $("npError").textContent = ""; $("newProjectDialog").showModal(); $("npName").focus(); };
$("npCancel").onclick = () => $("newProjectDialog").close();
$("npForm").onsubmit = async (e) => {
  e.preventDefault();
  const r = await api("/api/projects", { method: "POST", body: JSON.stringify({ name: $("npName").value }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { $("npError").textContent = j.error || `Couldn't create the project (${r.status}).`; return; }
  $("newProjectDialog").close();
  await loadProjects();
  chooseProject(j.name);
};

// The list belongs to the selected project (spec look-and-feel FR-39/40, brought forward from v0.5).
// General also keeps chats whose project folder is gone, so no chat disappears from the list.
const inProject = (c) => {
  const project = $("project").value;
  const known = new Set([...$("project").options].map((o) => o.value));
  return project === "General" ? !c.project || c.project === "General" || !known.has(c.project) : c.project === project;
};
const loadChats = async () => {
  const chats = await (await api("/api/chats")).json();
  renderChatList(chats);
  loadBinCount();
  return chats;
};
// New results seen or arriving (away.js): redraw the sidebar markers (spec away-status FR-196).
addEventListener("studio-seen", () => { if (state.allChats) renderChatList(state.allChats); });
const renderChatList = (chats) => {
  state.allChats = chats;
  renderRail();
  if (state.listLocked) return; // a rename or menu is open; the next refresh catches up
  const list = $("chatList");
  list.innerHTML = "";
  const project = $("project").value;
  const shown = chats.filter(inProject);
  $("chatsTitle").textContent = project === "General" ? "General chats" : `${project} chats`;
  list.setAttribute("aria-label", $("chatsTitle").textContent);
  if (!shown.length) list.append(el("p", "chat-empty", project === "General" ? "No general chats yet." : `No chats in ${project} yet.`));
  for (const c of shown) {
    const a = el("a", "chat-item" + (state.chat?.id === c.id ? " active" : ""));
    a.href = "#" + c.id;
    if (state.chat?.id === c.id) a.setAttribute("aria-current", "page");
    a.append(el("span", "t", c.title));
    // Working / Needs you take the place of the project tag (FR-80); the text is always there, not only a colour.
    if (c.waiting) a.append(el("span", "state-pill wait", "Needs you"));
    else if (c.running) { const s = el("span", "state"); const d = el("span", "dot"); d.setAttribute("aria-hidden", "true"); s.append(d, "Working"); a.append(s); }
    else if (typeof awIsNew === "function" && awIsNew(c)) a.append(el("span", "state-pill new", "New")); // spec away-status FR-196
    else if (c.project && c.project !== "General" && c.project !== project) a.append(el("span", "p", c.project));
    const more = el("button", "icon-btn more", "⋯");
    more.type = "button";
    more.setAttribute("aria-label", `Chat options: ${c.title}`);
    more.setAttribute("aria-haspopup", "menu");
    more.setAttribute("aria-expanded", "false");
    more.onclick = (e) => { e.preventDefault(); e.stopPropagation(); openChatMenu(a, more, c); };
    a.append(more);
    if (!c.running) {
      const x = el("button", "x", "✕");
      x.type = "button";
      x.setAttribute("aria-label", `Move "${c.title}" to the Recycle bin`);
      x.onclick = (e) => { e.preventDefault(); e.stopPropagation(); removeChat(c); };
      a.append(x);
    }
    a.onclick = (e) => { e.preventDefault(); openChat(c); };
    list.append(a);
  }
};
// The poller (look.js) brings fresh states every few seconds while something runs (FR-80).
addEventListener("studio-chats", (e) => {
  renderChatList(e.detail);
  // Another tab started a reply in the chat on screen: follow it here too.
  const mine = e.detail.find((c) => c.id === state.chat?.id);
  if (mine?.running && !state.busy && !state.stream) attachLive(state.chat);
});

// ---------- chat menu: Rename, Move to Recycle bin (FR-87, FR-88) ----------
const closeChatMenu = () => {
  document.querySelector(".chat-menu")?.remove();
  document.querySelector('.chat-item .more[aria-expanded="true"]')?.setAttribute("aria-expanded", "false");
  state.listLocked = false;
};
const openChatMenu = (item, button, chat) => {
  const open = button.getAttribute("aria-expanded") === "true";
  closeChatMenu();
  if (open) return;
  state.listLocked = true;
  button.setAttribute("aria-expanded", "true");
  const m = el("div", "chat-menu");
  m.setAttribute("role", "menu");
  m.setAttribute("aria-label", chat.title);
  const entry = (text, onPick, { danger = false, disabled = null } = {}) => {
    const b = el("button", danger ? "danger" : "");
    b.type = "button";
    b.setAttribute("role", "menuitem");
    b.tabIndex = -1;
    b.append(el("span", null, text));
    if (disabled) { b.setAttribute("aria-disabled", "true"); b.append(el("small", null, disabled)); }
    b.onclick = (e) => { e.preventDefault(); e.stopPropagation(); if (disabled) return; closeChatMenu(); onPick(); };
    m.append(b);
    return b;
  };
  entry("✎ Rename", () => renameInList(chat));
  entry("🗑 Move to Recycle bin", () => removeChat(chat), { danger: true, disabled: chat.running ? "Stop it first" : null });
  m.onkeydown = (e) => {
    const items = [...m.querySelectorAll("[role=menuitem]")];
    const i = items.indexOf(document.activeElement);
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); items[(i + (e.key === "ArrowDown" ? 1 : items.length - 1)) % items.length].focus(); }
    else if (e.key === "Escape" || e.key === "Tab") { e.preventDefault(); closeChatMenu(); button.focus(); }
  };
  item.append(m);
  m.querySelector("[role=menuitem]").focus();
};
addEventListener("pointerdown", (e) => { if (!e.target.closest(".chat-menu, .chat-item .more")) closeChatMenu(); });

const saveTitle = async (chat, title) => {
  const r = await api("/api/chats/" + chat.id, { method: "PATCH", body: JSON.stringify({ title }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) return j.error || "Couldn't rename the chat.";
  if (state.chat?.id === chat.id) { state.chat.title = j.title; showTitle(); }
  return null;
};
// Rename in place: Enter or leaving the field saves, Esc cancels; a bad title keeps the field open with the reason.
const titleField = (input, chat, { onDone, errorAfter }) => {
  let done = false;
  const err = el("p", "field-error");
  err.id = "renameError";
  input.setAttribute("aria-label", "Chat title");
  input.setAttribute("aria-describedby", err.id);
  input.maxLength = 200;
  const finish = async (save) => {
    if (done) return;
    const title = input.value.trim();
    if (save && title !== chat.title) {
      const problem = !title || title.length > 120 ? "Use 1 to 120 characters." : await saveTitle(chat, title);
      if (problem) { err.textContent = problem; if (!err.isConnected) errorAfter(err); input.focus(); return; }
    }
    done = true;
    err.remove();
    onDone();
  };
  input.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); finish(true); } else if (e.key === "Escape") { e.preventDefault(); finish(false); } };
  input.onblur = () => setTimeout(() => { if (!done && document.activeElement !== input) finish(true); }, 0);
  input.focus();
  input.select();
};
const renameInList = (chat) => {
  const item = [...$("chatList").querySelectorAll(".chat-item")].find((a) => a.getAttribute("href") === "#" + chat.id);
  if (!item) return;
  state.listLocked = true;
  const input = el("input", "rename");
  input.value = chat.title;
  item.replaceChildren(input);
  item.onclick = (e) => e.preventDefault();
  titleField(input, chat, { errorAfter: (err) => item.after(err), onDone: () => { state.listLocked = false; loadChats(); } });
};
const renameInTopbar = () => {
  if (!state.chat || state.chat.removed) return;
  const h = $("chatTitle");
  const input = el("input", "title-edit");
  input.value = state.chat.title;
  h.hidden = true;
  $("renameChat").hidden = true;
  h.after(input);
  titleField(input, state.chat, { errorAfter: (err) => input.after(err), onDone: () => { input.remove(); h.hidden = false; showTitle(); loadChats(); } });
};
$("renameChat").onclick = renameInTopbar;
$("chatTitle").ondblclick = renameInTopbar;

// ---------- Recycle bin (FR-82 to FR-86) ----------
const removeChat = async (chat) => {
  if (!confirm(`Move “${chat.title}” to the Recycle bin? You can restore it for 30 days.`)) return;
  const r = await api("/api/chats/" + chat.id, { method: "DELETE" });
  if (r.status === 409) { addNotice("warn", "Not moved.", (await r.json().catch(() => ({}))).error || "Stop it first."); return; }
  if (state.chat?.id === chat.id) newChat();
  loadChats();
};
const daysLeft = (removed) => Math.max(0, Math.ceil((removed + 30 * 86400000 - Date.now()) / 86400000));
const leftText = (removed) => { const d = daysLeft(removed); return d < 1 ? "less than a day left" : d === 1 ? "1 day left" : `${d} days left`; };
const loadBin = async () => { try { const r = await api("/api/chats?removed=1"); return r.ok ? await r.json() : []; } catch { return []; } };
const loadBinCount = async () => { const n = (await loadBin()).length; $("openBin").textContent = n ? `🗑 Recycle bin · ${n}` : "🗑 Recycle bin"; };
const confirmDanger = (title, text) => new Promise((resolve) => {
  const d = $("confirmDelete");
  $("cdTitle").textContent = title;
  $("cdText").textContent = text;
  d.returnValue = "";
  d.onclose = () => resolve(d.returnValue === "ok");
  d.showModal();
  d.querySelector('[value="cancel"]').focus();
});
const deleteForever = async (chat) => {
  if (!await confirmDanger(`Delete “${chat.title}” forever?`, "This removes the chat, its history and Claude Code's session file. It can't be undone.")) return false;
  await api(`/api/chats/${chat.id}?forever=1`, { method: "DELETE" });
  if (state.chat?.id === chat.id) newChat();
  if (state.binMode) renderBin();
  loadBinCount();
  return true;
};
const restoreChat = async (chat) => {
  const r = await api(`/api/chats/${chat.id}/restore`, { method: "POST" });
  if (!r.ok) return;
  const restored = await r.json();
  if (state.chat?.id === chat.id) { state.chat = restored; showBinBanner(); showTitle(); $("status").textContent = "Restored."; }
  if (state.binMode) renderBin();
  loadChats();
};
const setBinMode = (on) => {
  state.binMode = on;
  $("binView").hidden = !on;
  $("chatList").hidden = on;
  $("chatsTitle").hidden = on;
  $("newChat").hidden = on;
  $("openBin").hidden = on;
  if (on) { renderBin(); $("closeBin").focus(); } else { loadChats(); $("openBin").focus(); }
};
const renderBin = async () => {
  const all = await loadBin();
  const shown = $("binAll").checked ? all : all.filter(inProject);
  shown.sort((a, b) => b.removed - a.removed);
  const list = $("binList");
  list.innerHTML = "";
  $("emptyBin").hidden = !all.length;
  if (!shown.length) list.append(el("p", "chat-empty", all.length ? "No removed chats in this project. Tick “Show all projects” to see the rest." : "Recycle bin is empty. Removed chats stay here for 30 days."));
  for (const c of shown) {
    const row = el("div", "bin-item" + (state.chat?.id === c.id ? " active" : ""));
    row.setAttribute("role", "listitem");
    const open = el("button", "t", c.title);
    open.type = "button";
    open.title = "Open to check it (read-only)";
    open.onclick = () => openChat(c);
    const restore = el("button", "icon-btn", "↺");
    restore.type = "button";
    restore.setAttribute("aria-label", `Restore ${c.title}`);
    restore.title = "Restore";
    restore.onclick = () => restoreChat(c);
    const del = el("button", "icon-btn del", "🗑");
    del.type = "button";
    del.setAttribute("aria-label", `Delete ${c.title} forever`);
    del.title = "Delete forever";
    del.onclick = () => deleteForever(c);
    const sub = el("span", "sub", `${c.project || "General"} · removed ${ago(c.removed)} · `);
    sub.append(el("span", "left" + (daysLeft(c.removed) <= 3 ? " soon" : ""), leftText(c.removed)));
    row.append(open, restore, del, sub);
    list.append(row);
  }
};
$("openBin").onclick = () => setBinMode(true);
$("closeBin").onclick = () => setBinMode(false);
$("binView").onkeydown = (e) => { if (e.key === "Escape" && !document.querySelector("dialog[open]")) { e.preventDefault(); setBinMode(false); } };
$("binAll").onchange = renderBin;
$("emptyBin").onclick = async () => {
  const n = (await loadBin()).length;
  if (!n || !await confirmDanger(`Delete ${n} chat${n === 1 ? "" : "s"} forever?`, "This removes them, their history and Claude Code's session files. It can't be undone.")) return;
  await api("/api/chats?removed=1", { method: "DELETE" });
  if (state.chat?.removed) newChat();
  renderBin();
  loadBinCount();
};
// A removed chat opens read-only: the banner takes the composer's place (FR-83).
const showBinBanner = () => {
  const removed = !!state.chat?.removed;
  $("composer").classList.toggle("in-bin", removed);
  $("binBanner").hidden = !removed;
  if (removed) $("binLeft").textContent = leftText(state.chat.removed);
};
$("binRestore").onclick = () => state.chat && restoreChat(state.chat);
$("binDelete").onclick = () => state.chat && deleteForever(state.chat);

const emptyState = $("empty");
const resetConversation = () => {
  $("messages").innerHTML = "";
  state.run = null; state.userMeta = null; state.typing = null;
  state.tools.clear(); state.streamed.clear(); state.cmdBlock = null; state.cards.clear();
  state.follow = true; state.newCount = 0; state.needsYou = false;
  updateJump();
};
// Leaving a chat only stops this tab from following its reply; the turn keeps running on the server (FR-65).
const detach = () => {
  if (state.stream) { state.stream.abort(); state.stream = null; }
  if (state.busy) setBusy(false);
  state.turnId = null;
};
const setChat = (chat) => {
  state.chat = chat;
  studioView.chatId = chat?.id || null;
  heartbeat();
  showTitle();
  showBinBanner();
};
const newChat = (fromHistory) => {
  detach();
  setChat(null);
  resetConversation();
  $("messages").append(emptyState);
  if (fromHistory !== true && location.hash) history.pushState(null, "", location.pathname);
  loadChats();
  $("input").focus();
};
$("newChat").onclick = () => newChat();

// A chat id from the list or, failing that, the Recycle bin (for links and Back/Forward to a removed chat).
const findChat = async (id) => (await loadChats()).find((c) => c.id === id) || (await loadBin()).find((c) => c.id === id);

const openChat = async (chat, fromHistory) => {
  detach();
  setChat(chat);
  if (chat.project && [...$("project").options].some((o) => o.value === chat.project)) {
    $("project").value = chat.project; updatePill(); loadRoles(); if (!$("outputs").hidden) loadOutputs();
  }
  // Each opened chat is a history entry, so Back and Forward move between chats (FR-45a).
  if (fromHistory !== true && location.hash !== "#" + chat.id) history.pushState(null, "", "#" + chat.id);
  $("sidebar").classList.remove("open");
  if (state.binMode) renderBin(); else loadChats();
  resetConversation();
  const box = $("messages");
  const loading = el("div", "meta", "Loading…");
  box.append(loading);
  const res = await api(`/api/chats/${chat.id}/messages`);
  loading.remove();
  if (state.chat?.id !== chat.id) return; // another chat was opened meanwhile
  if (!res.ok) { addNotice("err", "Couldn't load this chat.", "Its history could not be read."); return; }
  for (const m of await res.json()) renderStored(m);
  closeRun();
  scrollDown(true);
  if (typeof awayOpened === "function") awayOpened(chat); // "Finished while you were away" (spec away-status FR-194)
  // A chat that is still working is rejoined live (FR-70).
  if (!chat.removed) attachLive(chat);
};

// ---------- auto-scroll and Jump to latest (spec reliable-chats X) ----------
// Following keeps the newest line in view. Scrolling up by hand pauses it; coming back near the bottom resumes it.
const followSetting = () => store.get("followReply", true);
const nearBottom = () => { const b = $("messages"); return b.scrollHeight - b.scrollTop - b.clientHeight <= 80; };
let lastTop = 0;
const scrollDown = (force) => {
  const box = $("messages");
  if (force) state.follow = true;
  if (force || (state.follow && followSetting())) { box.scrollTop = box.scrollHeight; lastTop = box.scrollTop; }
  updateJump();
};
// Something new arrived below the view (a bubble, a command, a card): count it for the ↓ button.
const noteNew = (card = false) => {
  if (state.follow && followSetting()) return;
  if (card) state.needsYou = true; else state.newCount++;
};
const updateJump = () => {
  const j = $("jump");
  const away = $("messages").scrollHeight - $("messages").scrollTop - $("messages").clientHeight > 80;
  if (!away) { state.newCount = 0; state.needsYou = false; }
  j.hidden = !away;
  if (!away) return;
  j.classList.toggle("wait", state.needsYou);
  j.replaceChildren("↓");
  if (state.needsYou) j.append(" Needs you");
  else if (state.newCount) j.append(el("span", "n", String(state.newCount)));
  j.setAttribute("aria-label", "Jump to latest" + (state.needsYou ? ", Claude needs you" : state.newCount ? `, ${state.newCount} new message${state.newCount === 1 ? "" : "s"}` : ""));
};
const jumpToLatest = () => {
  const box = $("messages");
  state.follow = true;
  box.scrollTo({ top: box.scrollHeight, behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
};
$("jump").onclick = jumpToLatest;
$("messages").addEventListener("scroll", () => {
  const box = $("messages");
  if (nearBottom()) state.follow = true;
  else if (box.scrollTop < lastTop - 2) state.follow = false; // moved up by the user; growing content never moves it up
  lastTop = box.scrollTop;
  updateJump();
}, { passive: true });
$("messages").addEventListener("keydown", (e) => { if (e.key === "End" && e.target === $("messages")) { e.preventDefault(); jumpToLatest(); } });
// A run is a group of consecutive bubbles from one side; corners and the avatar follow its first/last bubble.
const runFor = (side) => {
  if (state.run?.side === side) return state.run;
  emptyState.remove();
  const node = el("div", "run " + side);
  node.setAttribute("role", "list");
  $("messages").append(node);
  state.run = { side, node };
  return state.run;
};
const closeRun = () => { state.run = null; };
const regroup = (run) => {
  const rows = [...run.node.querySelectorAll(":scope > .brow")];
  rows.forEach((r, i) => {
    r.classList.remove("first", "mid", "last", "has-face");
    if (rows.length > 1) r.classList.add(i === 0 ? "first" : i === rows.length - 1 ? "last" : "mid");
  });
  if (run.side === "them" && rows.length) rows[rows.length - 1].classList.add("has-face");
};
const addBubble = (side, { cls = "", role } = {}) => {
  const run = runFor(side);
  const row = el("div", "brow");
  row.setAttribute("role", "listitem");
  if (side === "them") { const f = el("span", "face", "C"); f.setAttribute("aria-hidden", "true"); row.append(f); }
  const bubble = el("div", "bubble " + cls);
  if (role) bubble.setAttribute("role", role);
  bubble.append(el("span", "sr", side === "me" ? "You: " : "Claude: "));
  row.append(bubble);
  // Keep the typing indicator last in Claude's run.
  if (state.typing && state.typing.parentNode === run.node && side === "them") run.node.insertBefore(row, state.typing); else run.node.append(row);
  regroup(run);
  if (side === "them") noteNew();
  scrollDown();
  return bubble;
};
const addMeta = (side, text, cls = "") => {
  const m = el("div", "meta " + (side === "me" ? "me " : "") + cls, text);
  $("messages").append(m);
  closeRun();
  return m;
};

// Slash commands look like the terminal: a "❯ /command" line, then the command's own output after "⎿".
// track: false keeps a side block (/btw) from catching the output of the command that is running.
const addCommand = (text, { track = true, cls = "" } = {}) => {
  closeRun();
  if (track) hideTyping();
  emptyState.remove();
  const box = el("div", "cmd-block " + cls);
  box.setAttribute("role", "group");
  box.setAttribute("aria-label", "Command " + text.split(/\s/)[0]);
  box.append(el("div", "cmd-line", text));
  $("messages").append(box);
  if (track) state.cmdBlock = box;
  noteNew();
  scrollDown(); // a command you type is brought into view by send(); others don't pull the view down (FR-96)
  return box;
};
const addCommandOutput = (raw, { box = null, markdown = false } = {}) => {
  const s = String(raw || "");
  const text = s.replace(/<\/?local-command-(stdout|stderr)>/g, "").trim() || "(no output)";
  const target = box || state.cmdBlock || addCommand("/command");
  if (!box) hideTyping();
  const out = el("div", "cmd-out" + (/<local-command-stderr>/.test(s) ? " err" : ""));
  const elbow = el("span", "cmd-elbow", "⎿"); elbow.setAttribute("aria-hidden", "true");
  // Some commands answer in Markdown (/context: headings and tables); render those, keep the rest as terminal text (QA F-6).
  const looksMarkdown = /^#{1,6} /m.test(text) || /^\|.*\|\s*\n\|[\s:|-]+\|/m.test(text);
  let body;
  // Claude's own Markdown (/btw) is rendered as written; command output keeps its Windows paths' backslashes.
  if (markdown || looksMarkdown) { body = el("div", "md cmd-md"); body.innerHTML = md(markdown ? text : keepBackslashes(text)); } else body = terminalText(text);
  out.append(elbow, body);
  target.append(out);
  scrollDown();
  return out;
};

const addUser = (text, roleLabel) => {
  closeRun();
  state.cmdBlock = null;
  const b = addBubble("me");
  b.append(document.createTextNode(text));
  if (roleLabel) b.append(el("span", "role-tag", roleLabel));
  return b;
};
const addAssistantText = (text = "") => {
  const b = addBubble("them", { cls: "md" });
  const body = el("div");
  b.append(body);
  const block = { raw: text, body, timer: null };
  body.innerHTML = md(text);
  return block;
};
const renderText = (block) => {
  if (block.timer) return;
  block.timer = setTimeout(() => { block.timer = null; block.body.innerHTML = md(block.raw); scrollDown(); }, 50);
};
// Errors and refused messages as Claude bubbles with a tone edge (FR-12).
const addNotice = (tone, title, text) => {
  hideTyping();
  const b = addBubble("them", { cls: "tone-" + tone, role: tone === "err" ? "alert" : "status" });
  b.append(el("strong", null, title + " "), document.createTextNode(text));
  scrollDown(); // no forced jump while reading further up (FR-96)
  return b;
};

const showTyping = () => {
  if (state.typing) return;
  const run = runFor("them");
  const row = el("div", "brow");
  const f = el("span", "face", "C"); f.setAttribute("aria-hidden", "true");
  const b = el("div", "bubble typing");
  b.setAttribute("aria-label", "Claude is typing");
  b.setAttribute("role", "status");
  b.append(el("i"), el("i"), el("i"));
  row.append(f, b);
  run.node.append(row);
  state.typing = row;
  regroup(run);
  scrollDown();
};
const hideTyping = () => {
  if (!state.typing) return;
  const parent = state.typing.parentNode;
  state.typing.remove();
  state.typing = null;
  if (parent && state.run?.node === parent) regroup(state.run);
};

// Tool calls as chips between Claude's bubbles; more than 4 in a row collapse to "N steps" (FR-9).
const toolArg = (input = {}) => String(input.file_path || input.path || input.command || input.pattern || input.url || input.query || input.description || input.skill || input.prompt || "").split("\n")[0].slice(0, 160);
const addTool = (block) => {
  if (block.name === "AskUserQuestion") return;
  const run = runFor("them");
  let steps = run.node.lastElementChild;
  if (state.typing && steps === state.typing) steps = state.typing.previousElementSibling;
  if (!steps?.classList.contains("steps")) {
    steps = el("div", "steps");
    steps.setAttribute("aria-label", "Claude's steps");
    if (state.typing?.parentNode === run.node) run.node.insertBefore(steps, state.typing); else run.node.append(steps);
  }
  const chip = el("span", "chip-tool");
  const dot = el("span", "dot"); dot.setAttribute("aria-hidden", "true");
  chip.append(dot, el("b", null, block.name), el("span", "arg", toolArg(block.input)));
  steps.append(chip);
  state.tools.set(block.id, chip);
  const chips = steps.querySelectorAll(".chip-tool");
  if (chips.length > 4) {
    let toggle = steps.querySelector(".step-toggle");
    if (!toggle) {
      toggle = el("button", "step-toggle");
      toggle.type = "button";
      toggle.onclick = () => { steps.classList.toggle("collapsed"); toggle.setAttribute("aria-expanded", String(!steps.classList.contains("collapsed"))); label(); };
      steps.prepend(toggle);
      steps.classList.add("collapsed");
      toggle.setAttribute("aria-expanded", "false");
    }
    const label = () => { toggle.textContent = `${steps.querySelectorAll(".chip-tool").length} steps ${steps.classList.contains("collapsed") ? "▸" : "▾"}`; };
    label();
  }
  scrollDown();
};
const finishTool = (result) => {
  const chip = state.tools.get(result.tool_use_id);
  if (chip) chip.classList.add(result.is_error ? "failed" : "done");
};

const userText = (content) => typeof content === "string" ? content
  : Array.isArray(content) ? content.filter((b) => b.type === "text").map((b) => b.text).join("\n") : "";
const roleLabelFor = (skill) => state.roles.chips.find((c) => c.skill === skill)?.label || skill;

// Stored history from Claude Code's session file (FR-15). Injected context and skill instructions are hidden.
const renderStored = (m) => {
  // The turn record merged in by the server (FR-77): settled cards and end-of-turn lines.
  if (m.type === "studio") {
    // Allowed without a card (for a reply, by the trust level, or as bookkeeping): the muted line, not a card (QA v0.19 F-3).
    if (m.kind === "card" && ["reply", "level", "bookkeeping"].includes(m.settled?.by)) {
      addAutoAllow(String(m.settled.file || m.card.input?.command || m.card.input?.file_path || m.card.input?.url || m.card.toolName), m.settled.by);
    } else if (m.kind === "card") showCard({ ...m.card }, { readOnly: true, settled: m.settled || { outcome: "deny", by: "cancelled", reason: "closed" } });
    else if (m.kind === "end") addEndLine(m.end);
    return;
  }
  if (m.parent_tool_use_id) return;
  const content = m.message?.content;
  if (m.type === "user") {
    if (Array.isArray(content)) content.filter((b) => b.type === "tool_result").forEach(finishTool);
    let text = userText(content).trim();
    if (!text) return;
    const cmd = text.match(/<command-name>\/?([^<]+)<\/command-name>/);
    if (cmd) {
      const args = ((text.match(/<command-args>([\s\S]*?)<\/command-args>/) || [])[1] || "").trim();
      // A role chip's message stays a bubble with its label; any other command shows as a terminal line.
      if (args && state.roles.chips.some((c) => c.skill === cmd[1])) addUser(args, roleLabelFor(cmd[1]));
      else addCommand(("/" + cmd[1] + " " + args).trim());
      return;
    }
    const custom = text.match(/^<studio-role label="([^"]*)">[\s\S]*?<\/studio-role>\s*([\s\S]*)$/);
    if (custom) { addUser(custom[2], custom[1]); return; }
    if (/^</.test(text) || /^Base directory for this skill:/.test(text)) return;
    addUser(text);
  } else if (m.type === "system" && m.subtype === "local_command") {
    addCommandOutput(m.content);
  } else if (m.type === "assistant" && Array.isArray(content)) {
    for (const b of content) {
      if (b.type === "text" && b.text.trim()) addAssistantText(b.text);
      else if (b.type === "tool_use") addTool(b);
    }
  }
};

// Live SDK messages.
const markSeen = () => {
  if (state.seen || !state.userMeta) return;
  state.seen = true;
  state.userMeta.textContent += " · Seen";
};
const handleSdk = (msg) => {
  if (msg.parent_tool_use_id) return; // subagent internals stay hidden
  if (msg.type === "stream_event") {
    const ev = msg.event;
    if (ev.type === "message_start" && ev.message?.id) { state.streamed.add(ev.message.id); markSeen(); }
    else if (ev.type === "content_block_start" && ev.content_block?.type === "text") { hideTyping(); state.currentText = addAssistantText(""); }
    else if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta" && state.currentText) {
      state.currentText.raw += ev.delta.text;
      renderText(state.currentText);
    } else if (ev.type === "content_block_stop") state.currentText = null;
  } else if (msg.type === "system" && msg.subtype === "local_command_output") {
    addCommandOutput(msg.content);
  } else if (msg.type === "assistant" && (msg.local_command_source || (msg.message?.model === "<synthetic>" && state.cmdBlock && !msg.error))) {
    // A command Claude Code ran itself (no model call): its printed output, terminal-style.
    markSeen();
    addCommandOutput(msg.local_command_source || userText(msg.message?.content));
  } else if (msg.type === "assistant") {
    markSeen();
    // Text that never streamed (for example a synthetic error message) is shown whole.
    const streamed = state.streamed.has(msg.message?.id);
    for (const b of msg.message?.content || []) {
      if (b.type === "tool_use") addTool(b);
      else if (b.type === "text" && !streamed && b.text.trim()) { hideTyping(); addAssistantText(b.text); }
    }
    if (msg.error) addNotice("err", "Couldn't reply.", API_ERRORS[msg.error] || `Something went wrong (${msg.error}).`);
  } else if (msg.type === "user") {
    const c = msg.message?.content;
    if (Array.isArray(c)) c.filter((b) => b.type === "tool_result").forEach(finishTool);
  } else if (msg.type === "result") {
    hideTyping();
    const secs = Math.round((msg.duration_ms || 0) / 1000);
    const cost = msg.total_cost_usd != null ? ` · $${msg.total_cost_usd.toFixed(3)}` : "";
    const failed = msg.is_error || msg.subtype !== "success";
    addMeta("them", `${failed ? "Stopped · " + (RESULT_REASONS[msg.subtype] || "Error") : clock()} · ${secs}s${cost}`, failed ? "error" : "");
    const detail = failed && msg.errors?.[0];
    if (detail) {
      const d = el("div", "meta-detail", detail.length > 300 ? detail.slice(0, 300) + "…" : detail);
      d.title = detail;
      $("messages").append(d);
    }
    scrollDown();
  }
};

// End of a saved turn, the same line as live (FR-77): time · seconds · cost, or why it stopped.
const timeOf = (ms) => new Date(ms).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
const addEndLine = (end) => {
  closeRun();
  const secs = end.durationMs != null ? ` · ${Math.round(end.durationMs / 1000)}s` : "";
  const cost = end.costUsd != null ? ` · $${end.costUsd.toFixed(3)}` : "";
  if (end.status === "done") addMeta("them", `${timeOf(end.at)}${secs}${cost}`);
  else if (end.status === "interrupted") addMeta("them", "Stopped · Studio closed before this reply finished", "warn");
  else if (end.status === "stopped") addMeta("them", `Stopped${secs}${cost}`, "error");
  else addMeta("them", `Stopped · ${RESULT_REASONS[end.reason] || "Error"}${secs}${cost}`, "error");
};

// ---------- permission prompts and questions as quick replies (FR-10, FR-11; reliable-chats R) ----------
// Every card is kept by request id so its outcome can be shown when it is settled here, in another tab,
// by the 30-minute limit, or by Stop. History cards are drawn by the same code, read-only (design D-3).
const answer = (requestId, body) => api(`/api/turn/${state.turnId}/permission/${requestId}`, { method: "POST", body: JSON.stringify(body) });
const showCard = (ev, opts = {}) => (ev.toolName === "AskUserQuestion" ? showQuestions(ev, opts) : showPermission(ev, opts));
const outcomeText = (card, s) => {
  if (s.outcome === "allow") return "Allowed";
  if (s.outcome === "always") return s.rule ? `${s.where === "chat" ? "Allowed for this chat" : s.where === "project" ? `Always allowed in ${s.project}` : "Always allowed"} · ${s.rule}` : "Always allowed";
  if (s.outcome === "reply") return `Allowed for this reply · ${String(card.ev.input?.command || card.ev.toolName).split(/\s+/).slice(0, 2).join(" ")} …`;
  if (s.outcome === "answered") return Object.values(s.answers || {}).join(" · ");
  return /skipped/i.test(s.message || "") ? "Skipped" : "Denied";
};
// Pressing a pill sends the answer; the outcome is drawn when the server says the card is settled.
const sendAnswer = async (card, body) => {
  card.groups.forEach((g) => g.querySelectorAll("button, input").forEach((x) => (x.disabled = true)));
  card.mine = true;
  let r = null;
  try { r = await answer(card.ev.requestId, body); } catch {}
  if (r?.status === 404) {
    card.mine = false; // someone else (another tab, the time limit, Stop) settled it first
    if (card.done && card.answerShown) addMeta("me", "in another tab");
  } else if (!r?.ok) {
    card.mine = false;
    card.groups.forEach((g) => g.querySelectorAll("button, input").forEach((x) => (x.disabled = false)));
    if (r) addNotice("warn", "Answer not sent.", (await r.json().catch(() => ({}))).error || `Request failed (${r.status})`);
  }
};
const settleCard = (card, s, { live = false } = {}) => {
  if (card.done) return;
  card.done = true;
  card.timer?.remove();
  if (card.needsYou) { state.needsYou = false; updateJump(); }
  if (s.by === "user") {
    card.groups.slice(0, -1).forEach((g) => g.remove());
    showAnswer(card.groups.at(-1) || null, outcomeText(card, s));
    card.answerShown = true;
    if (live && !card.mine) addMeta("me", "in another tab");
  } else {
    card.groups.forEach((g) => g.remove());
    closeRun();
    if (s.by === "timeout") addMeta("them", "Declined · no answer within 30 minutes", "warn");
    else addMeta("them", s.reason === "closed" ? "Cancelled · Studio closed" : "Cancelled");
  }
  if (live && state.busy) showTyping();
};
// FR-74: in the last 5 minutes a waiting card says when it will be declined; the last minute is announced once.
const updateTimers = () => {
  for (const card of state.cards.values()) {
    if (card.done || !card.ev.expiresAt) continue;
    const left = card.ev.expiresAt - Date.now();
    if (left > 5 * 60000) continue;
    if (!card.timer) { card.timer = el("div", "card-timer"); card.groups.at(-1)?.append(card.timer); }
    const last = left < 60000;
    if (last && !card.timer.getAttribute("role")) card.timer.setAttribute("role", "status");
    card.timer.textContent = last ? "⏳ Declines in under a minute…" : `⏳ Declines in ${Math.ceil(left / 60000)} min if there's no answer`;
  }
};
setInterval(updateTimers, 15000);
const quickGroup = (label) => {
  const run = runFor("them");
  const g = el("div", "quick");
  g.setAttribute("role", "group");
  g.setAttribute("aria-label", label);
  run.node.append(g);
  return g;
};
const pill = (text, cls = "") => { const b = el("button", "qr " + cls, text); b.type = "button"; return b; };
// After an answer the pills go away and the answer shows as a small bubble on the user's side.
const showAnswer = (group, text) => {
  group?.remove();
  closeRun();
  const b = addBubble("me");
  b.parentNode.parentNode.classList.add("answer");
  b.append(document.createTextNode(text));
  closeRun();
};

// A card registered so FR-71 outcomes can reach it; live cards may need the ↓ "Needs you" button.
const registerCard = (ev, groups, readOnly) => {
  const card = { ev, groups, mine: false, done: false, timer: null, needsYou: false };
  if (!readOnly) {
    state.cards.set(ev.requestId, card);
    if (!(state.follow && followSetting())) { card.needsYou = true; noteNew(true); }
    updateTimers();
  }
  scrollDown();
  return card;
};
const showPermission = (ev, { readOnly = false, settled = null } = {}) => {
  if (!readOnly) markSeen();
  hideTyping();
  const b = addBubble("them");
  b.append(el("strong", null, `Allow ${ev.toolName}?`));
  if (ev.decisionReason) b.append(el("div", "reason", ev.decisionReason));
  const detail = ev.input?.command || ev.input?.file_path || ev.input?.url || JSON.stringify(ev.input, null, 2);
  b.append(el("div", "detail", String(detail).slice(0, 4000)));
  if (ev.input?.description) b.append(el("div", "reason", ev.input.description));
  const g = quickGroup("Permission");
  const card = registerCard(ev, [g], readOnly);
  if (readOnly) return settleCard(card, settled);
  const allow = pill("Allow", "primary"); allow.onclick = () => sendAnswer(card, { decision: "allow" });
  g.append(allow);
  // Allow for this reply (spec permissions FR-124): never offered for risky actions, which it couldn't cover.
  if (!ev.risky) { const reply = pill("Allow for this reply"); reply.onclick = () => sendAnswer(card, { decision: "reply" }); g.append(reply); }
  if (ev.canAlwaysAllow) {
    const always = pill("Always allow…");
    always.setAttribute("aria-expanded", "false");
    always.onclick = () => toggleRuleEditor(card, always);
    g.append(always);
  }
  const deny = pill("Deny", "ghost"); deny.onclick = () => sendAnswer(card, { decision: "deny" });
  g.append(deny);
  if (state.follow) allow.focus({ preventScroll: true });
};
// The rule editor under a card (FR-111 to FR-114): the suggested pattern or the exact rule, editable, saved for
// this chat or in Home's local settings. It joins the card's groups, so it goes away when the card is settled.
const toggleRuleEditor = (card, button) => {
  if (card.editor) { card.editor.remove(); card.groups = card.groups.filter((x) => x !== card.editor); card.editor = null; button.setAttribute("aria-expanded", "false"); return; }
  const ev = card.ev;
  const box = el("div", "rule-editor");
  box.id = "rule-" + ev.requestId;
  box.setAttribute("role", "group");
  box.setAttribute("aria-label", "Always allow rule");
  button.setAttribute("aria-controls", box.id);
  button.setAttribute("aria-expanded", "true");
  box.append(el("h4", null, "Always allow"));
  if (ev.risky) {
    const warn = el("div", "rule-warn");
    warn.setAttribute("role", "alert");
    warn.append(el("b", null, "⚠ This can delete or publish things."), " Saving a pattern would allow it everywhere.");
    box.append(warn);
  }
  // The pattern for an inline Node script allows any such script, so the card says so (spec trust-levels FR-259).
  if (!ev.risky && /^(Bash|PowerShell)\(node -e /.test(ev.suggestedRule || "")) {
    const warn = el("div", "rule-warn");
    warn.append(el("b", null, "⚠ This allows any inline Node script."), " A script can read, change or delete files, so save it only where you trust every chat.");
    box.append(warn);
  }
  // A command no rule could match again (long, several steps, a date or id): a note and an empty field instead of a rule that
  // would fail, with Allow once inside the editor (spec trust-levels FR-258).
  if (ev.noMatch) {
    box.classList.add("nomatch");
    const note = el("div", "rule-note");
    const icon = el("span", "i", "ⓘ"); icon.setAttribute("aria-hidden", "true");
    note.append(icon, el("span", null, "This is several steps in one command, so a rule can't match it again. Allow it once, or ask Claude to use the Edit tool or a file on the bookkeeping list (Settings → Permissions)."));
    box.append(note);
  }
  const field = el("label", "field");
  const input = el("input");
  input.value = ev.noMatch ? "" : ev.risky ? ev.exactRule : ev.suggestedRule;
  if (ev.noMatch) input.placeholder = "Write a rule, e.g. Bash(npm test *)";
  input.spellcheck = false;
  input.autocomplete = "off";
  field.append(el("span", null, "Rule"), input);
  const error = el("div", "field-error");
  error.hidden = true;
  box.append(field, error);
  // Pattern / Exact fill the field; typing clears both.
  const toggles = [];
  if (ev.suggestedRule !== ev.exactRule) {
    const pick = el("div", "rule-pick");
    pick.append("Use:");
    for (const [label, value] of [["Pattern", ev.suggestedRule], ["Exact", ev.exactRule]]) {
      const t = pill(label);
      t.setAttribute("aria-pressed", String(input.value === value));
      t.onclick = () => { input.value = value; toggles.forEach(([b, v]) => b.setAttribute("aria-pressed", String(v === value))); input.focus(); };
      toggles.push([t, value]);
      pick.append(t);
    }
    box.append(pick);
  }
  input.oninput = () => {
    toggles.forEach(([b, v]) => b.setAttribute("aria-pressed", String(input.value === v)));
    error.hidden = true; input.removeAttribute("aria-invalid");
    if (ev.noMatch) { const typed = !!input.value.trim(); save.setAttribute("aria-disabled", String(!typed)); box.classList.toggle("nomatch", !typed); }
  };
  const where = el("fieldset", "where");
  where.append(el("legend", null, "Where:"));
  const seg = el("span", "seg");
  const hint = el("p", "hint");
  const homeHint = "Saved to Home's local settings (.claude\\settings.local.json) · also applies in the terminal and LIVE";
  // In a project chat: This chat · This project · All of Home, with This project first (spec project-rules FR-201).
  // General keeps today's two choices with Home first (design project-rules §2).
  const project = state.chat?.project && state.chat.project !== "General" ? state.chat.project : null;
  const hints = { home: homeHint, chat: "Only for this chat",
    project: `Saved to projects\\${project}\\.claude\\settings.local.json · ${project} chats only, on DEV and LIVE, and in a terminal opened there` };
  const choices = project ? [["chat", "This chat"], ["project", `This project · ${project}`], ["home", "All of Home"]] : [["home", "Always, in Home"], ["chat", "This chat"]];
  const first = project ? "project" : "home";
  hint.id = "where-hint-" + ev.requestId;
  for (const [value, label] of choices) {
    const l = el("label");
    const r = el("input");
    r.type = "radio"; r.name = "where-" + ev.requestId; r.value = value; r.checked = value === first;
    r.setAttribute("aria-describedby", hint.id);
    r.onchange = () => { hint.textContent = hints[value]; };
    l.append(r, " " + label);
    seg.append(l);
  }
  where.append(seg);
  hint.textContent = hints[first];
  const actions = el("div", "rule-actions");
  const cancel = el("button", "btn ghost", "Cancel"); cancel.type = "button";
  const save = el("button", ev.noMatch ? "btn" : "btn primary", "Allow and save"); save.type = "button";
  if (ev.noMatch) save.setAttribute("aria-disabled", "true");
  actions.append(cancel, save);
  if (ev.noMatch) {
    const once = el("button", "btn primary", "Allow once"); once.type = "button";
    once.onclick = () => sendAnswer(card, { decision: "allow" });
    actions.append(once);
    queueMicrotask(() => once.focus());
  }
  box.append(where, hint, actions);
  cancel.onclick = () => { toggleRuleEditor(card, button); button.focus(); };
  const submit = async () => {
    const rule = input.value.trim();
    if (save.getAttribute("aria-disabled") === "true") return;
    const problem = ruleProblem(rule);
    if (problem) { setRuleError(error, problem); error.hidden = false; input.setAttribute("aria-invalid", "true"); return; }
    save.textContent = "Saving…";
    const r = await answer(ev.requestId, { decision: "always", rule, where: box.querySelector("input[type=radio]:checked").value }).catch(() => null);
    if (r?.ok) { card.mine = true; return; }
    save.textContent = "Allow and save";
    if (r?.status === 404) return; // settled elsewhere first; its outcome arrives as an event
    const j = await r?.json().catch(() => ({}));
    if (j?.problem) setRuleError(error, j.problem, j.hint); else error.textContent = j?.error || "Couldn't save the rule.";
    error.hidden = false;
  };
  save.onclick = submit;
  box.onkeydown = (e) => {
    if (e.key === "Enter" && e.target === input) { e.preventDefault(); submit(); }
    if (e.key === "Escape") { e.preventDefault(); cancel.onclick(); }
  };
  card.groups.at(-1).after(box);
  card.groups.push(box);
  card.editor = box;
  if (!ev.noMatch) input.focus();
};
// An action allowed without a card for the rest of a reply (FR-126): a muted line before its tool chip.
const AUTO_ALLOW_LEAD = { reply: "Allowed for this reply", level: "Allowed in this project", bookkeeping: "Allowed · bookkeeping" }; // trust-levels FR-250, FR-264
const addAutoAllow = (detail, by = "reply") => {
  const m = el("div", "meta auto-allow");
  const lead = AUTO_ALLOW_LEAD[by] || AUTO_ALLOW_LEAD.reply;
  const ok = el("span", "ok", "✓"); ok.setAttribute("aria-hidden", "true");
  m.append(ok, ` ${lead} · `, el("code", null, detail));
  m.title = `${lead} · ${detail}`;
  $("messages").append(m);
  closeRun();
  return m;
};

const showQuestions = (ev, { readOnly = false, settled = null } = {}) => {
  hideTyping();
  const questions = ev.input?.questions || [];
  const picks = new Map();
  const others = new Map();
  const groups = [];
  let card = null;
  const finish = (body) => sendAnswer(card, body);
  // History: the options as plain text chips with the chosen ones marked, then the outcome.
  if (readOnly) {
    for (const q of questions) {
      const b = addBubble("them");
      if (q.header) b.append(el("div", "qhead", q.header));
      b.append(document.createTextNode(q.question));
      const g = quickGroup(q.header || "Answer");
      g.setAttribute("aria-disabled", "true");
      const chosen = (settled?.answers?.[q.question] || "").split(", ");
      for (const o of q.options || []) {
        const s = el("span", "qr ghost static", o.label);
        if (chosen.includes(o.label)) s.setAttribute("aria-pressed", "true");
        g.append(s);
      }
      groups.push(g);
    }
    // Only the last group is replaced by the answer; the earlier option rows stay visible in history.
    card = registerCard(ev, [], true);
    return settleCard(card, settled);
  }
  const submit = () => {
    const answers = {};
    for (const q of questions) {
      const extra = others.get(q.question)?.value.trim();
      const vals = [...picks.get(q.question), ...(extra ? [extra] : [])];
      if (vals.length) answers[q.question] = vals.join(", ");
    }
    if (!Object.keys(answers).length) return;
    finish({ answers }, Object.values(answers).join(" · "));
  };
  const instant = questions.length === 1 && !questions[0].multiSelect;
  questions.forEach((q, qi) => {
    const b = addBubble("them");
    if (q.header) b.append(el("div", "qhead", q.header));
    b.append(document.createTextNode(q.question));
    picks.set(q.question, new Set());
    const g = quickGroup(q.header || "Answer");
    groups.push(g);
    const opts = [];
    for (const o of q.options || []) {
      const p = pill(o.label);
      if (o.description) p.title = o.description;
      if (!instant) p.setAttribute("aria-pressed", "false");
      p.onclick = () => {
        const set = picks.get(q.question);
        if (instant) { set.add(o.label); return submit(); }
        if (!q.multiSelect) { set.clear(); opts.forEach((x) => x.setAttribute("aria-pressed", "false")); }
        if (set.has(o.label)) { set.delete(o.label); p.setAttribute("aria-pressed", "false"); }
        else { set.add(o.label); p.setAttribute("aria-pressed", "true"); }
      };
      opts.push(p);
      g.append(p);
    }
    const other = pill("Other…", "ghost");
    other.onclick = () => {
      other.hidden = true;
      const input = el("input", "other-input");
      input.setAttribute("aria-label", "Other answer");
      input.placeholder = "Type your answer…";
      input.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); submit(); } };
      others.set(q.question, input);
      g.insertBefore(input, other);
      if (instant) { const s = pill("Send", "primary"); s.onclick = submit; g.insertBefore(s, other); }
      input.focus();
    };
    g.append(other);
    if (qi === questions.length - 1) {
      if (!instant) { const s = pill("Send", "primary"); s.onclick = submit; g.append(s); }
      const skip = pill("Skip", "ghost");
      skip.onclick = () => finish({ decision: "deny", message: "The user skipped the question. Ask them in plain text instead." }, "Skipped");
      g.append(skip);
    }
  });
  card = registerCard(ev, groups, false);
  if (state.follow) groups[0]?.querySelector("button")?.focus({ preventScroll: true });
};

// ---------- role chips (spec D) ----------
const loadRoles = async () => {
  const project = $("project").value;
  try {
    const res = await api("/api/roles?project=" + encodeURIComponent(project));
    if (!res.ok) throw new Error();
    state.roles = await res.json();
  } catch { state.roles = { chips: [], custom: [], commands: [] }; }
  if (state.role && !state.roles.chips.some((c) => c.id === state.role.id && !c.hidden)) state.role = null;
  renderRoleChips();
  if (!$("panelRoles").hidden) renderRoleSettings();
};
const renderRoleChips = () => {
  const box = $("roles");
  box.innerHTML = "";
  const visible = state.roles.chips.filter((c) => !c.hidden);
  for (const c of visible) {
    const b = el("button", "role-chip", c.label);
    b.type = "button";
    b.setAttribute("aria-pressed", String(state.role?.id === c.id));
    b.title = c.kind === "skill" ? `Runs /${c.skill}` : "Your instructions: " + (c.text || "").slice(0, 120);
    b.onclick = () => { state.role = state.role?.id === c.id ? null : c; renderRoleChips(); $("input").focus(); };
    box.append(b);
  }
  {
    const add = el("button", "role-chip add", "＋");
    add.type = "button";
    add.setAttribute("aria-label", "Add or manage roles");
    add.title = "Add or manage roles";
    add.onclick = () => { selectTab("tabRoles"); $("settings").showModal(); $("addRole").open = true; $("newLabel").focus(); };
    box.append(add);
  }
};
const roleRequest = (c) => (c.discovered ? { kind: "skill", name: c.skill } : { id: c.id });

// Settings -> Roles: show/hide, rename, reorder, delete custom, add (FR-20, FR-21).
const prefsFromChips = (chips) => ({
  hidden: chips.filter((c) => c.hidden).map((c) => c.id),
  renamed: Object.fromEntries(chips.filter((c) => c.renamedTo).map((c) => [c.id, c.renamedTo])),
  order: chips.map((c) => c.id),
});
// A renamed project role keeps its new label in renamedTo; custom roles keep their label in the custom list.
const editableChips = () => state.roles.chips.map((c) => ({ ...c, renamedTo: c.discovered && c.label !== c.defaultLabel ? c.label : undefined }));
let roleSaveTimer = null;
const saveRoles = async (chips, custom) => {
  $("roleError").textContent = "";
  const res = await api("/api/roles", { method: "PUT", body: JSON.stringify({ project: $("project").value, prefs: prefsFromChips(chips), custom }) });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) { $("roleError").textContent = body.error || "Could not save."; return false; }
  state.roles = { ...state.roles, chips: body.chips, custom: body.custom };
  renderRoleChips();
  renderRoleSettings();
  return true;
};
const renderRoleSettings = () => {
  $("rolesProject").textContent = $("project").value;
  const list = $("roleList");
  list.innerHTML = "";
  const chips = editableChips();
  const custom = () => state.roles.custom.map((c) => ({ ...c }));
  chips.forEach((c, i) => {
    const li = el("li");
    const show = el("input");
    show.type = "checkbox"; show.checked = !c.hidden;
    show.setAttribute("aria-label", `Show ${c.label}`);
    show.onchange = () => { chips[i].hidden = !show.checked; saveRoles(chips, custom()); };
    const name = el("input");
    name.type = "text"; name.value = c.label; name.maxLength = 24;
    name.setAttribute("aria-label", `Label for ${c.label}`);
    name.oninput = () => {
      clearTimeout(roleSaveTimer);
      roleSaveTimer = setTimeout(() => {
        const v = name.value.trim();
        if (!v) return;
        if (c.discovered) chips[i].renamedTo = v === c.defaultLabel ? undefined : v;
        else { const all = custom(); const k = all.find((x) => x.id === c.id); if (k) k.label = v; return saveRoles(chips, all); }
        saveRoles(chips, custom());
      }, 500);
    };
    const ctl = el("span", "ctl");
    const move = (d) => () => { const j = i + d; if (j < 0 || j >= chips.length) return; [chips[i], chips[j]] = [chips[j], chips[i]]; saveRoles(chips, custom()); };
    const up = el("button", "icon-btn", "↑"); up.type = "button"; up.setAttribute("aria-label", `Move ${c.label} up`); up.onclick = move(-1); up.disabled = i === 0;
    const down = el("button", "icon-btn", "↓"); down.type = "button"; down.setAttribute("aria-label", `Move ${c.label} down`); down.onclick = move(1); down.disabled = i === chips.length - 1;
    ctl.append(up, down);
    if (!c.discovered) {
      const del = el("button", "icon-btn", "✕"); del.type = "button"; del.setAttribute("aria-label", `Delete ${c.label}`);
      del.onclick = () => { if (confirm(`Delete the role "${c.label}"?`)) saveRoles(chips.filter((x) => x.id !== c.id), custom().filter((x) => x.id !== c.id)); };
      ctl.append(del);
    }
    const what = el("div", "what", c.kind === "skill" ? `${c.discovered ? "project skill" : "skill"}: /${c.skill}` : `prompt${c.scope === "all" ? " · all projects" : ""}: ${c.text || ""}`);
    li.append(show, name, ctl, what);
    list.append(li);
  });
  if (!chips.length) list.append(el("li", "hint", "No roles for this project yet."));
  const dl = $("skillOptions");
  dl.innerHTML = "";
  for (const k of state.roles.commands || []) { const o = el("option"); o.value = k.name; o.label = k.description.slice(0, 80); dl.append(o); }
};
$("newKind").onchange = () => { const skill = $("newKind").value === "skill"; $("newSkillField").hidden = !skill; $("newTextField").hidden = skill; };
$("addRoleBtn").onclick = async () => {
  const kind = $("newKind").value;
  const scope = $("newScope").value === "all" ? "all" : $("project").value;
  const item = { kind, label: $("newLabel").value.trim(), scope, ...(kind === "skill" ? { skill: $("newSkill").value.trim() } : { text: $("newText").value.trim() }) };
  const ok = await saveRoles(editableChips(), [...state.roles.custom, item]);
  if (ok) { $("newLabel").value = ""; $("newSkill").value = ""; $("newText").value = ""; $("addRole").open = false; }
};
$("refreshRoles").onclick = async () => {
  $("refreshRoles").disabled = true;
  await api("/api/roles/refresh", { method: "POST" });
  await loadRoles();
  $("refreshRoles").disabled = false;
};

// ---------- sending and following a turn (spec reliable-chats Q) ----------
const setBusy = (busy, text = "") => {
  state.busy = busy;
  activity.localBusy = busy; // the poller and pixel Claude know this page has a turn going (FR-80, FR-81)
  if (busy) kickPoll();
  dispatchEvent(new CustomEvent("studio-busy", { detail: busy })); // Claude in the sidebar thinks along
  $("send").hidden = busy;
  $("stop").hidden = !busy;
  $("mode").disabled = busy; // the level is fixed for a running reply; it applies from the next one (trust-levels FR-253)
  $("status").textContent = text;
  $("status").classList.remove("warn");
};

// One handler for every turn event, whether this tab sent the message or rejoined the turn later.
const handleEvent = (ev) => {
  if (ev.seq) state.lastSeq = ev.seq;
  if (ev.type === "chat") {
    state.turnId = ev.turnId;
    const isNew = !state.chat;
    setChat(ev.chat);
    history.replaceState(null, "", "#" + ev.chat.id);
    if (isNew) loadChats();
  } else if (ev.type === "prompt") {
    if (state.sentHere) return; // already on screen in the tab that sent it
    const label = ev.role?.kind === "skill" ? roleLabelFor(ev.role.name) : ev.role?.id ? state.roles.chips.find((c) => c.id === ev.role.id)?.label || "Role" : null;
    if (!label && ev.text.trim().startsWith("/")) addCommand(ev.text.trim()); else addUser(ev.text, label);
    hideTyping();
    state.userMeta = addMeta("me", timeOf(ev.at));
    state.seen = false;
    showTyping();
  } else if (ev.type === "sdk") handleSdk(ev.msg);
  else if (ev.type === "permission") showCard(ev);
  else if (ev.type === "auto-allow") addAutoAllow(ev.detail, ev.by);
  else if (ev.type === "permission-settled") { const card = state.cards.get(ev.requestId); if (card) settleCard(card, ev, { live: true }); }
  else if (ev.type === "error") addNotice("err", "Something went wrong.", ev.error);
  else if (ev.type === "done") { state.turnDone = true; if (typeof awayTurnEnded === "function") awayTurnEnded(state.chat?.id, ev.lastEnd); }
};
const readEvents = async (res) => {
  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  let buf = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) return;
    buf += value;
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1);
      if (line.trim()) handleEvent(JSON.parse(line));
    }
  }
};
const wait = (ms, signal) => new Promise((resolve) => { const t = setTimeout(resolve, ms); signal.addEventListener("abort", () => { clearTimeout(t); resolve(); }); });
// Follows a turn to its end. If the stream drops while the turn still runs, attach again from the last event:
// after 1 s, 2 s, 5 s, then every 5 s for up to a minute (FR-70a). Returns "done", "ended" (finished while we
// were away), "lost" or "detached" (this tab moved on).
const followTurn = async (res, chatId) => {
  const signal = state.stream.signal;
  const delays = [1000, 2000, 5000];
  let tries = 0, since = null;
  for (;;) {
    try { await readEvents(res); } catch {}
    if (signal.aborted) return "detached";
    if (state.turnDone) return "done";
    since ??= Date.now();
    $("status").textContent = "Reconnecting…";
    $("status").classList.add("warn");
    for (;;) {
      if (Date.now() - since > 60000) return "lost";
      await wait(delays[Math.min(tries++, delays.length - 1)], signal);
      if (signal.aborted) return "detached";
      let r;
      try { r = await fetch(`/api/chats/${state.chat?.id || chatId}/live?after=${state.lastSeq}`, { signal }); } catch { continue; }
      if (r.status === 204) return "ended";
      if (r.ok) { res = r; break; }
    }
    $("status").textContent = "Working…";
    $("status").classList.remove("warn");
    tries = 0; since = null;
  }
};
// After a turn: close the view of it. A turn that ended while we were reconnecting is reloaded from history.
const endTurnView = (outcome, chat) => {
  if (outcome === "detached") return;
  state.stream = null;
  document.querySelectorAll(".quick button, .quick input").forEach((x) => (x.disabled = true));
  hideTyping();
  closeRun();
  state.turnId = null;
  setBusy(false);
  loadChats();
  loadOutputs();
  kickPoll();
  if (outcome === "ended" && state.chat?.id === chat.id) openChat(state.chat, true);
  if (outcome === "lost") {
    const b = addNotice("warn", "Lost the live view.", "The reply may still be running. ");
    const retry = pill("Retry");
    retry.onclick = () => { retry.disabled = true; attachLive(chat); };
    b.append(retry);
  }
};
const startStream = () => {
  state.stream = new AbortController();
  state.lastSeq = 0;
  state.turnDone = false;
  state.currentText = null;
  return state.stream.signal;
};

const send = async (text) => {
  if (state.busy || !text.trim()) return;
  const role = state.role;
  if (!role && text.trim().startsWith("/")) addCommand(text.trim()); else addUser(text, role?.label);
  state.userMeta = addMeta("me", clock());
  state.seen = false;
  scrollDown(true); // sending always brings the view back down (FR-95)
  setBusy(true, "Working…");
  const signal = startStream();
  state.sentHere = true;
  showTyping();
  let outcome = "done";
  try {
    const res = await api("/api/turn", {
      method: "POST",
      signal,
      body: JSON.stringify({ text, chatId: state.chat?.id, project: $("project").value, permissionMode: $("mode").value, model: $("model").value || undefined, ...(role ? { role: roleRequest(role) } : {}) }),
    });
    if (!res.ok || !res.body) {
      // 400 (bad input), 404 (unknown chat), 409 (chat busy or in the bin): the message was not sent.
      const body = await res.text();
      let message = body;
      try { message = JSON.parse(body).error || body; } catch {}
      if (res.status === 404) addNotice("warn", "Message not sent.", "This chat no longer exists. Start a new chat.");
      else if (res.status === 400 || res.status === 409) addNotice("warn", "Message not sent.", message);
      else addNotice("err", "Something went wrong.", message || `Request failed (${res.status})`);
    } else outcome = await followTurn(res, state.chat?.id);
  } catch (e) {
    if (signal.aborted) outcome = "detached";
    // fetch rejects with a TypeError when the server can't be reached.
    else if (e instanceof TypeError) addNotice("err", "Couldn't reach Claude Studio.", "Is the server running? Check the terminal or Start Claude Studio.cmd.");
    else addNotice("err", "Something went wrong.", String(e.message || e));
  }
  state.sentHere = false;
  endTurnView(outcome, state.chat);
};

// Rejoin a chat's running turn (FR-70): replay its events so far, then follow it live. 204 = nothing running.
const attachLive = async (chat) => {
  if (state.stream) return;
  const signal = startStream();
  let res;
  try { res = await fetch(`/api/chats/${chat.id}/live?after=0`, { signal }); } catch { if (state.stream?.signal === signal) state.stream = null; return; }
  if (res.status !== 200 || state.chat?.id !== chat.id) { if (state.stream?.signal === signal) state.stream = null; res.body?.cancel(); return; }
  setBusy(true, "Rejoined · still working");
  if (typeof awayRejoined === "function") awayRejoined(chat); // the visible "Still working" banner (spec away-status FR-192)
  setTimeout(() => { if (state.busy && $("status").textContent === "Rejoined · still working") $("status").textContent = "Working…"; }, 3000);
  showTyping();
  const outcome = await followTurn(res, chat.id);
  endTurnView(outcome, chat);
  if (outcome === "done") scrollDown();
};

// ---------- slash commands ----------
// Typing / opens a menu of commands. Studio handles a few itself (some only exist in the terminal, like /btw);
// everything else (Claude Code built-ins such as /usage or /compact, skills, custom commands) is sent to Claude as typed.
let claudeCommands = null;
const loadCommands = async () => {
  if (claudeCommands) return claudeCommands;
  try { const r = await api("/api/commands"); claudeCommands = r.ok ? await r.json() : []; } catch { claudeCommands = []; }
  return claudeCommands;
};
const allCommands = () => {
  const studio = STUDIO_COMMANDS.map((c) => ({ ...c, key: c.name, desc: c.description, aliases: c.aliases || [], group: "Studio" }));
  const taken = new Set(studio.flatMap((c) => [c.name, ...c.aliases]));
  const rest = (claudeCommands || []).filter((c) => !taken.has(c.name)).map((c) => ({ ...c, key: c.name, desc: c.description, group: c.builtin ? "Claude Code" : "Skills and commands" }))
    .sort((a, b) => (a.group === b.group ? a.name.localeCompare(b.name) : a.group === "Skills and commands" ? -1 : 1));
  return [...studio, ...rest];
};
const studioCommand = (name) => STUDIO_COMMANDS.find((c) => c.name === name || c.aliases?.includes(name));

const menu = { items: [], index: 0 };
const closeMenu = () => { $("cmdMenu").hidden = true; $("input").setAttribute("aria-expanded", "false"); $("input").removeAttribute("aria-activedescendant"); menu.items = []; };
const pickCommand = (c) => {
  const studio = studioCommand(c.name);
  const runsNow = studio && !c.argumentHint; // Studio commands without arguments run at once; others wait for Enter
  $("input").value = "/" + c.name + (runsNow ? "" : " ");
  closeMenu();
  autosize();
  $("input").focus();
  if (runsNow && c.name !== "help") $("composer").requestSubmit();
};
const renderMenu = async (all = false) => {
  const v = $("input").value;
  const m = /^\/([^\s]*)$/.exec(v);
  if (!m && !all) return closeMenu();
  if (!claudeCommands) {
    // First use: show the menu at once while Claude Code's list loads (QA F-1).
    const box = $("cmdMenu");
    box.innerHTML = "";
    box.append(el("p", "cmd-empty", "Loading commands…"));
    box.hidden = false;
    $("input").setAttribute("aria-expanded", "true");
    await loadCommands();
    if ($("input").value !== v) return; // the text changed meanwhile; its own input event renders the menu
  }
  const f = (m ? m[1] : "").toLowerCase();
  // Groups in this order: Studio, then skills and custom commands, then Claude Code built-ins (shared matching, look.js).
  menu.items = rankMatches(allCommands(), f, ["Studio", "Skills and commands", "Claude Code"]).slice(0, 60);
  menu.index = 0;
  const box = $("cmdMenu");
  box.innerHTML = "";
  if (!menu.items.length) { box.append(el("p", "cmd-empty", `No command matches /${f}. Press Enter to send it to Claude as typed.`)); }
  let group = null;
  menu.items.forEach((c, i) => {
    if (!f && c.group !== group) { group = c.group; box.append(el("div", "cmd-group", group)); }
    // While filtering, each row is tagged with its group.
    box.append(resultRow({ id: "cmd-" + i, name: "/" + c.name, hint: c.argumentHint, desc: c.description, tag: f ? (c.group === "Skills and commands" ? "Skill" : c.group) : "", onPick: () => pickCommand(c) }));
  });
  box.hidden = false;
  $("input").setAttribute("aria-expanded", "true");
  highlight(0);
};
const highlight = (i) => {
  if (!menu.items.length) return;
  menu.index = (i + menu.items.length) % menu.items.length;
  document.querySelectorAll(".cmd-item").forEach((o, k) => o.setAttribute("aria-selected", String(k === menu.index)));
  const cur = $("cmd-" + menu.index);
  $("input").setAttribute("aria-activedescendant", cur.id);
  cur.scrollIntoView({ block: "nearest" });
};

// Studio's own commands. Returns true when handled here (nothing is sent to Claude).
const runStudioCommand = async (text) => {
  const m = /^\/(\S+)\s*([\s\S]*)$/.exec(text.trim());
  const cmd = m && studioCommand(m[1]);
  if (!cmd) return false;
  const arg = m[2].trim();
  if (cmd.name === "new") newChat();
  else if (cmd.name === "help") { $("input").value = "/"; renderMenu(true); }
  else if (cmd.name === "model") {
    const v = arg.toLowerCase() === "default" ? "" : arg.toLowerCase();
    if (![...$("model").options].some((o) => o.value === v)) addNotice("warn", "Unknown model.", "Use /model opus, sonnet, haiku, fable or default.");
    else { $("model").value = v; store.set("model", v); $("status").textContent = `Model: ${$("model").selectedOptions[0].text}`; }
  } else if (cmd.name === "rename") {
    if (!state.chat) addNotice("warn", "Nothing to rename yet.", "Send a first message, then rename the chat.");
    else if (!arg) addNotice("warn", "Add a title.", "For example: /rename Release notes");
    else {
      const r = await api("/api/chats/" + state.chat.id, { method: "PATCH", body: JSON.stringify({ title: arg }) });
      if (r.ok) { state.chat.title = (await r.json()).title; showTitle(); loadChats(); } else addNotice("warn", "Couldn't rename the chat.", (await r.json().catch(() => ({}))).error || "");
    }
  } else if (cmd.name === "btw") {
    if (!arg) addNotice("warn", "Ask something after /btw.", "For example: /btw what file are you editing?");
    else btw(arg);
  }
  return true;
};
// A side card that is not part of the chat history: the question, then the answer (Markdown, sanitised).
// /btw looks like any other command: "❯ /btw question", then the answer after "⎿". It is a side block:
// not saved to the chat, dismissable, and it never takes the output of a command that is running.
const btw = async (question) => {
  const box = addCommand("/btw " + question, { track: false, cls: "btw" });
  box.setAttribute("aria-live", "polite");
  const x = el("button", "cmd-x", "✕");
  x.type = "button";
  x.setAttribute("aria-label", "Dismiss this side answer");
  x.title = "Dismiss";
  x.onclick = () => box.remove();
  box.prepend(x);
  const waiting = addCommandOutput("Thinking…", { box });
  waiting.classList.add("waiting");
  const note = () => box.append(el("div", "cmd-note", "Side answer · not saved to this chat"));
  try {
    const r = await api("/api/btw", { method: "POST", body: JSON.stringify({ text: question, chatId: state.chat?.id, model: $("model").value || undefined }) });
    const j = await r.json().catch(() => ({}));
    waiting.remove();
    if (r.ok) addCommandOutput(j.answer || "No answer.", { box, markdown: true });
    else addCommandOutput(`<local-command-stderr>${j.error || `Request failed (${r.status})`}</local-command-stderr>`, { box });
  } catch {
    waiting.remove();
    addCommandOutput("<local-command-stderr>Couldn't reach Studio.</local-command-stderr>", { box });
  }
  note();
  scrollDown(true);
};

$("composer").onsubmit = async (e) => {
  e.preventDefault();
  const text = $("input").value;
  closeMenu();
  if (text.trim().startsWith("/") && studioCommand(text.trim().slice(1).split(/\s/)[0])) {
    const isBtw = /^\/btw\b/.test(text.trim());
    if (state.busy && !isBtw) return; // other Studio commands wait for the reply to finish
    $("input").value = "";
    autosize();
    await runStudioCommand(text);
    return;
  }
  // A saved Auto mode that this account can't use is refused here, before the message is sent and cleared (trust-levels FR-255).
  if ($("mode").value === "auto" && !state.busy && !(await autoModeAvailable())) return;
  $("input").value = "";
  autosize();
  send(text);
};
$("input").onkeydown = (e) => {
  if (!$("cmdMenu").hidden && menu.items.length) {
    if (e.key === "ArrowDown") { e.preventDefault(); return highlight(menu.index + 1); }
    if (e.key === "ArrowUp") { e.preventDefault(); return highlight(menu.index - 1); }
    if (e.key === "Tab" || (e.key === "Enter" && !e.shiftKey && !e.isComposing)) { e.preventDefault(); return pickCommand(menu.items[menu.index]); }
  }
  if (e.key === "Escape" && !$("cmdMenu").hidden) { e.preventDefault(); return closeMenu(); }
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); $("composer").requestSubmit(); }
};
$("input").onblur = () => setTimeout(closeMenu, 150);
const autosize = () => { const t = $("input"); t.style.height = "auto"; t.style.height = t.scrollHeight + "px"; };
$("input").oninput = () => { autosize(); renderMenu(); };
$("stop").onclick = () => { if (state.turnId) api(`/api/turn/${state.turnId}/interrupt`, { method: "POST" }); $("status").textContent = "Stopping…"; };

$("model").value = store.get("model", "");
syncModeMenu(store.get("project", "General"));
$("model").onchange = () => store.set("model", $("model").value);
$("mode").onchange = async () => {
  const p = $("project").value;
  // Auto mode is checked once (FR-255); when the account can't use it the menu goes back to the saved level and says so.
  if ($("mode").value === "auto" && !(await autoModeAvailable())) return;
  store.set("modeByProject", { ...store.get("modeByProject", { General: store.get("mode", "default") }), [p]: $("mode").value });
  showModeHelp();
  updatePill();
  $("status").textContent = `Mode for ${p}: ${$("mode").selectedOptions[0].text}`;
  setTimeout(() => { if ($("status").textContent.startsWith("Mode for ")) $("status").textContent = ""; }, 3000);
};

// ---------- outputs panel ----------
let outputs = [];
const renderOutputs = () => {
  const f = $("outputFilter").value.toLowerCase();
  const list = $("outputList");
  list.innerHTML = "";
  for (const o of outputs.filter((o) => o.path.toLowerCase().includes(f)).slice(0, 150)) {
    const a = el("a", "output-item");
    const enc = o.path.split("/").map(encodeURIComponent).join("/");
    a.href = outputsProject === "General" ? "/output/" + enc : `/project-file/${encodeURIComponent(outputsProject)}/${enc}`;
    a.target = "_blank";
    a.rel = "noopener";
    const parts = o.path.split("/");
    a.append(el("span", "dir", parts.slice(0, -1).join("/") || (outputsProject === "General" ? "output" : outputsProject)), document.createTextNode(parts.at(-1)));
    a.title = new Date(o.mtime).toLocaleString();
    list.append(a);
  }
};
// The panel follows the selected project: General shows Home\output, a project shows its own folder (newest first).
let outputsProject = "General";
const loadOutputs = async () => {
  const project = $("project").value || "General";
  const res = await api("/api/outputs?project=" + encodeURIComponent(project));
  outputsProject = project;
  outputs = res.ok ? await res.json() : [];
  $("outputsTitle").textContent = project === "General" ? "Outputs" : `${project} files`;
  $("outputs").setAttribute("aria-label", $("outputsTitle").textContent);
  renderOutputs();
  if (!outputs.length) $("outputList").append(el("p", "chat-empty", project === "General" ? "No files in output yet." : `No files in ${project} yet.`));
  panel.docs = await docsFor(project);
  renderTabs();
};

// Specs and Tests tabs: shown only when the project has that folder; a file opens rendered inside the panel.
const TAB_IDS = { files: "tabFiles", specs: "tabSpecs", tests: "tabTests" };
const panel = { tab: store.get("panelTab", "files"), docs: {} };
const docsFor = async (project) => {
  if (project === "General") return {};
  const one = async (folder) => { try { const r = await api(`/api/project-docs?project=${encodeURIComponent(project)}&folder=${folder}`); return r.ok ? await r.json() : null; } catch { return null; } };
  const [specs, tests] = await Promise.all([one("specs"), one("tests")]);
  return { specs, tests };
};
const renderTabs = () => {
  $("tabSpecs").hidden = !panel.docs.specs;
  $("tabTests").hidden = !panel.docs.tests;
  const tab = panel.tab !== "files" && panel.docs[panel.tab] ? panel.tab : "files";
  for (const [t, id] of Object.entries(TAB_IDS)) { $(id).setAttribute("aria-selected", String(t === tab)); $(id).tabIndex = t === tab ? 0 : -1; }
  $("panelBody").setAttribute("aria-labelledby", TAB_IDS[tab]);
  $("filesPane").hidden = tab !== "files";
  $("docsPane").hidden = tab === "files";
  $("refreshOutputs").hidden = tab !== "files";
  if (tab !== "files") renderDocList(tab);
};
const renderDocList = (folder, focusPath) => {
  const box = $("docsPane");
  box.innerHTML = "";
  box.onkeydown = null;
  const files = panel.docs[folder] || [];
  if (!files.length) { box.append(el("p", "chat-empty", `No Markdown files in ${folder} yet.`)); return; }
  for (const f of files) {
    const b = el("button", "doc-item");
    b.type = "button";
    b.append(el("span", "doc-name", f.path), el("span", "doc-time", ago(f.mtime)));
    b.onclick = () => openDoc(folder, f.path);
    box.append(b);
    if (f.path === focusPath) b.focus();
  }
};
const openDoc = async (folder, file) => {
  const box = $("docsPane");
  box.innerHTML = "";
  const head = el("div", "doc-head");
  const back = el("button", "link-btn", "← Back");
  back.type = "button";
  back.onclick = () => renderDocList(folder, file);
  const raw = el("a", "doc-raw", "Open raw");
  raw.href = `/project-file/${encodeURIComponent(outputsProject)}/${folder}/${encodeURIComponent(file)}`;
  raw.target = "_blank";
  raw.rel = "noopener";
  head.append(back, raw);
  const body = el("div", "md doc-body", "Loading…");
  box.append(head, el("div", "doc-title", file), body);
  box.onkeydown = (e) => { if (e.key === "Escape") { e.preventDefault(); renderDocList(folder, file); } };
  back.focus();
  try {
    const r = await fetch(raw.href);
    if (!r.ok) throw new Error(String(r.status));
    body.innerHTML = md(await r.text());
  } catch {
    body.textContent = "Couldn't read this file.";
    body.classList.add("error-text");
  }
};
for (const [t, id] of Object.entries(TAB_IDS)) $(id).onclick = () => { panel.tab = t; store.set("panelTab", t); renderTabs(); };
$("panelTabs").onkeydown = (e) => {
  const tabs = [...$("panelTabs").querySelectorAll('[role="tab"]:not([hidden])')];
  const i = tabs.indexOf(document.activeElement);
  const j = { ArrowRight: i + 1, ArrowLeft: i - 1, Home: 0, End: tabs.length - 1 }[e.key];
  if (i < 0 || j == null) return;
  e.preventDefault();
  const t = tabs[(j + tabs.length) % tabs.length];
  t.click();
  t.focus();
};
$("outputFilter").oninput = renderOutputs;
$("refreshOutputs").onclick = loadOutputs;
$("toggleOutputs").onclick = () => { const o = $("outputs"); o.hidden = !o.hidden; store.set("outputsOpen", !o.hidden); if (!o.hidden) loadOutputs(); dispatchEvent(new Event("studio-panels")); };
// Desktop: hide the sidebar for more room (remembered per browser). On a phone the sidebar is an overlay and « closes it.
const phone = () => matchMedia("(max-width: 860px)").matches;
const setSidebarHidden = (hidden) => {
  document.querySelector(".app").classList.toggle("side-hidden", hidden);
  store.set("sidebarHidden", hidden);
  $("toggleSidebar").setAttribute("aria-label", hidden ? "Show sidebar" : "Show chats");
  $("toggleSidebar").title = hidden ? "Show sidebar" : "Chats";
  dispatchEvent(new Event("studio-panels")); // Claude keeps out from under the panels (QA F-3)
};
setSidebarHidden(store.get("sidebarHidden", false));
// The Outputs panel sits just under the top bar (desktop), whatever the top bar's height.
new ResizeObserver(() => document.documentElement.style.setProperty("--topbar-h", `${document.querySelector(".topbar").offsetHeight}px`)).observe(document.querySelector(".topbar"));
$("toggleSidebar").onclick = () => {
  if (phone()) return $("sidebar").classList.toggle("open");
  setSidebarHidden(false);
  $("hideSidebar").focus();
};
$("hideSidebar").onclick = () => {
  if (phone()) return $("sidebar").classList.remove("open");
  setSidebarHidden(true);
  $("toggleSidebar").focus();
};

// The chat page follows the address (FR-45a): a pasted #<chat id>, Back and Forward open that chat.
addEventListener("hashchange", async () => {
  const id = location.hash.slice(1);
  if (id === "settings-home") return;
  if (!id) { if (state.chat) newChat(true); return; }
  if (state.chat?.id === id) return;
  const chat = await findChat(id);
  if (chat) openChat(chat, true);
  else { newChat(true); history.replaceState(null, "", location.pathname); addNotice("warn", "This chat no longer exists.", "Start a new chat."); }
});

// ---------- start ----------
(async () => {
  await Promise.all([loadInfo(), loadProjects()]);
  // An action handed over from the Home page: open a project, start a new chat, or send a first message.
  let pending = null;
  try { pending = JSON.parse(sessionStorage.getItem("studio.pending")); sessionStorage.removeItem("studio.pending"); } catch {}
  if (pending?.project && [...$("project").options].some((o) => o.value === pending.project)) {
    $("project").value = pending.project; store.set("project", pending.project); updatePill();
  }
  loadRoles();
  await loadChats();
  const fromHash = location.hash.length > 1 ? await findChat(location.hash.slice(1)) : null;
  if (fromHash && !pending) openChat(fromHash);
  else if (!pending && location.hash.length > 1 && location.hash !== "#settings-home") {
    history.replaceState(null, "", location.pathname);
    addNotice("warn", "This chat no longer exists.", "Start a new chat.");
  }
  // Text from Home's field may be a Studio command (/new, /model, /btw); those run here, the rest goes to Claude.
  if (pending?.text && !(await runStudioCommand(pending.text))) send(pending.text);
  if (pending?.draft) { $("input").value = pending.draft; autosize(); } // a command chosen in Home's Ctrl K palette
  if (store.get("outputsOpen", false)) { $("outputs").hidden = false; loadOutputs(); dispatchEvent(new Event("studio-panels")); }
  $("input").focus();
  setTimeout(loadCommands, 2000); // warm the / menu's list (QA F-1)
})();
