// Attachments (spec attachments FR-266 to FR-283, design attachments.md): the ＋ button, the tray, drag and drop, paste,
// the thumbnails and chips in a message, and the question about files when a chat is deleted forever.
// Loaded after app.js and look.js, whose top-level helpers ($, el, api, state, addNotice…) it uses.
const ATT_MB = 1048576;
const ATT_LIM = { files: 10, total: 32 * ATT_MB, image: 5 * ATT_MB, pdf: 20 * ATT_MB, file: 25 * ATT_MB };
const ATT_BLOCKED = /\.(exe|dll|msi|bat|cmd|com|scr|ps1|vbs|js|jse|wsf|lnk|reg)$/i;
const att = { items: [], seq: 0 }; // item: { key, file, name, size, kind, status: uploading | done | refused | failed, id, progress, reason, thumb, xhr }
const attSize = (n) => (n >= ATT_MB ? (n / ATT_MB).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB");
const attGuessKind = (f) => (/^image\/(png|jpeg|gif|webp)$/.test(f.type) ? "image" : f.type === "application/pdf" ? "pdf" : "file");
const attIcon = (kind) => (kind === "pdf" ? "📕" : "📄");
const attSay = (text) => { const s = $("attStatus"); s.textContent = ""; setTimeout(() => { s.textContent = text; }, 30); };
const attCounted = () => att.items.filter((i) => i.status !== "refused");
const attReady = () => att.items.filter((i) => i.status === "done");
const attPending = () => att.items.some((i) => i.status === "uploading" || i.status === "failed");

// Why a file can't be added, before anything is sent (the server checks again by content, FR-272).
const attProblem = (item) => {
  if (ATT_BLOCKED.test(item.name)) return "Not allowed: programs and scripts";
  if (!item.size) return "Empty file";
  const counted = attCounted();
  if (counted.length >= ATT_LIM.files) return `Over the ${ATT_LIM.files}-file limit`;
  if (item.size > ATT_LIM[item.kind]) return `Over ${ATT_LIM[item.kind] / ATT_MB} MB`;
  if (counted.reduce((n, i) => n + i.size, 0) + item.size > ATT_LIM.total) return `Over the ${ATT_LIM.total / ATT_MB} MB total`;
  return "";
};
const attAdd = (files) => {
  const added = [], refused = [];
  for (const file of files) {
    const item = { key: ++att.seq, file, name: file.name || "file", size: file.size, kind: attGuessKind(file), status: "uploading", progress: 0, thumb: null };
    item.reason = attProblem(item);
    if (item.reason) { item.status = "refused"; refused.push(item); } else { added.push(item); if (item.kind === "image") item.thumb = URL.createObjectURL(file); }
    att.items.push(item);
  }
  attRender();
  for (const item of added) attUpload(item);
  const said = [];
  if (added.length) said.push(`${added.map((i) => i.name).join(", ")} added`);
  if (refused.length) said.push(`${refused.map((i) => `${i.name} not added: ${i.reason}`).join("; ")}`);
  if (said.length) attSay(said.join(". "));
};
const attUpload = (item) => {
  const xhr = new XMLHttpRequest();
  item.xhr = xhr; item.status = "uploading"; item.progress = 0;
  xhr.open("POST", "/api/attachments?name=" + encodeURIComponent(item.name));
  xhr.setRequestHeader("X-Studio", "1");
  xhr.setRequestHeader("Content-Type", "application/octet-stream");
  xhr.upload.onprogress = (e) => { if (e.lengthComputable) { item.progress = e.loaded / e.total; attRender(); } };
  xhr.onload = () => {
    let j = {};
    try { j = JSON.parse(xhr.responseText); } catch {}
    item.xhr = null;
    if (xhr.status === 201) { Object.assign(item, { status: "done", id: j.id, kind: j.kind, name: j.name }); }
    else { item.status = "refused"; item.reason = j.reason || j.error || "Couldn't upload"; attSay(`${item.name} not added: ${item.reason}`); }
    attRender();
  };
  xhr.onerror = () => { item.xhr = null; item.status = "failed"; attRender(); };
  xhr.send(item.file);
};
const attRemove = (item, fromKeyboard = true) => {
  if (item.xhr) item.xhr.abort();
  if (item.status === "done" && item.id) api("/api/attachments/" + item.id, { method: "DELETE" }).catch(() => {});
  const i = att.items.indexOf(item);
  att.items.splice(i, 1);
  attRender();
  if (fromKeyboard) (document.querySelectorAll("#attTray .att-chip .x")[Math.min(i, att.items.length - 1)] || $("attachBtn")).focus();
};

// ---- the tray (design 3) ----
const attRender = () => {
  const tray = $("attTray");
  tray.textContent = "";
  tray.hidden = !att.items.length;
  for (const item of att.items) {
    const chip = el("div", "att-chip" + (item.status === "refused" || item.status === "failed" ? " refused" : ""));
    chip.setAttribute("role", "listitem");
    if (item.status === "refused" || item.status === "failed") { const w = el("span", "warn", "⚠"); w.setAttribute("aria-hidden", "true"); chip.append(w); }
    else if (item.thumb) { const img = el("img", "thumb"); img.alt = ""; img.src = item.thumb; chip.append(img); }
    else { const ic = el("span", "thumb", attIcon(item.kind)); ic.setAttribute("aria-hidden", "true"); chip.append(ic); }
    const txt = el("div", "txt"), name = el("span", "name", item.name);
    name.title = item.name;
    const size = el("span", "size", item.status === "uploading" ? `Uploading ${Math.round(item.progress * 100)} %` : item.status === "failed" ? "Upload failed" : item.status === "refused" ? item.reason : attSize(item.size));
    txt.append(name, size);
    if (item.status === "uploading") {
      const bar = el("div", "att-bar"), fill = el("i");
      fill.style.width = Math.round(item.progress * 100) + "%";
      bar.append(fill);
      bar.setAttribute("role", "progressbar"); bar.setAttribute("aria-valuemin", "0"); bar.setAttribute("aria-valuemax", "100");
      bar.setAttribute("aria-valuenow", String(Math.round(item.progress * 100))); bar.setAttribute("aria-label", `Uploading ${item.name}`);
      txt.append(bar);
    }
    chip.append(txt);
    if (item.status === "failed") { const retry = el("button", "link-btn", "Retry"); retry.type = "button"; retry.onclick = () => { attUpload(item); attRender(); }; chip.append(retry); }
    const x = el("button", "x", "✕");
    x.type = "button";
    x.setAttribute("aria-label", item.status === "refused" ? `Dismiss ${item.name}` : item.status === "uploading" ? `Cancel upload of ${item.name}` : `Remove ${item.name}`);
    x.onclick = () => attRemove(item);
    chip.append(x);
    tray.append(chip);
  }
  const counted = attCounted();
  if (counted.length) {
    const total = counted.reduce((n, i) => n + i.size, 0);
    const lim = el("div", "att-limits" + (counted.length >= ATT_LIM.files - 1 || total > ATT_LIM.total * 0.875 ? " warn" : ""), `${counted.length} of ${ATT_LIM.files} files · ${(total / ATT_MB).toFixed(1)} of ${ATT_LIM.total / ATT_MB} MB`);
    tray.append(lim);
  }
  attUpdateUi();
};

// ---- the ＋ button and Send (design 2, 5) ----
const ATT_PLACEHOLDER = "Message Claude… ( / for commands)";
const ATT_NARROW = matchMedia("(max-width: 600px)");
const attUpdateUi = () => {
  const btn = $("attachBtn");
  const slash = $("input").value.trim().startsWith("/");
  const reason = state.busy ? "Wait for the reply to finish" : slash ? "Commands can't carry attachments" : attCounted().length >= ATT_LIM.files ? `${ATT_LIM.files} files is the limit` : "";
  btn.disabled = !!reason;
  btn.title = reason || "Attach files · sent to Claude with your message";
  if (reason) { $("attReason").textContent = reason; btn.setAttribute("aria-describedby", "attReason"); } else { $("attReason").textContent = ""; btn.removeAttribute("aria-describedby"); }
  // The long hint doesn't fit a phone-width message box, so narrow windows get a short one (QA F-2).
  $("input").placeholder = att.items.length ? (ATT_NARROW.matches ? "Add a message…" : "Add a message, or just send the files…") : ATT_PLACEHOLDER;
  const wait = attPending();
  $("send").setAttribute("aria-disabled", String(wait));
  $("send").title = wait ? "Waiting for uploads to finish" : "Send (Enter)";
};
$("attachBtn").onclick = () => $("attInput").click();
$("attInput").onchange = () => { attAdd([...$("attInput").files]); $("attInput").value = ""; };
$("input").addEventListener("input", attUpdateUi);
addEventListener("studio-busy", attUpdateUi);
ATT_NARROW.addEventListener("change", attUpdateUi);

// ---- drag and drop (design 4) and paste ----
let attDrag = 0;
const attHasFiles = (e) => [...(e.dataTransfer?.types || [])].includes("Files");
const attCanTake = () => !state.busy && !$("composer").classList.contains("in-bin");
const attHideDrop = () => { attDrag = 0; $("dropTarget").hidden = true; };
addEventListener("dragenter", (e) => { if (!attHasFiles(e) || !attCanTake()) return; attDrag++; $("dropTarget").hidden = false; });
addEventListener("dragover", (e) => { if (attHasFiles(e)) e.preventDefault(); });
addEventListener("dragleave", (e) => { if (!attHasFiles(e)) return; attDrag = Math.max(0, attDrag - 1); if (!attDrag) attHideDrop(); });
addEventListener("drop", (e) => {
  if (!attHasFiles(e)) return;
  e.preventDefault();
  attHideDrop();
  if (attCanTake()) attAdd([...e.dataTransfer.files]);
});
addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("dropTarget").hidden) attHideDrop(); });
$("input").addEventListener("paste", (e) => {
  if (!attCanTake()) return;
  const images = [...(e.clipboardData?.files || [])].filter((f) => /^image\//.test(f.type));
  if (!images.length) return; // plain text pastes as usual
  const t = new Date(), p = (n) => String(n).padStart(2, "0");
  attAdd(images.map((f, i) => new File([f], `pasted-image-${p(t.getHours())}-${p(t.getMinutes())}-${p(t.getSeconds())}${i ? "-" + (i + 1) : ""}.${(f.type.split("/")[1] || "png").replace("jpeg", "jpg")}`, { type: f.type })));
});
addEventListener("beforeunload", () => att.items.forEach((i) => i.thumb && URL.revokeObjectURL(i.thumb)));

// ---- sending (FR-275, FR-276) ----
// The files to send with this message, or null when sending has to wait or can't carry them.
const attForSend = (text) => {
  const ready = attReady();
  if (!att.items.length) return [];
  if (text.trim().startsWith("/") && att.items.length) { $("status").textContent = "Commands can't carry attachments. Remove the files or the /."; return null; }
  if (attPending()) { $("status").textContent = "Waiting for uploads to finish…"; return null; }
  return ready;
};
// After the server accepted the message: the tray empties (the files are the server's now).
const attSent = (sent) => { att.items = att.items.filter((i) => !sent.includes(i)); attRender(); };

// ---- in a message: thumbnails and chips (design 6, FR-279, FR-280) ----
const attUrl = (a) => "/api/attachments/" + a.id;
const attNode = (list, { live = false } = {}) => {
  const box = el("div", "atts-box");
  const thumbs = el("div", "atts"), files = el("div", "att-files");
  for (const a of list) {
    const label = `${a.name}, ${a.kind === "image" ? "image" : a.kind === "pdf" ? "PDF" : "file"}, ${attSize(a.size || 0)}`;
    if (a.kind === "image") {
      const link = el("a", "att-thumb");
      link.href = attUrl(a); link.target = "_blank"; link.rel = "noopener";
      link.setAttribute("aria-label", `Open ${a.name} in a new tab, ${label.slice(a.name.length + 2)}`);
      const img = el("img");
      img.alt = a.name;
      img.src = a.thumb || attUrl(a);
      img.onerror = () => { const gone = el("div", "att-gone", "🖼 File no longer there"); link.replaceWith(gone); };
      link.append(img);
      thumbs.append(link);
    } else {
      const chip = el("a", "att-file");
      chip.href = attUrl(a);
      if (a.kind === "pdf") { chip.target = "_blank"; chip.rel = "noopener"; chip.setAttribute("aria-label", `Open ${a.name} in a new tab, PDF, ${attSize(a.size || 0)}`); }
      else { chip.setAttribute("download", a.name); chip.setAttribute("aria-label", `Download ${label}`); }
      const ic = el("span", null, attIcon(a.kind)); ic.setAttribute("aria-hidden", "true");
      chip.append(ic, el("span", "nm", a.name), el("span", "sz", attSize(a.size || 0) + (a.kind === "pdf" ? "" : " ⬇")));
      files.append(chip);
      // A file that was moved or deleted shows as "no longer there" (design 6); live bubbles skip the check.
      if (!live) api(attUrl(a), { method: "HEAD" }).then((r) => { if (!r.ok) { chip.classList.add("gone"); chip.removeAttribute("href"); chip.removeAttribute("download"); chip.querySelector(".sz").textContent = "no longer there"; chip.setAttribute("aria-label", `${a.name}, no longer there`); } }).catch(() => {});
    }
  }
  if (thumbs.children.length) box.append(thumbs);
  if (files.children.length) box.append(files);
  return box;
};
// A stored user message carries a marker block naming its files; history strips it and shows them (FR-280).
const attSplit = (text) => {
  const m = text.match(/<studio-attachments>\n([\s\S]*?)\n<\/studio-attachments>/);
  if (!m) return { text, atts: [] };
  const atts = [];
  for (const line of m[1].split("\n")) {
    if (!line.startsWith("- {")) continue;
    try { const a = JSON.parse(line.slice(2)); if (a.id && a.name) atts.push({ id: a.id, name: a.name, kind: a.kind, size: a.size }); } catch {}
  }
  return { text: text.replace(m[0], "").trim(), atts };
};

// ---- deleting a chat with files (design 8, FR-274) ----
const attFilesText = (sum, many) => many
  ? `${sum.chats === 1 ? "1 of these chats has" : `${sum.chats} of these chats have`} attached files (${sum.files} file${sum.files === 1 ? "" : "s"}, ${attSize(sum.bytes)}). What should happen to them?`
  : `This chat has ${sum.files} attached file${sum.files === 1 ? "" : "s"} (${attSize(sum.bytes)}). What should happen to them?`;
// Returns "keep", "delete" or null (Cancel). One dialog replaces the usual "are you sure?" (design 8).
const confirmFiles = (title, text, sum, many) => new Promise((resolve) => {
  const d = $("confirmDelete");
  $("cdTitle").textContent = title;
  $("cdText").textContent = text;
  $("cdFiles").textContent = attFilesText(sum, many);
  $("cdKeep").textContent = many ? "Keep the files: moved to attachments\\_kept\\…" : "Keep the files: moved to attachments\\_kept\\…";
  $("cdDel").textContent = many ? "Delete them too: removed with the chats" : "Delete them too: removed with the chat";
  d.classList.add("files");
  d.returnValue = "";
  d.setAttribute("aria-describedby", "cdText cdFiles cdOutcomes");
  d.onclose = () => { d.classList.remove("files"); d.setAttribute("aria-describedby", "cdText"); resolve(["keep", "delete"].includes(d.returnValue) ? d.returnValue : null); };
  d.showModal();
  d.querySelector('[value="keep"]').focus();
});
const binNote = (text) => {
  let n = document.getElementById("binNote");
  if (!n) { n = el("p", "hint"); n.id = "binNote"; n.setAttribute("role", "status"); $("binView").prepend(n); }
  n.textContent = text;
  clearTimeout(binNote.t);
  binNote.t = setTimeout(() => n.remove(), 12000);
};
attRender();
